extract_info_SEM <- function(MATobject, dimensions = 2, type = "SEM"){
  
  
  if(type == "info"){
    
    index = 1
    
  }
  
  
  if(type == "SEM"){
    
    index = 2
    
  }

  
  test.obj <- MATobject[["Test.Info.SEM"]]
  
  obj.apply <- lapply(test.obj, "[[", index)
  
  sem.apply <- lapply(obj.apply, diag)
  
  sem.combine <- do.call(rbind.data.frame, sem.apply)
  
  if(type == "info"){

    colnames(sem.combine) = paste("Info", 1:dimensions, sep = "_")
    
  }
  
  
  if(type == "SEM"){
    
    colnames(sem.combine) = paste("SEM", 1:dimensions, sep = "_")
    
  }
  
  return(sem.combine)
  
}