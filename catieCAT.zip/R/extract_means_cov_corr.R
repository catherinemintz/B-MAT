extract_means_cov_corr <- function(MATobject, dimensions = 2, type = "means"){
  
  
  if(type == "cov" | type == "corr"){
    
    index = 1
    
  }
  
  
  if(type == "means"){
    
    index = 2
    
  }
  

  test.obj <- MATobject[["Estimated.Posterior.Distribution"]]
  
  obj.apply <- lapply(test.obj, "[[", index)
  
  
  if(type == "cov"){
    
    obj.return <- obj.apply
    
  }
    
  if(type == "corr"){
    
    obj.return <- lapply(obj.apply, function(x){
      
      y <- cov2cor(x)
      z <- odiag(y)
 
      
      if(dimensions == 2){
        
        z <- odiag(y)[1]
        
      }
      
      return(z)
      
    
      })
    
  }
  
  if(type == "means"){
    
    obj.return <- do.call(rbind.data.frame, obj.apply)
    colnames(obj.return) = paste("Theta", 1:dimensions, sep = "_")
    
  }

  
  return(obj.return)
  
}