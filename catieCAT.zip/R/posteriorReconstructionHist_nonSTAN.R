posteriorReconstructionHist_nonSTAN <- function(thetaobject, target_length = 900){

  dim1.min <- dim2.min <- -6
  dim1.max <- dim2.max <- 6

  dim1.bins <- seq(from = dim1.min, to = dim1.max, length.out = sqrt(target_length))
  dim2.bins <- seq(from = dim2.min, to = dim2.max, length.out = sqrt(target_length))

  dim1.increment <- (dim1.max-dim1.min)/length(dim1.bins)
  dim2.increment <- (dim2.max-dim2.min)/length(dim2.bins)

  dim1.labels <- dim1.bins
  dim2.labels <- dim2.bins


thetaobject_withcounts <- as.data.frame(table(cut(thetaobject[,1], breaks = seq.int(from = dim1.min, to = dim1.max, by = dim1.increment), labels = dim1.labels),
                                              cut(thetaobject[,2], breaks = seq.int(from = dim2.min, to = dim2.max, by = dim2.increment), labels = dim2.labels)))


thetaobject_withcounts[,1] <- as.numeric(as.character(thetaobject_withcounts[,1]))
thetaobject_withcounts[,2] <- as.numeric(as.character(thetaobject_withcounts[,2]))
thetaobject_withcounts[,3] <- as.numeric(as.character(thetaobject_withcounts[,3]))

## Calculating proportions

thetaobject_withcounts$Proportion <- thetaobject_withcounts$Freq/sum(thetaobject_withcounts$Freq)

return(thetaobject_withcounts)

}
