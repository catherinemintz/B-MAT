PPMC_evaluation_graphs <- function(PPMC_results, file_location){



  ## Read all PPMC iterations into a list

  filenames <- list.files(file_location, pattern="*.csv", full.names=TRUE)
  csv_names <- do.call(rbind.data.frame,lapply(filenames, function(x){

    iteration_name <- unlist(strsplit(as.character(x), "[^0-9]+"))[2]

    return(iteration_name)


  }))

  csv_list <- lapply(filenames, read.csv)

  for(i in 1:length(csv_list)){

    names(csv_list)[i] <- csv_names[i,]

  }


  ##=============== Computing the number of item pairs with problems and the items with the most problems

  item_problems <- lapply(seq_along(csv_list), function(i){

    x <- csv_list[[i]]

    mnrm_x <- x[,which(colnames(x)  %in% c("X", "mnrm.random.PPV"))]
    m3pl_x <- x[,which(colnames(x)  %in% c("X", "m3pl.random.PPV"))]

    mnrm_pairs <- mnrm_x[which(mnrm_x$mnrm.random.PPV < 0.025 |mnrm_x$mnrm.random.PPV > 0.975),]
    m3pl_pairs <- m3pl_x[which(m3pl_x$m3pl.random.PPV < 0.025 |m3pl_x$m3pl.random.PPV > 0.975),]

    # Number of item pairs with problems

    mnrm_pairs_num <- nrow(mnrm_pairs)
    m3pl_pairs_num <- nrow(m3pl_pairs)

    mnrm_problem_pairs <- m3pl_problem_pairs <- as.data.frame(matrix(NA, ncol = 3))
    colnames(mnrm_problem_pairs) <- colnames(m3pl_problem_pairs) <- c("Iteration", "Model", "Num.Pairs")

    mnrm_problem_pairs$Iteration <- m3pl_problem_pairs$Iteration <- names(csv_list)[i]
    mnrm_problem_pairs$Model <- "MNRM"
    m3pl_problem_pairs$Model <- "M3PL"
    mnrm_problem_pairs$Num.Pairs <- mnrm_pairs_num
    m3pl_problem_pairs$Num.Pairs <- m3pl_pairs_num

    problem_pairs <- rbind(mnrm_problem_pairs, m3pl_problem_pairs)

    #  Problematic Items

    mnrm_item_split <- unlist(strsplit(mnrm_pairs$X, "\\_"))
    m3pl_item_split <- unlist(strsplit(m3pl_pairs$X, "\\_"))

    mnrm_item_freq <- as.data.frame(table(mnrm_item_split))
    mnrm_item_freq$Model <- "MNRM"
    colnames(mnrm_item_freq) <- c("Item", "Freq", "Model")

    m3pl_item_freq <- as.data.frame(table(m3pl_item_split))
    m3pl_item_freq$Model <- "M3PL"
    colnames(m3pl_item_freq) <- c("Item", "Freq", "Model")

    item_freq <- rbind(mnrm_item_freq, m3pl_item_freq)
    item_freq$Iteration <- names(csv_list)[i]


    return(LIST(problem_pairs, item_freq))

  })

  num_pairs <- get_elements(item_problems, "problem_pairs")
  num_pairs_df <- do.call(rbind.data.frame, num_pairs)

  indiv_items <- get_elements(item_problems, "item_freq")
  indiv_items_df <- do.call(rbind.data.frame, indiv_items)


  #Across iterations, the number of problematic pairs

  num_pairs_plot <- ggplot(num_pairs_df)+
                        geom_histogram(aes(x = Num.Pairs))+
                        scale_x_continuous(name = "Number of Pairs")+
                        scale_y_continuous(name = "Counts")+
                        facet_wrap(vars(Model))+
                        theme_bw()









}
