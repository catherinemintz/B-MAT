#' Compare parameter to its standard error for models run with one chain
#'
#' @param stan.sum STAN summary object 
#' @param sample.size Number of iterations
#' @return Frequency tables of parameters with convergence issues

check_convergence <- function(stan.sum, sample.size){
  
  stan.sum$se <- stan.sum$sd/sample.size
  
  stan.sum <- stan.sum[which(stan.sum$mean != 0 & stan.sum$se != 0),]
  
  stan.sum$exceeds <- "No"
  
  stan.sum$exceeds[stan.sum$se >= abs(10*stan.sum$mean)] <- "Yes"
  
  datsub <- stan.sum[which(stan.sum$ess_bulk < 100 | stan.sum$ess_tail < 100 | stan.sum$exceeds == "Yes"),]
  
  if(TRUE %in% grepl("lambdaDim", datsub$variable)|TRUE %in%grepl("mu", datsub$variable)|TRUE %in%grepl("guess", datsub$variable)){
    
    datsub$param <- sub("^([[:alpha:]]*).*", "\\1", datsub$variable)
    
    p <- as.data.frame(table(datsub$param))
    
    return(p)
    
  } else {
    
    return("Solved")
    
  }
  
}