construct_chi_square <- function(categories, realdat, df2, cat.combos, return_PPMC = TRUE){

  df_list <- list(realdat, df2)

  cat.combos = cat.combos

  construction <- lapply(df_list, function(y){

    cat.tab <- as.data.frame(table(y[,1], y[,2]))

    print(cat.tab); print(cat.combos)
    colnames(cat.tab) <- c("Item1", "Item2", "Freq")
    colnames(cat.combos) <- c("Item1", "Item2", "Freq")

    cat.tab[,1] <- as.numeric(as.character(cat.tab[,1]))
    cat.tab[,2] <- as.numeric(as.character(cat.tab[,2]))

    for(i in 1:nrow(cat.combos)){
      for(j in 1:nrow(cat.tab)){

        if(cat.combos[i,c(1)] == cat.tab[j,c(1)] & cat.combos[i,c(2)] == cat.tab[j,c(2)]){

          cat.combos[i,3] <- cat.tab[j,3]

        }

      }
    }


  cat.contingency <- xtabs(Freq ~ Item1+Item2, data=cat.combos)

  return(cat.contingency)

  })

 chi_results <- unlist(lapply(construction, function(x){

  z <- chi_square(x)
  #chi <- z[["statistic"]][["X-squared"]]
  return(z)

 }))

 if(return_PPMC == TRUE){

   if(chi_results[2] >= chi_results[1]){

     chi.x <- 1

   } else {

     chi.x <- 0

   }

   return(chi.x)


 } else {

   return(chi_results)

 }

}


##
#item1 = chain1[1, grepl("Y_rep\\[1," , colnames( chain1 ))]
#item2 = chain1[1, grepl("Y_rep\\[2," , colnames( chain1 ))]
#df2 <- as.data.frame(cbind(item1, item2))

#realdat = MIRT_realdat_order[,c(1:2)]
#df2 = MIRT_realdat_order[,c(3:4)]
