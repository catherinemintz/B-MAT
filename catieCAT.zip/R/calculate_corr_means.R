calculate_corr_means <- function(STANdf){
 
  thetaobject <- STANdf[,(grep('theta\\[', colnames(STANdf)))]
  
  theta_corr_mat <- cor(thetaobject)
  theta_corr <- theta_corr_mat[1,2]
  means <- colMeans(thetaobject)
  
  return(list(theta_corr,means))
  
}