item_dimension_proportions <- function(MATobject, data_type = "nominal"){
  
  admin.items <- MATobject[["Administered.Items"]]

  admin.items.split <- split(admin.items, admin.items$Item)
  
  total_items <- list(0,0,0)
  
  names(total_items) <- c("Dim.1", "Dim.2", "Dim.Both")
  
  if(data_type == "nominal"){
    
    for(i in 1:length(admin.items.split)){
      
      if(all(unique(admin.items.split[[i]]$a1[1:3]) == 0)){
        
        total_items[["Dim.2"]] <- total_items[["Dim.2"]]+1
        
      }
      
      if(all(unique(admin.items.split[[i]]$a2[1:3]) == 0)){
        
        total_items[["Dim.1"]] <- total_items[["Dim.1"]]+1
        
      }
      
      if(all(unique(admin.items.split[[i]]$a1[1:3]) != 0) & all(unique(admin.items.split[[i]]$a2[1:3]) != 0)){
        
        total_items[["Dim.Both"]] <- total_items[["Dim.Both"]]+1
        
      }
      
    }
    
  }
  
  if(data_type == "dichotomous"){
    
    for(i in 1:length(admin.items.split)){
      
      if(all(unique(admin.items.split[[i]]$a1) == 0)){
        
        total_items[["Dim.2"]] <- total_items[["Dim.2"]]+1
        
      }
      
      if(all(unique(admin.items.split[[i]]$a2) == 0)){
        
        total_items[["Dim.1"]] <- total_items[["Dim.1"]]+1
        
      }
      
      if(all(unique(admin.items.split[[i]]$a1) != 0) & all(unique(admin.items.split[[i]]$a2) != 0)){
        
        total_items[["Dim.Both"]] <- total_items[["Dim.Both"]]+1
        
      }
      
    }
    
    
  }

  
  total_items_proportion <- lapply(total_items, function(x){
    
    round(x/length(admin.items.split),2)
    
  }) 
  
}