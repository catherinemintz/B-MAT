#' calculate_exposure_rate
#'
#' @param examinee_results List containing MAT output (examinee responses, items administered, and posterior).
#' @param item_pool Item pool input used in MAT. At minimum, should be a matrix or data frame with the first column being a numeric vector of item IDs.
#' @param comparison_examinee_results Optional list containing MAT output (examinee responses, items administered, and posterior). Used to compare different item pool parameterizations.
#' @return Depending on whether comparison_examinee_results is implemented, returns either 1) a data frame of the percent of examinees given each item or 2) a list of data frames of the percent of examinees given each item.


calculate_exposure_rate <- function(examinee_results, item_pool, comparison_examinee_results = NULL, comparison_names = NULL){

  ## Exposure rates for administered items

    administered_items <- lapply(examinee_results , "[[" , "Administered.Items")

    item_only <- lapply(administered_items , "[[" , "Item")

    unique_items_per_person <- lapply(item_only, function(x){

      return(unique(x))

    })

    unlisted_items <- unlist(unique_items_per_person)

    administered_items_table <-as.data.frame(table(unlisted_items))

    item_exposure_proportion <- as.data.frame((table(unlisted_items)/length(names(examinee_results)))*100)
    colnames(item_exposure_proportion) <- c("Item", "Exposure Rate")
    item_exposure_proportion$Item <- as.numeric(as.character(item_exposure_proportion$Item))

  ## Making sure items not administered are counted

    item_pool_items <- unique(item_pool[,1])
    not_administered <- as.data.frame(item_pool_items[item_pool_items %!in% administered_items_table[,1]])
    colnames(not_administered) <- "Item"

    if(nrow(not_administered) != 0){

     not_administered$`Exposure Rate` <- 0

     item_exposure_proportion <- rbind(item_exposure_proportion,not_administered)

    }



  ##=========================================== If comparing two different parameterizations of item pools

    if(is.null(comparison_examinee_results) == FALSE){

      item_exposure_proportion_original <- item_exposure_proportion[order(item_exposure_proportion[,1]),]

      comparison_administered_items <- lapply(comparison_examinee_results , "[[" , "Administered.Items")

      comparison_item_only <- lapply( comparison_administered_items , "[[" , "Item")

      comparison_unique_items_per_person <- lapply( comparison_item_only, function(x){

        return(unique(x))

      })

      comparison_unlisted_items <- unlist( comparison_unique_items_per_person)

      comparison_administered_items_table <-as.data.frame(table( comparison_unlisted_items))

      comparison_item_exposure_proportion <- as.data.frame((table( comparison_unlisted_items)/length(names( comparison_examinee_results)))*100)
      colnames( comparison_item_exposure_proportion) <- c("Item", "Exposure Rate")
      comparison_item_exposure_proportion$Item <- as.numeric(as.character( comparison_item_exposure_proportion$Item))

      ## Making sure items not administered are counted

      comparison_not_administered <- as.data.frame(item_pool_items[item_pool_items %!in% comparison_administered_items_table[,1]])
      colnames(comparison_not_administered) <- "Item"

      if(nrow(comparison_not_administered) != 0){

        comparison_not_administered$`Exposure Rate` <- 0

        comparison_item_exposure_proportion <- rbind(comparison_item_exposure_proportion,comparison_not_administered)

      }

      comparison_item_exposure_proportion <- comparison_item_exposure_proportion[order(comparison_item_exposure_proportion[,1]),]

      item_exposure_proportion <- as.data.frame(matrix(NA, ncol = 4, nrow = nrow(item_exposure_proportion_original)))
      colnames(item_exposure_proportion) <- c("Item", comparison_names[1], comparison_names[2], "Exposure Rate Difference")
      item_exposure_proportion[,c(1:2)] <- item_exposure_proportion_original
      item_exposure_proportion[,3] <- comparison_item_exposure_proportion[,2]

      item_exposure_proportion[,4] <- item_exposure_proportion[,2]-item_exposure_proportion[,3]


    }

    return(item_exposure_proportion)

}
