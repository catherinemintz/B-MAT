#' D_optimality
#'
#' @param item_parameters Matrix containing the item parameters for the previously administered items plus the auditioned item. The last row should contain the item parameters for the auditioned item.
#' @param data_type The type of data. Takes either "dichotomous" (for 0/1 scored data) or "nominal" (for unordered data; built for series of 1,2,3,4)
#' @return D-optimality value for the auditioned item.

D_optimality_hand_calc <- function(
  item_parameters,
  corr_means_STAN_object,
  data_type){


  if(data_type == "dichotomous"){

    model.type = "M3PL"

  }

  if(data_type == "nominal"){

    model.type = "MNRM"

  }

  info.mat <- test_information(item_parameters = item_parameters, model = model.type, theta.val = list(corr_means_STAN_object[[1]], as.vector(corr_means_STAN_object[[2]])), item.info = FALSE)[[1]]

  D_optim <- det(info.mat)

  return(D_optim)
} #end bracket
