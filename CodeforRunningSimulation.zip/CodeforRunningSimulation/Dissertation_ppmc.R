
myArgs = commandArgs(trailingOnly = TRUE) #this will have all the specified arguments


iteration = as.numeric(myArgs[1])


#save(myArgs, file = paste("/Users/mathers/Dissertation/myArgs_", condition, ".RData", sep = ""))
#
# set random number seed
seed = 0813 + iteration
set.seed(seed = seed)


####========================================================================== Reading in necessary functions and packages ####

library("MASS")
library("reshape2")
library("gtools")
#library("data.table")
#library("rstan")

for(i in 1:length(list.files(path = "/Users/mathers/catieCAT/R"))){
  
  file <- paste("/Users/mathers/catieCAT/R/",list.files(path = "/Users/mathers/catieCAT/R")[i], sep="")
  
  source(file, encoding="utf-8")
  
}
# M3PL Data


load(file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/M3PL/M3PL_Raw_Iteration_", iteration, ".RData", sep=""))

save(file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Generating Parameters/Iteration_", iteration, ".RData", sep=""))


####========================================================================== Reading in necessary functions and packages ####
# https://raw.githubusercontent.com/jonathantemplin/Bayesian-Psychometric-Modeling-Course-Fall2022/main/lectures/lecture05/05_Bayesian_Psychometric_Model_Fit.R
# setting up PPMC

#simData <- as.matrix(modrun_m3pl, pars = "Y_rep")
simData <- moddraws_m3pl[, grepl("Y_rep",colnames(moddraws_m3pl))]

colnames(simData)
dim(simData)

nItems = ncol(sim_response_dich_df)
nObs = nrow(sim_response_dich_df)
item_combos <- as.data.frame(gtools::combinations(nItems, 2, c(1:nItems)))

real.chi = NULL
for(i in 1:nrow(item_combos)){
  df1 <- table(sim_response_dich_df[,item_combos[i,1]], sim_response_dich_df[,item_combos[i,2]])
  real.chi[i] <- chisq.test(df1)["statistic"]
  
}

# set up object for storing each iteration's PPMC data
nPairs = choose(ncol(sim_response_dich_df), 2)
pairNames = NULL
for (col in 1:(nItems-1)){
  for (row in (col+1):nItems){
    pairNames = c(pairNames, paste0("item", row, "_item", col))
  }
}

PPMCsamples2 = list()

PPMCsamples2$correlation = NULL
PPMCsamples2$mean = NULL
PPMCsamples2$chi = NULL

# loop over each posterior sample's simulated data

for (sample in 1:nrow(simData)){
  #for (sample in 1:100){ #CATIE: uncomment above and delete this line when done troubleshooting
  
  # create data frame that has observations (rows) by items (columns)
  sampleData = data.frame(matrix(data = NA, nrow = nObs, ncol = nItems))
  
  for (item in 1:nItems){
    itemColumns = colnames(simData)[grep(pattern = paste0("Y_rep\\[", item, "\\,"), x = colnames(simData))] 
    #sampleData[,item] = t(simData[sample, itemColumns])
    sampleData[,item] = (simData[sample, itemColumns])
  }
  # with data frame created, apply functions of the data:
  
  # calculate item means
  PPMCsamples2$mean = rbind(PPMCsamples2$mean, apply(X = sampleData, MARGIN = 2, FUN = mean))
  
  # calculate pearson correlations  
  temp=cor(sampleData)
  PPMCsamples2$correlation = rbind(PPMCsamples2$correlation, temp[lower.tri(temp)])
  
  # calculate chi-square statistics
  
  sim.chi = vector(length = nrow(item_combos))
  
  for(i in 1:nrow(item_combos)){
    
    item1 <- sampleData[,c(item_combos[i,1])]
    item2 <- sampleData[,c(item_combos[i,2])]
    
    df2 <- table(item1, item2)
    
    sim.chi[i]  <- chisq.test(df2)["statistic"]
    
  }
  
  
  PPMCsamples2$chi <- rbind(PPMCsamples2$chi, sim.chi)
}

colnames(PPMCsamples2$correlation) = pairNames
colnames(PPMCsamples2$mean) = paste0("item", 1:nItems)
colnames(PPMCsamples2$chi) = pairNames

# example densities of some statistics

for(i in 1:nItems){
  plot(density(PPMCsamples2$mean[,i]), main = paste("Posterior Predictive Distribution: Item ", i, " Mean", sep = ""))
  lines(x = c(mean(sim_response_dich_df[,i]),mean(sim_response_dich_df[,i])), y = c(0,10),
        lty = 2, col=2, lwd=3)
}


for(i in 1:nrow(item_combos)){
  
  plot(density(PPMCsamples2$correlation[,1]), main = paste("Items", item_combos[i,1], "and", item_combos[i,2], "Pearson Correlation"))
  lines(x = c(cor(sim_response_dich_df[,item_combos[i,1]:item_combos[i,2]])[1,2],
              cor(sim_response_dich_df[,item_combos[i,1]:item_combos[i,2]])[1,2]),
        y = c(0,10),
        lty = 2, col=2, lwd=3)
  
  plot(density(PPMCsamples2$chi[,1]), main = paste("Items", item_combos[i,1], "and", item_combos[i,2], "Chi-Square"))
  lines(x = c(real.chi[i],
              real.chi[i]),
        y = c(0,10),
        lty = 2, col=2, lwd=3)
  
}


# next, build distributions for each type of statistic
meanSummary2 = NULL

# for means
for (item in 1:nItems){
  
  tempDist = ecdf(PPMCsamples2$mean[,item])
  ppmcMean = mean(PPMCsamples2$mean[,item])
  observedMean = mean(sim_response_dich_df[,item])
  meanSummary2 = rbind(
    meanSummary2,
    data.frame(
      item = paste0("Item", item),
      ppmcMean = ppmcMean,
      observedMean = observedMean,
      residual = observedMean - ppmcMean,
      observedMeanPCT = tempDist(observedMean)
    )
  )
  
}
print(meanSummary2)

# for  correlations
corrSummary2 = NULL

# for means
for (column in 1:ncol(PPMCsamples2$correlation)){
  
  # get item numbers from items
  items = unlist(strsplit(x = colnames(PPMCsamples2$correlation)[column], split = "_"))
  item1num = as.numeric(substr(x = items[1], start = 5, stop = nchar(items[1])))
  item2num = as.numeric(substr(x = items[2], start = 5, stop = nchar(items[2])))
  
  tempDist = ecdf(PPMCsamples2$correlation[,column])
  ppmcCorr = mean(PPMCsamples2$correlation[,column])
  observedCorr = cor(sim_response_dich_df[,c(item1num, item2num)])[1,2]
  pct = tempDist(observedCorr)
  if (pct > .975 | pct < .025){
    inTail = TRUE
  } else {
    inTail = FALSE
  }
  corrSummary2 = rbind(
    corrSummary2,
    data.frame(
      item1 = paste0("Item", item1num),
      item2 = paste0("Item", item2num),
      ppmcCorr = ppmcCorr,
      observedCorr = observedCorr,
      residual = observedCorr - ppmcCorr,
      observedCorrPCT = pct, 
      inTail = inTail
    )
  )
  
}

#chisquare
ChiSummary2 = NULL

for (column in 1:ncol(PPMCsamples2$chi)){
  
  # get item numbers from items
  items = unlist(strsplit(x = colnames(PPMCsamples2$chi)[column], split = "_"))
  item1num = as.numeric(substr(x = items[1], start = 5, stop = nchar(items[1])))
  item2num = as.numeric(substr(x = items[2], start = 5, stop = nchar(items[2])))
  
  tempDistChi = ecdf(PPMCsamples2$chi[,column])
  ppmcChi = mean(PPMCsamples2$chi[,column])
  observedChi = chi_square(table(sim_response_dich_df[,c(item1num, item2num)]))
  pct = tempDistChi(observedChi)
  if (pct > .975 | pct < .025){
    inTail = TRUE
  } else {
    inTail = FALSE
  }
  ChiSummary2 = rbind(
    ChiSummary2,
    data.frame(
      item1 = paste0("Item", item1num),
      item2 = paste0("Item", item2num),
      ppmcChi = ppmcChi,
      observedChi = observedChi,
      residual = observedChi - ppmcChi,
      observedChiPCT = pct, 
      inTail = inTail
    )
  )
  
}

print(ChiSummary2)

# gather count of problematic items
badItemsCorr= c(
  corrSummary2$item1[corrSummary2$inTail],
  corrSummary2$item2[corrSummary2$inTail]
)
table(badItemsCorr)[order(table(badItemsCorr), decreasing = TRUE)]


badItemsChi= c(
  ChiSummary2$item1[ChiSummary2$inTail],
  ChiSummary2$item2[ChiSummary2$inTail]
)

table(badItemsChi)[order(table(badItemsChi), decreasing = TRUE)]

#save(PPMCsamples2, corrSummary2, meanSummary2, badItemsCorr, badItemsChi, file = "~/hpchome/Dissertation/RealData/PPMC_Items/PPMC_Results_Templin_Code.RData")#local

save(PPMCsamples2, corrSummary2, meanSummary2, badItemsCorr, badItemsChi, file = "/Users/mathers/Dissertation/RealData/PPMC_Items/PPMC_Results_Templin_Code.RData")

writexl::write_xlsx(corrSummary2, path = "~/hpchome/Dissertation/RealData/PPMC_Items/Correlations.xlsx")
writexl::write_xlsx(ChiSummary2, path = "~/hpchome/Dissertation/RealData/PPMC_Items/Chi.xlsx")
