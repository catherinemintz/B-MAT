## DCM Loglikelihood =============================================

DCMloglike_old = function(response, b0, b1, b2, num_att, data_type = "dichotomous", per_class = FALSE){ # for the LCDM

  data_type = data_type
  response = response
  num_class = 2^num_att

  class = NULL
  for (classNum in 1:num_class){
    class = rbind(class, dec2bin(decimal_number = classNum-1, nattributes = num_att, basevector = rep(2, num_att)))
  }

  class_loglike <- matrix(NA, ncol = num_class, nrow = 1)


  ##--------------------------------------------------- Dichotomous data

  if(data_type == "dichotomous"){
    #for(classNum in 1:ncol(class)){

    prob <- matrix(NA, ncol = num_class)

    prob = exp(b0+(b1*class[,1])+(b2*class[,2]))/(1+exp(b0+(b1*class[,1])+(b2*class[,2])))

    for(cl in 1:num_class){
   #   loglikelihood = dbinom(x = response, size = 1, prob = prob[cl], log = TRUE)
    # class_loglike[cl] <- loglikelihood
      class_loglike[cl] <- dbinom(x = response, size = 1, prob = prob[cl], log = TRUE)

    }

    #  }
    }

  ##--------------------------------------------------- Nominal data
  if(data_type == "nominal"){
    #  for(cat in 1:length(b0)){

    r_vec <- vector(length = length(b0))
    cat <- response
    r_vec[cat] <- 1

    cat_prob <- matrix(NA, nrow = length(r_vec), ncol = num_class)
    denom_cat <- matrix(NA, nrow = length(r_vec), ncol = num_class)


    for(cat in 1:length(r_vec)){
        denom_cat[cat,] <- exp(b0[cat]+(b1[cat]*class[,1])+(b2[cat]*class[,2]))
      }

      denom <- colSums(denom_cat)


    for(cat in 1:length(r_vec)){
      cat_prob[cat,] = exp(b0[cat]+(b1[cat]*class[,1])+(b2[cat]*class[,2]))/denom
    }

    for(cl in 1:num_class){
    #  loglikelihood = dmultinom(x = r_vec, prob = cat_prob[,cl], log = TRUE)
    #  class_loglike[cl] <- loglikelihood
      class_loglike[cl] <- dmultinom(x = r_vec, prob = cat_prob[,cl], log = TRUE)
    }


    # }
  }

  if(per_class == TRUE){

    return(class_loglike)

  } else{

    class_loglike_sum <- sum(class_loglike)

    return(class_loglike_sum)
  }
}


# multinomprob <- matrix(NA, nrow = 1)
#
# for(cprob in 1:length(r_vec)){
#   if(r_vec[cprob] == 1 ){
#     multinomprob[cprob] <- cat_prob[cprob]
#   } else{
#     multinomprob[cprob] <- 1
#   }
# }
#
#loglikelihood = prod(multinomprob)
