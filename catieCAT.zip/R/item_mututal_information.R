#' Mutual Information statistic for a single auditioned item.
#'
#' @param response_array Vector of responses to previously administered items
#' @param current_posterior Current posterior estimate as returned from the posteriorReconstructionHist function. NOTE: posterior densities with zero probability have a small decimal added to them.
#' @param item_parameters Parameters/parameter estimates for the auditioned item
#' @param items_administered Parameters/parameter estimates for the previously administered items
#' @param latent_variable_type How the latent variables are distributed. Takes "continuous" or "categorical" as input
#' @param data_type Takes input of "dichotomous" or "nominal"
#' @return MI statistic for auditioned item

item_mututal_information = function(response_array,
                                    current_posterior,
                                    item_parameters,
                                    items_administered,
                                    latent_variable_type,
                                    data_type,
                                    item_priors){

  posterior_list <- list()


  if(latent_variable_type == "categorical"){

    classObject <- matrix(c(0,0,1,1,0,1,0,1), nrow = 4, ncol = 2)

    if(data_type == "dichotomous"){

      b0 <- item_parameters[,2]
      b1 <- item_parameters[,3]
      b2 <- item_parameters[,4]

      # current_posterior = p(\alpha_c|_yn-1)
      # classObject == attribute profile for each class

      condLogit <- vector(length = length(current_posterior))
      condProb_1 <- vector(length = length(current_posterior))
      condProb_0 <- vector(length = length(current_posterior))


      Prob1 = matrix(NA, nrow = length(current_posterior))
      Prob0 = matrix(NA, nrow = length(current_posterior))

      for(classNum in 1:length(current_posterior)){
        condLogit[classNum] = b0+(b1*classObject[classNum,1])+(b2*classObject[classNum,2])
        condProb_1[classNum] = exp(condLogit[classNum])/(1+exp(condLogit[classNum])) #P(Y=1|a_c)
        condProb_0[classNum] = 1-condProb_1[classNum] #P(Y=0|a_c)

        Prob1[classNum] = condProb_1[classNum]*current_posterior[classNum]
        Prob0[classNum] = condProb_0[classNum]*current_posterior[classNum]
      }


      binary_response <- matrix(c(0,1), nrow = 2)
      posterior_class <- matrix(NA, nrow =classNum, ncol = length(binary_response))
      term_prod = vector(length=length(binary_response))

      score_vec <- vector()
      first_term <- vector()
      second_term <- vector(length = length(current_posterior)) #CATIE

      for(score in 1:length(binary_response)){

        if(score == 1){
          score_vec = 0
          condl_prob = condProb_0
          marg_prob <- sum(Prob0)

        } else {
          score_vec = 1
          condl_prob = condProb_1
          marg_prob <<- sum(Prob1)

        }


        posterior_given_n_and_n_minus_1 <- posteriorEstimate(response = score_vec,
                                                             item_parameters = item_parameters,
                                                             class_prior = current_posterior,
                                                             num_att = 2,
                                                             data_type = "dichotomous") #P(a_c|Y, y-1)

        for (classNum in 1:length(current_posterior)){
          second_term[classNum] <- posterior_given_n_and_n_minus_1[classNum]*log(posterior_given_n_and_n_minus_1[classNum]/current_posterior[classNum])
        }

        first_term <- marg_prob
        second_sum_over_class = sum(second_term)
        term_prod[score] = first_term*second_sum_over_class


        posterior_list[[score]] <- posterior_given_n_and_n_minus_1

      }
      MI = sum(term_prod)
    }


    ##------------------------------------------------Nominal Condition
    if(data_type == "nominal"){

      applied_ia_ic <- MI_conditional_logits_DCM(DF = item_parameters, current_posterior = current_posterior, classObject = classObject)

      marg_cat_probs <- matrix(NA, nrow = 4, ncol = length(current_posterior))

      for (classNum in 1:length(current_posterior)){
        for(u in 1:nrow(applied_ia_ic)){
          marg_cat_probs[u, classNum] <- applied_ia_ic[u, classNum]*current_posterior[classNum]
        }
      }


      nominal_response <- matrix(c(1,2,3,4), nrow = 4)
      posterior_class <- matrix(NA, nrow =ncol(classObject), ncol = length(nominal_response))

      first_term <- vector()
      second_term <- vector()

      for(score in 1:length(nominal_response)){

        score_vec <- nominal_response[score,]
        condl_prob = applied_ia_ic[score,]
        marg_cat_probs_sum <- sum(marg_cat_probs[score,])

        posterior_given_n_and_n_minus_1 <- posteriorEstimate(response = score_vec,
                                                             item_parameters = item_parameters,
                                                             class_prior = current_posterior,
                                                             num_att = 2,
                                                             data_type = "nominal") #P(a_c|Y, y-1)

        for (classNum in 1:length(current_posterior)){
          second_term[classNum] <- posterior_given_n_and_n_minus_1[classNum]*log(posterior_given_n_and_n_minus_1[classNum]/current_posterior[classNum])
        }

        first_term <- marg_cat_probs_sum
        second_sum_over_class = sum(second_term)
        term_prod[score] = first_term*second_sum_over_class


        posterior_list[[score]] <- posterior_given_n_and_n_minus_1

      }

      MI = sum(term_prod)
    }
  }

  ##------------------------------------------------------------------------------------------------------------

  if(latent_variable_type == "continuous"){
    if(data_type == "dichotomous"){

      item_with_administered <- rbind(items_administered, item_parameters)

      quad <- do.call(cbind, mgauss.hermite(n = 30, mu = item_priors[["mu_theta"]], sigma = item_priors[["Sigma"]]))
      current_posterior = as.data.frame(quad)
      colnames(current_posterior) <- c("Dim1", "Dim2", "Prob")

      condProb <- apply(item_with_administered, MARGIN = 1, function(y){

        z.list <-  apply(current_posterior[,c(1:2)], MARGIN = 1, function(x){

          z <- list()

          z[[1]] <- M3PL(single_item_parameters = y, theta = x, return_probs = TRUE)
          z[[2]] <- 1- z[[1]]

          return(z)
        })

        z.combine <- do.call(rbind.data.frame, z.list)
        return(z.combine)

      })

      binary_response <- c(0,1)
      term_prod = vector(length=length(binary_response))

      for(score in 1:length(binary_response)){

        score_vec <- binary_response[score]

        response_array_plus_score_vec <- c(response_array, score_vec)

        response_index <- vector()
        response_index[response_array_plus_score_vec == 0] <- 2
        response_index[response_array_plus_score_vec == 1] <- 1

        selected_condProb <- lapply(seq_along(condProb), function(i){ #conditional probabilities of items given the response patterns

          y <- condProb[[i]][[response_index[i]]]
          return(y)

        })

        selected_condProb_df <- do.call(cbind.data.frame, selected_condProb)

        marg_prob <- sum(selected_condProb_df[[length(response_array_plus_score_vec)]]*current_posterior$Prob)

        updated_posterior <- apply(selected_condProb_df, MARGIN = 1, FUN = prod)

        if(0 %in% updated_posterior){

          updated_posterior[which(updated_posterior == 0)] <- .Machine$double.xmin

        }

        if(0 %in% current_posterior$Prob){

          current_posterior[current_posterior$Prob == 0] <- .Machine$double.xmin

        }


        second_term <- updated_posterior*log(updated_posterior/current_posterior$Prob)

        second_term_sum <- sum(second_term)
        term_prod[score] <- marg_prob*second_term_sum

      }

      MI <- MI_post <- sum(term_prod)

    }

    if(data_type == "nominal"){

      item_with_administered <- rbind(items_administered, item_parameters)

      quad <- do.call(cbind, mgauss.hermite(n = 30, mu = item_priors[["mu_theta"]], sigma = item_priors[["Sigma"]]))
      current_posterior = as.data.frame(quad)
      colnames(current_posterior) <- c("Dim1", "Dim2", "Prob")

      item.split <- split(item_with_administered, factor(item_with_administered$Item, levels = unique(item_with_administered$Item)))
      condProb <- lapply(item.split, function(y){

        z.list <-  apply(current_posterior[,c(1:2)], MARGIN = 1, function(x){

          z <- MNRM(single_item_parameters = y, theta = x, return_probs = TRUE)

          return(z)

        })

        z.combine <- do.call(rbind.data.frame, z.list)
        return(z.combine)

      })

      nominal_response <- c(1,2,3,4)
      term_prod = vector(length=length(nominal_response))

      for(score in 1:length(nominal_response)){

        score_vec <- nominal_response[score]

        response_array_plus_score_vec <- c(response_array, score_vec)

        selected_condProb <- lapply(seq_along(condProb), function(i){ #conditional probabilities of items given the response patterns

          y <- condProb[[i]][[response_array_plus_score_vec[i]]]
          return(y)

        })
        selected_condProb_df <- do.call(cbind.data.frame, selected_condProb)

        marg_prob <- sum(selected_condProb_df[[length(response_array_plus_score_vec)]]*current_posterior$Prob)

        updated_posterior <- apply(selected_condProb_df, MARGIN = 1, FUN = prod)

        if(0 %in% updated_posterior){

          updated_posterior[which(updated_posterior == 0)] <- .Machine$double.xmin

        }

        if(0 %in% current_posterior$Prob){

          current_posterior[current_posterior$Prob == 0] <- .Machine$double.xmin

        }

        second_term <- updated_posterior*log(updated_posterior/current_posterior$Prob)

        second_term_sum <- sum(second_term)
        term_prod[score] <- marg_prob*second_term_sum

      }

      MI <- MI_post <- sum(term_prod)

    }
  }

  return(MI_post)

}

