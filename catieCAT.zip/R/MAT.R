#' Multidmensional Adaptive Test Simulation
#'
#' @param item_pool A dataframe with column vectors in the following order: Question ID, Item intercept, and A minus 2 Attribute weight columns
#' @param item_selection_criterion Choice of item selection criterion. Takes either "Mutual Information" or "D-optimality" as input
#' @param test_termination_criterion The number of items to administer
#' @param data_type The type of data. Takes either "dichotomous" (for 0/1 scored data) or "nominal" (for unordered data; built for series of 1,2,3,4)
#' @param true_theta Either a vector of length two or matrix with nrow = number of personal and ncol = number of latent variables
#' @param Sigma IN PROGRESS. Potentially a list, with each element corresponding to a matrix like that obtained with posteriorReconstructionHist?
#' @return A list of item responses, administered items, and the estimated posterior distribution after each item for each simulee.

MAT <- function(item_pool, item_selection_criterion, test_termination_criterion, data_type, model_text_file, first_item_text_file = NULL, true_theta, priors, working_directory, Bank, Person, stan.its){


  #################### Changes since last time
  # Changed calculate_corr_means to calculate_cov_means to work with updated STAN syntax
  # Updated moddata so the lkj prior is now the prior for Sigma and theta_prior = Sigma
  #
  # Changed a line in D_optimality_hand_calc; added eval to info.mat to solve the equation. double check that this is correct
  ###################

 # set.seed(123)

  Bank <- Bank
  Person <- Person
  true_theta <- true_theta
  priors <- priors

  stan.warmup = round(((1/2)*stan.its),0)

  #current_posterior <- mvrnorm(n = 1000, mu = mu_Post, Sigma = Sigma_Post) #Actually the prior

  # Objects for necessary follow-ups

  #items_administered <- matrix(NA)

  estimated_posterior <- test.info.sem <- list()
  responses <- vector(length=test_termination_criterion)
  working_directory = working_directory

  objectlengths <- 1

  ISC <- rep(NA,nrow(item_pool))
  item_pool <- cbind(item_pool, ISC)

  if(missing(first_item_text_file)) {

    first_item_text_file <- model_text_file

  }

  model.file <- readr::read_file(model_text_file)

  modstan = rstan::stan_model(model_code = model.file)
  first.file <- readr::read_file(first_item_text_file)

  modstan_first = rstan::stan_model(model_code = first.file) # compile stan model

  options(mc.cores = parallel::detectCores(), error = traceback)
  rstan::rstan_options(auto_write = TRUE)

####========================================================== First item ==================================================####

            if(item_selection_criterion == "mutual information"| item_selection_criterion == "Mutual Information"){

              item_pool_split <- split(item_pool, item_pool[,1])
              item_pool_MI <- lapply(item_pool_split, function(x){

                first_results <- first_item_mututal_information_calc(item_parameters = x[,c(1:5)],
                                                                latent_variable_type = "continuous",
                                                                data_type = data_type,
                                                                 item_priors = priors)

                x$ISC = first_results
                return(x)
                #print(first_results)

              })
              item_pool = do.call(rbind.data.frame, item_pool_MI)

          }

            if(item_selection_criterion == "D-Optimality"| item_selection_criterion == "d-optimality"){

              item_pool_split <- split(item_pool, item_pool[,1])
              item_pool_Dopt <- lapply(item_pool_split, function(x){


                Dopt <-  D_optimality_hand_calc(item_parameters = x[,c(1:5)],
                                                  corr_means_STAN_object = list(priors[["Sigma"]], priors[["mu_theta"]]),
                                                  data_type = data_type)

                x$ISC = Dopt
                return(x)

              })
              item_pool = do.call(rbind.data.frame, item_pool_Dopt)

            }


                print("First item chosen")

                item_pool$ISC <- as.numeric(item_pool$ISC)

                item_pool_sorted <- item_pool[order(-item_pool$ISC), ]

                item_pool_unique <- unique(item_pool_sorted[,c(1,6)])

                top_five <- item_pool_unique[1:5,]

                item_to_be_administered_id <- top_five[sample(1:nrow(top_five), 1), ]

                item_to_be_administered <- item_pool[which(item_pool[,1] == item_to_be_administered_id[,1]),]

                items_administered <- item_to_be_administered

   ###========================================================== Update score, test info, and STAN inputs ==================================###

            if(data_type == "dichotomous"){

            new_response <- M3PL(item_to_be_administered, theta = true_theta, return_probs = FALSE)
            responses[objectlengths] <- new_response
            response_vec <- as.matrix(new_response, nrow = 1)

            test.info.sem[[objectlengths]] <- test_information(item_parameters = items_administered,
                                                               theta.val = list(priors[["Sigma"]], priors[["mu_theta"]]),
                                                               model = "M3PL",
                                                               item.info = FALSE)

            }

            if(data_type == "nominal"){

            new_response <- MNRM(item_to_be_administered, thetas = true_theta, return_probs = FALSE)
            responses[objectlengths] <- new_response
            response_vec <- as.matrix(new_response, nrow = 1)

            test.info.sem[[objectlengths]] <- test_information(item_parameters = items_administered,
                                                               theta.val = list(priors[["Sigma"]], priors[["mu_theta"]]),
                                                               model = "MNRM", item.info = FALSE)

            }


###========================================================== Updating Algorithm  ===========================================###

              if(data_type == "dichotomous"){

                moddata = list(nItems = 1,
                               Y =  response_vec,
                               mu = array(item_to_be_administered[,which(grepl('d', colnames(item_to_be_administered)) == TRUE)]),
                               lambdaDim = array(item_to_be_administered[,which(grepl('^a', colnames(item_to_be_administered)) == TRUE)]),
                               guess = array(item_to_be_administered[,which(grepl('c', colnames(item_to_be_administered)) == TRUE)]),
                               nFactors = length(priors[["mu_theta"]]),
                               meanTheta = priors[["mu_theta"]],
                               Sigma = priors[["Sigma"]],
                               Theta_Strength = priors[["Theta_Strength"]]) # define model data as specified in the rstan model syntax's data block (just like cmdstanr)

                }

              if(data_type == "nominal"){
                moddata = list(nObs = 1,
                               nItems = 1,
                               Y = response_vec,
                               nFactors = length(priors[["mu_theta"]]),
                               meanTheta = priors[["mu_theta"]],
                               Sigma = priors[["Sigma"]],
                               Theta_Strength = priors[["Theta_Strength"]]) # define model data as specified in the rstan model syntax's data block (just like cmdstanr)

                moddata[["mu"]] <- array(item_to_be_administered[,which(grepl('d', colnames(item_to_be_administered)) == TRUE)])
                moddata[["lambdaDim"]] <- t(as.matrix(item_to_be_administered[,which(grepl('^a', colnames(item_to_be_administered)) == TRUE)], ncol = length(true_theta)))
                moddata[["maxCategory"]] <- priors[["maxCategory"]]

              }

              modrun = rstan::sampling(modstan_first,
                                       data = moddata,
                                       chains = 4,
                                       warmup = stan.warmup,
                                       iter = stan.its,
                                       refresh = 1500) # run sampler with default settings (see rstan documentation at https://mc-stan.org/rstan/reference/stanmodel-method-sampling.html for more options, if needed)

              modsum = posterior::summarise_draws(modrun) # summarizes the posterior draws after sampling

              current_posterior_STAN = as.data.frame(modrun) # saves the posterior's draws to a data.frame object

###========================================================== Updating posterior-dependent inputs  ==================================###

                current_posterior <- posterior_reconstruction_hist(current_posterior_STAN[,c(1:2)], bins = 30, set_limits = TRUE, target_length = 900)

              #  estimated_posterior[[objectlengths]] <- current_posterior_STAN #make sure this object updates accordingly

                #desc <- calculate_corr_means(current_posterior_STAN)
                estimated_posterior[[objectlengths]]  <- desc <- calculate_cov_means(current_posterior_STAN, method = "across")

                priors[["mu_theta"]] <- desc[[2]]
                priors[["Sigma"]] <- desc[[1]]

                objectlengths <- objectlengths + 1

####========================================================== After first item ===================================================####

      while(objectlengths <= test_termination_criterion){ #keep looping through until the specified number of items is administered

          print(paste("Selecting item", objectlengths))

          item_parameters <- item_pool[which(item_pool[,1] %!in% items_administered[,1]),]


          if(item_selection_criterion == "mutual information"| item_selection_criterion == "Mutual Information"){

            mgauss.post = mgauss.hermite(n = 30, mu = priors[["mu_theta"]], sigma = priors[["Sigma"]])

            item.split <- split(items_administered, factor(items_administered$Item, levels = unique(items_administered$Item)))


            if(data_type == "nominal"){

              condProb <- lapply(item.split, function(y){

                z.list <-  apply(mgauss.post[,c(1:2)], MARGIN = 1, function(x){

                  z <- MNRM(single_item_parameters = y, theta = x, return_probs = TRUE)

                  return(z)

                })
                t.z <- t(z.list)

                # z.combine <- do.call(rbind.data.frame, z.list)
                return(t.z)

              })

              selected_condProb <- lapply(seq_along(condProb), function(i){ #conditional probabilities of items given the response patterns

                # z <- sapply(condProb[[i]], `[`, responses[1:objectlengths-1][i])

                z <- condProb[[i]][,responses[1:objectlengths-1][i]]

                return(z)

              })

            }

            if(data_type == "dichotomous"){

              condProb <- lapply(item.split, function(y){

                z.list <-  apply(mgauss.post[,c(1:2)], MARGIN = 1, function(x){

                  w <- M3PL(single_item_parameters = y, theta = x, return_probs = TRUE)
                  z <- c(1-w,w)

                  return(z)

                })
                t.z <- t(z.list)

                # z.combine <- do.call(rbind.data.frame, z.list)
                return(t.z)

              })

              responses_converted <- responses+1

              selected_condProb <- lapply(seq_along(condProb), function(i){ #conditional probabilities of items given the response patterns

                # z <- sapply(condProb[[i]], `[`, responses[1:objectlengths-1][i])

                z <- condProb[[i]][,responses_converted[1:objectlengths-1][i]]

                return(z)

              })



            }


            item_param_split <- split(item_parameters, item_parameters$Item)

            item_param_MI <- lapply(item_param_split, function(x){

              item_results <-  item_mututal_information_short(response_array = responses[1:objectlengths-1],
                                                  item_parameters = x[,c(1:5)],
                                                 items_administered = selected_condProb,
                                                 latent_variable_type = "continuous",
                                                 data_type = data_type,
                                                 mgauss = mgauss.post)
              x$ISC = item_results
              return(x)

            })

            item_parameters = do.call(rbind.data.frame, item_param_MI)

            item_parameters$ISC <- as.numeric(item_parameters$ISC)
            colnames(item_parameters) <- colnames(item_pool)

            }

          if(item_selection_criterion == "D-Optimality"| item_selection_criterion == "d-optimality"){

            item_pool_split <- split(item_parameters, item_parameters[,1])
            item_pool_Dopt <- lapply(item_pool_split, function(x){

                Dopt <-  D_optimality_hand_calc(item_parameters = x[,c(1:5)],
                                               corr_means_STAN_object = list(desc[[1]], desc[[2]]),
                                               data_type = data_type)

                x$ISC <- Dopt

              return(x)

            })
            item_parameters = do.call(rbind.data.frame, item_pool_Dopt)


          }

###========================================================== Update score and STAN inputs ==================================###

          max.item.id <- unique(item_parameters$Item[(which.max(item_parameters$ISC))])

          item_to_be_administered <- item_parameters[which(item_parameters[,1] == max.item.id),] #select item who has the highest MI from MI_results

          items_administered <- rbind(items_administered,item_to_be_administered)


          if(data_type == "dichotomous"){

            new_response <- M3PL(item_to_be_administered, theta = true_theta, return_probs = FALSE)
            responses[objectlengths] <- new_response
            response_vec <- c(response_vec, new_response)

            test.info.sem[[objectlengths]] <- test_information(item_parameters = items_administered,
                                                               theta.val = list(priors[["Sigma"]], priors[["mu_theta"]]),
                                                               model = "M3PL", item.info = FALSE)

          }

          if(data_type == "nominal"){

          new_response <- MNRM(item_to_be_administered, thetas = true_theta, return_probs = FALSE)
          responses[objectlengths] <- new_response
          response_vec <- c(response_vec, new_response)

          test.info.sem[[objectlengths]] <- test_information(item_parameters = items_administered,
                                                             theta.val = list(priors[["Sigma"]], priors[["mu_theta"]]),
                                                             model = "MNRM", item.info = FALSE)

          }

###========================================================== Updating Algorithm  ===========================================###

          if(data_type == "dichotomous"){

             moddata = list(nItems = length(unique(items_administered[,1])),
                            # mu =  t(array(items_administered[,which(grepl('d', colnames(items_administered)) == TRUE)], dim = c(length(unique(items_administered[,1]))))),
                            mu = as.vector(t(array(items_administered[,which(grepl('d', colnames(items_administered)) == TRUE)], dim = c(length(unique(items_administered[,1])))))),
                            #guess =  t(array(items_administered[,which(grepl('c', colnames(items_administered)) == TRUE)], dim = c(length(unique(items_administered[,1]))))),
                            guess = as.vector(t(array(items_administered[,which(grepl('c', colnames(items_administered)) == TRUE)], dim = c(length(unique(items_administered[,1])))))),
                            lambdaDim =array(t(items_administered[,which(grepl('^a', colnames(items_administered)) == TRUE)]), dim = c(length(true_theta), length(unique(items_administered[,1])))),
                            Y = t(as.matrix(response_vec, nrow = 1)),
                            nFactors = length(priors[["mu_theta"]]),
                            meanTheta = as.vector(desc[[2]]),
                            Sigma = desc[[1]],
                            Theta_Strength = priors[["Theta_Strength"]]) # define model data as specified in the rstan model syntax's data block (just like cmdstanr

              }

          if(data_type == "nominal"){
            num_items_admin <- length(unique(items_administered$Item))
            unique_items_admin <- unique(items_administered$Item)

            mu <- array(dim = c(num_items_admin, priors[["maxCategory"]]))

            for(p in 1:num_items_admin){

              mu[p,]  <- items_administered[unique_items_admin[p] == items_administered[,1], grepl('d', colnames(items_administered)) == TRUE]

            }

            lambdaDim <- array(dim = c(length(true_theta), num_items_admin,  priors[["maxCategory"]]))

            for(p in 1:length(true_theta)){

              patt <- paste('^a', p, sep ="")

              for(m in 1:num_items_admin){

                for(k in 1:priors[["maxCategory"]]){

                  itemcat <- items_administered[which(items_administered$Item == unique_items_admin[m] & items_administered$Category == k),]

                  lambdaDim[p,m,k] <- itemcat[,which(grepl(patt, colnames(itemcat)) == TRUE)]

                }


              }

            }


            moddata = list(nObs = 1,
                           nItems = length(unique(items_administered[,1])),
                           mu =  mu,
                           lambdaDim = lambdaDim,
                           Y = response_vec[1:objectlengths],
                           nFactors = length(priors[["mu_theta"]]),
                           meanTheta = as.vector(unlist(desc[2])),
                           Sigma = desc[[1]],
                           Theta_Strength = priors[["Theta_Strength"]]) # define model data as specified in the rstan model syntax's data block (just like cmdstanr)



            moddata[["maxCategory"]] <- priors[["maxCategory"]]

          }

          modrun = rstan::sampling(modstan,
                                   data = moddata,
                                   chains = 4,
                                   warmup = stan.warmup,
                                   iter = stan.its,
                                   refresh = 1500) # run sampler with default settings (see rstan documentation at https://mc-stan.org/rstan/reference/stanmodel-method-sampling.html for more options, if needed)

          modsum = posterior::summarise_draws(modrun) # summarizes the posterior draws after sampling

          current_posterior_STAN = as.data.frame(modrun) # saves the posterior's draws to a data.frame object (this will be used to create a .csv file later)

          current_posterior <- posterior_reconstruction_hist(current_posterior_STAN[,c(1:2)], bins = 30, set_limits = TRUE, target_length = 900)

###========================================================== Updating posterior-dependent inputs  ==================================###

           # estimated_posterior[[objectlengths]] <- current_posterior_STAN

            #desc <- calculate_corr_means(current_posterior_STAN)

          estimated_posterior[[objectlengths]] <-  desc <- calculate_cov_means(current_posterior_STAN, method = "across")

          priors[["mu_theta"]] <- desc[[2]]
          priors[["Sigma"]] <- desc[[1]]

          objectlengths <- objectlengths + 1 #updating the element index in each list

      }


  MAT_results <- list(Bank, Person, data_type, responses, items_administered, estimated_posterior, test.info.sem, true_theta, item_selection_criterion, test_termination_criterion, priors[["Theta_Strength"]])
  names(MAT_results) <- c("Bank","Person", "Data.Type", "Responses", "Administered.Items","Estimated.Posterior.Distribution", "Test.Info.SEM" ,"True.Theta" ,"Item.Selection.Criterion", "Test.Termination.Criterion", "Prior.Strength")

  return(MAT_results)

}



##============================================================== Follow-ups

# items_for_dimension_one <- list()
# items_for_dimension_two <- list()
# items_for_both_dimensions <- list()

# if(item_to_be_administered$Dimension == "One"|item_to_be_administered$Dimension == "1"){ #For checking whether one dimension is more heavily pulled from than another
#   items_for_dimension_one[[objectlengths]] <- item_to_be_administered           }
#
# if(item_to_be_administered$Dimension == "Two"|item_to_be_administered$Dimension == "two"){
#   items_for_dimension_two[[objectlengths]] <- item_to_be_administered
# }
#
# if(item_to_be_administered$Dimension == "Both"|item_to_be_administered$Dimension == "both"){
#   items_for_both_dimensions[[objectlengths]] <- item_to_be_administered
# }

#item_exposure <- matrix()

