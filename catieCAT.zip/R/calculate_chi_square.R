chi_square <- function(contingency.table){

  contingency.table[is.na(contingency.table)] <- 0

  ct <- addmargins(contingency.table)
  row.sum <- ct[5, c(1:4)]
  col.sum <- ct[c(1:4),5]
  expected <- (col.sum %*% t(row.sum))/(ct[5,5])

 chi.val <- (contingency.table - expected)^2/expected
 chi.val[is.na(chi.val)] <- 0

 chi.val <- sum(chi.val)

 return(chi.val)

}
