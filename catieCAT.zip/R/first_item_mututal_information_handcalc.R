first_item_mututal_information_calc = function(item_parameters,
                                          latent_variable_type = "categorical",
                                          data_type = "dichotomous",
                                         item_priors){



  item_parameters = item_parameters
  item_priors <<- item_priors

 # posterior_list <- list()
  rstan::rstan_options(auto_write = TRUE)

  if(latent_variable_type == "categorical"){

    classObject <- matrix(c(0,0,1,1,0,1,0,1), nrow = 4, ncol = 2)

    if(data_type == "dichotomous"){

      b0 <- item_parameters[,2]
      b1 <- item_parameters[,3]
      b2 <- item_parameters[,4]

      # current_posterior = p(\alpha_c|_yn-1)
      # classObject == attribute profile for each class

      condLogit <- vector(length = length(current_posterior))
      condProb_1 <- vector(length = length(current_posterior))
      condProb_0 <- vector(length = length(current_posterior))


      Prob1 = matrix(NA, nrow = length(current_posterior))
      Prob0 = matrix(NA, nrow = length(current_posterior))

      for(classNum in 1:length(current_posterior)){
        condLogit[classNum] = b0+(b1*classObject[classNum,1])+(b2*classObject[classNum,2])
        condProb_1[classNum] = exp(condLogit[classNum])/(1+exp(condLogit[classNum])) #P(Y=1|a_c)
        condProb_0[classNum] = 1-condProb_1[classNum] #P(Y=0|a_c)

        Prob1[classNum] = condProb_1[classNum]*current_posterior[classNum]
        Prob0[classNum] = condProb_0[classNum]*current_posterior[classNum]
      }


      binary_response <- matrix(c(0,1), nrow = 2)
      posterior_class <- matrix(NA, nrow =classNum, ncol = length(binary_response))
      term_prod = vector(length=length(binary_response))

      score_vec <- vector()
      first_term <- vector()
      second_term <- vector(length = nrow(current_posterior))

      for(score in 1:length(binary_response)){

        if(score == 1){
          score_vec = 0
          condl_prob = condProb_0
          marg_prob <- Prob0

        } else {
          score_vec = 1
          condl_prob = condProb_1
          marg_prob <<- Prob1

        }


        posterior_given_n_and_n_minus_1 <- posteriorEstimate(response = score_vec,
                                                             item_parameters = item_parameters,
                                                             class_prior = current_posterior,
                                                             num_att = 2,
                                                             data_type = "dichotomous") #P(a_c|Y, y-1)

        for (classNum in 1:length(current_posterior)){
          second_term[classNum] <- posterior_given_n_and_n_minus_1[classNum]*log(posterior_given_n_and_n_minus_1[classNum]/current_posterior[classNum])
        }

        first_term <- marg_prob
        second_sum_over_class = sum(second_term)
        term_prod[score] = first_term*second_sum_over_class

        posterior_list[[score]] <- posterior_given_n_and_n_minus_1

      }
      MI = sum(term_prod)
    }


    ##------------------------------------------------Nominal Condition
    if(data_type == "nominal"){

      applied_ia_ic <- MI_conditional_logits_DCM(DF = item_parameters, current_posterior = current_posterior, classObject = classObject)

      marg_cat_probs <- matrix(NA, nrow = nrow(applied_ia_ic), ncol = ncol(classObject))

      for (classNum in 1:nrow(current_posterior)){
        for(u in 1:ncol(applied_ia_ic)){
          marg_cat_probs[u, classNum] = applied_ia_ic[u, classNum]*current_posterior[classNum,4]
        }
      }

      nominal_response <- matrix(c(1,2,3,4), nrow = 4)
      posterior_class <- matrix(NA, nrow =ncol(classObject), ncol = length(nominal_response))

      first_term <- vector()
      second_term <- vector()

      for(score in 1:length(nominal_response)){

        score_vec <- nominal_response[score,]
        condl_prob = applied_ia_ic[score,]
        marg_cat_probs_sum <- sum(marg_cat_probs[s,core])

        posterior_given_n_and_n_minus_1 <- posteriorEstimate(response = score_vec,
                                                             item_parameters = item_parameters,
                                                             class_prior = current_posterior,
                                                             num_att = 2,
                                                             data_type = "nominal") #P(a_c|Y, y-1)

        for (classNum in 1:length(current_posterior)){
          second_term[classNum] <- posterior_given_n_and_n_minus_1[classNum]*log(posterior_given_n_and_n_minus_1[classNum]/current_posterior[classNum])
        }

        first_term <- marg_cat_probs_sum
        second_sum_over_class = sum(second_term)
        term_prod[score] = first_term*second_sum_over_class

        posterior_list[[score]] <- posterior_given_n_and_n_minus_1

      }

      MI = sum(term_prod)
    }
  }

  ##------------------------------------------------------------------------------------------------------------

  if(latent_variable_type == "continuous"){
    if(data_type == "dichotomous"){

      ## Since we don't have set classes, creating the various combinations of theta values

      ## Creating the bins

      #dim.min <- -4
      #dim.max <- 4

      #dim.bins <- seq(from = dim.min, to = dim.max, length.out = sqrt(900))
      #dimension_combinations_ls <- expand.grid(x = dim.bins, y = dim.bins)
      #dimension_combinations <- do.call(cbind.data.frame, dimension_combinations_ls)

      quad <- do.call(cbind, mgauss.hermite(n = 30, mu = item_priors[["mu_theta"]], sigma = item_priors[["Sigma"]]))

      #current_posterior <- cbind(dimension_combinations, current_posterior_probs)

      current_posterior = as.data.frame(quad)
      colnames(current_posterior) <- c("Dim1", "Dim2", "Prob")

      condProb_1 <- apply(current_posterior[,c(1:2)], MARGIN = 1, function(x){

        M3PL(single_item_parameters = item_parameters, theta = x, return_probs = TRUE)

      })
      condProb_0 <- 1-condProb_1

      Prob1 <- sum(condProb_1*current_posterior$Prob)
      Prob0 <- sum(condProb_0*current_posterior$Prob)

      binary_response <- c(0,1)
      term_prod = vector(length=length(binary_response))

      condProb <- list(condProb_0, condProb_1)
      Prob <- list(Prob0, Prob1)

      #p_theta_given_current_posterior <-dmvnorm(x = dimension_combinations, mean = item_priors[["mu_theta"]], sigma = item_priors[["Sigma"]])

      for(score in 1:length(binary_response)){

        score_vec = as.data.frame(binary_response[score])
        condl_prob = condProb[[score]]
        marg_prob = Prob[[score]]

        if(0 %in% condl_prob){

          condl_prob[which(condl_prob == 0)] <- .Machine$double.xmin

        }

        if(0 %in% current_posterior$Prob){

          current_posterior[current_posterior$Prob == 0] <- .Machine$double.xmin

        }

        second_term <- condl_prob*log(condl_prob/current_posterior$Prob)

        first_term <- marg_prob
        second_term_sum <- sum(second_term)
        term_prod[score] <- first_term*second_term_sum

        #posterior_list[[score]] <- posterior_distribution

      }

      MI <- sum(term_prod)

    }

    if(data_type == "nominal"){

      quad <- do.call(cbind, mgauss.hermite(n = 30, mu = item_priors[["mu_theta"]], sigma = item_priors[["Sigma"]]))

      ## Creating the bins

      #dim.min <- min(quad[,1])
      #dim.max <- max(quad[,1])

      #dim.bins <- seq(from = dim.min, to = dim.max, length.out = sqrt(900))
      #dimension_combinations_ls <- expand.grid(x = dim.bins, y = dim.bins)
      #dimension_combinations <- do.call(cbind.data.frame, dimension_combinations_ls)

     # current_posterior_probs <- apply(dimension_combinations, MARGIN = 1, FUN = function(x){

     #   mvn_pdf(x, item_priors[["mu_theta"]], item_priors[["Sigma"]])

      #})

      current_posterior <- as.data.frame(quad)

      colnames(current_posterior) <- c("Dim1", "Dim2", "Prob")
      condl_cat_probs <- apply(current_posterior[,c(1:2)], MARGIN = 1, function(x){

      y <-  MNRM(single_item_parameters = item_parameters, theta = x, return_probs = TRUE)
      return(y)

      })

     # condl_cat_probs <- do.call(rbind.data.frame, condl_cat_probs)
      condl_cat_probs <- t(condl_cat_probs)

      joint_distribution = condl_cat_probs*current_posterior$Prob

      marg_cat_probs_sum <- colSums(joint_distribution)

      nominal_response <- matrix(c(1:nrow(item_parameters)), nrow = nrow(item_parameters))
      term_prod = vector(length=length(nominal_response))

      for(score in 1:length(nominal_response)){

        score_vec <- as.data.frame(nominal_response[score])
        condl_prob <- condl_cat_probs[,score]
        marg_prob <- marg_cat_probs_sum[score]

        if(0 %in% condl_prob){

          condl_prob[which(condl_prob == 0)] <- .Machine$double.xmin

        }

        if(0 %in% current_posterior$Prob){

          current_posterior[current_posterior$Prob == 0] <- .Machine$double.xmin

        }

        second_term <- condl_prob*log(condl_prob/current_posterior$Prob)

        first_term <- marg_prob
        second_term_sum = sum(second_term)
        term_prod[score] = first_term*second_term_sum

      #  posterior_list[[score]] <- condl_prob

      }

      MI = sum(term_prod)

    }
  }

  #MI_post <- list(MI, posterior_list)
  MI_post <- MI

  return(MI_post)

}

