#' D-optimality
#'
#' @param response_array vector of responses to already administered items
#' @param STANobject STAN object for current posterior obtained using a posteriorEstimate function
#' @param item_parameters Matrix containing the item parameters for the previously administered items plus the auditioned item. The last row should contain the item parameters for the auditioned item.
#' @param data_type The type of data. Takes either "dichotomous" (for 0/1 scored data) or "nominal" (for unordered data; built for series of 1,2,3,4)
#' @param alpha Uhhh I think this is to determine the volume of the ellipsoid.
#' @param p the number of latent variables
#' @return D-optimality value for the auditioned item.

D_optimality <- function(response_array,
                              STANobject,
                              item_parameters,
                              items_administered,
                              model,
                              model.file,
                              priors,
                              alpha,
                              p,
                              working_directory){


    current_posterior_hist <- posterior_reconstruction_hist(STANobject,
                                                            bins = 30,
                                                            set_limits = TRUE,
                                                            target_length = 900)

    items_administered_and_considered <- cbind(items_administered, item_parameters)

    if(model == "3PL"){

      posterior_n_n_min_1 <- run_rstan_M3PL(STAN_file = model.file,
                                            x = response_array,
                                            num_theta = 2,
                                            item_params = items_administered_and_considered,
                                            working_directory = working_directory,
                                            single_item = FALSE,
                                            priors = priors)

    }

    if(model == "MNRM"){
      posterior_n_n_min_1 <- run_rstan_MNRM(STAN_file = model.file,
                                            x = response_array,
                                            num_theta = 2,
                                            item_params = items_administered_and_considered,
                                            working_directory = working_directory,
                                            single_item = FALSE,
                                            priors = priors)
    }


    posterior_draws_summary <- posterior_n_n_min_1$summary()
    n.chains <- dim(posterior_draws)[2]

    mcmc.cov <- as.data.frame(posterior_draws_summary[which(posterior_draws_summary$variable =="theta_corr[1,2]"),2])

    var.cov_current <- cor(current_post_hist[,c(1:2)])
    var.cov_proposed <- matrix(c(1,mcmc.cov,mcmc.cov,1), nrow = 2, ncol = 2)

    one_minus_alpha <- 1- alpha
    chisq_p_alpha <- qchisq(one_minus_alpha, df =p) #chisq for alpha = .05 and p = 2 is 5.991

    numerator <- ((2*pi)^(p/2)) #in Segall's formula, p = num dimensions

    gamma.input <-0.5*p

    denom <- (p*factorial(gamma.input-1)) #factorial(gamma.input-1) = gamma function

    ksi <- numerator/denom #volume of the multivariate ellipsoid

    W_current <- ksi*det(var.cov_current)^(0.5)
    W_proposed <- ksi*det(var.cov_proposed)^(0.5)

    D_optim <- W_current - W_proposed

  return(D_optim)

} #end bracket
