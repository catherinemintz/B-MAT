posteriorEstimate_M3PL_individual <- function(x, num_theta,
                                                           item_params,
                                                         working_directory,
                                                          priors = list(
                                                            mu_theta = c(0,0),
                                                            #sigma_theta = c(1,1),
                                                            lkj_theta=1, #for correlation matrix
                                                          sigma_theta_corr = rep(1,num_theta))){


  ## CATIE: NEED TO CONSTRAIN THETA CORRELATION

  a1 <- item_params[,3]
  a2 <- item_params[,4]
  guess <- item_params[,5]
  diff <- item_params[,2]

  y1 <- t(rbind(item_params[,1], x))

  stanData <- list(D=num_theta,
                   I=max(y1[,1]),
                   a1=a1,
                   a2 = a2,
                   diff = diff,
                   guess = guess,
                   Y=y1[,2], #begin specifying priors
                   lkj_theta= priors[["lkj_theta"]], #for correlation matrix
                   sigma_theta_corr = priors[["sigma_theta_corr"]],
                 #  theta_corr_input = priors[["theta_corr_input"]],
                   mu_theta = priors[["mu_theta"]]
                  #sigma_theta = priors[["sigma_theta"]]
                 )


model.file <- "
data{
     int<lower=1> D;  // number of latent dimensions
     int<lower=1> I;  // number of items
     int<lower=0> Y[I];
     vector<lower=0>[I] a1; // discrim parms for trait 1
     vector<lower=0>[I] a2; // discrim parms for trait 2
     vector[I] diff;
     vector<lower=0, upper=1>[I] guess;
     //int<lower=-1,upper=1> theta_corr_input;
    row_vector [D] mu_theta;
    //row_vector [D] sigma_theta;

  //User-specified priors
  real lkj_theta;
  row_vector [D] sigma_theta_corr; //will need to be fixed to 1
}


  transformed data{

 // corr_matrix[D] theta_corr;
  //theta_corr[1,1] = 1;
  //theta_corr[2,2] = theta_corr[1,1];
  //theta_corr[1,2] = theta_corr_input;
  //theta_corr[2,1] =   theta_corr[1,2];

//row_vector [D] mu_theta = rep_row_vector(0.0, D);
  row_vector [D] sigma_theta = rep_row_vector(1.0, D);

}


 parameters {
     vector [D] theta;
  //row_vector [D] sigma_theta;
    corr_matrix[D] theta_corr;
   }

transformed parameters {
    cov_matrix[D] Sigma_theta_cov;
    Sigma_theta_cov = quad_form_diag(theta_corr, sigma_theta_corr);

   }

   model{


    target += lkj_corr_lpdf(theta_corr | lkj_theta);
    target += multi_normal_lpdf(theta | mu_theta, quad_form_diag(theta_corr, sigma_theta)); //is this right?

  for(i in 1:I){
      real y_ = inv_logit(a1[i] .* theta[1] + a2[i] .* theta[2] + diff[i]);

	  	//target += bernoulli_logit_lpmf(Y[n] | y_);
        Y[i] ~ bernoulli_logit(guess[i]+(1-guess[i])*y_);
      }
   }


"


path_name <- paste(working_directory,"model.stan", sep="/")

fileConn <-file(path_name)
writeLines(model.file, fileConn)
close(fileConn)

file <- file.path(path_name)

m3PL_file <- cmdstan_model(file)

m3PL_mcmc <- m3PL_file$sample(
  data = stanData,
  chains = 4,
  parallel_chains = 4,
  iter_warmup = 5000,
  iter_sampling = 10000,
  show_messages = TRUE)


model_params <- m3PL_mcmc$summary()

return(list(model_params = model_params, stanObject = m3PL_mcmc))

}

###===========
# #
# sim_items <- as.data.frame(dichotomous_response_parameters(9, 2, TRUE, latent_variable_type = "continuous", TRUE))
#
# #Simulating item responses for an individual with latent variable 1 = 0 and latent variable 2 = 0
# sim_responses <- vector(length=nrow(sim_items))
#
# N = 1
# theta = cbind(rnorm(N), rnorm(N))
# data = matrix(data = NA, nrow = N, ncol = length(sim_responses))
# for (p in 1:N){
#   for(i in 1:length(sim_responses)){
#     sim_responses[i] <- M3PL(single_item_parameters = sim_items[i,], theta = theta[p,], return_probs = FALSE)
#   }
#   data[p, ] = sim_responses
# }
#
# BITCHIDIDIT <- posteriorEstimate_M3PL_individual(x = data,
#                                              num_theta = 2,
#                                              item_params = sim_items,
#                                              working_directory = getwd(),
#                                              priors = list(lkj_theta=1, #for correlation matrix
#                                               mu_theta = c(0,0),
#                                               sigma_theta_corr = rep(1,num_theta)))
