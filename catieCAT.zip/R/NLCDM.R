#' Item probability under the Nominal Log-linear Cognitive Diagnostic Model
#'
#' @param single_item_parameters Vector of item parameters. Assumes two attributes and no interaction
#' @param latent_class Vector containing the latent class for an individual, with each element corresponding to the absence or presence of an attribute
#' @return_probs If true, returns the probability of each item category. Otherwise, returns the category score with the highest probability
#' @return Probability of answering the item correctly given the individual's latent class


NLCDM <- function(single_item_parameters, latent_class, return_probs = FALSE){

  score <- 0
  r_vec <- c(1,2,3,4)

  cat_logit <- matrix(NA, nrow = length(r_vec))
  cat_prob <- matrix(NA, nrow = length(r_vec))

  b0 <- single_item_parameters[,2]
  b1 <- single_item_parameters[,3]
  b2 <- single_item_parameters[,4]

  for(cat in 1:length(r_vec)){
    cat_logit[cat] = exp(b0[cat]+(b1[cat]*latent_class[1])+(b2[cat]*latent_class[2]))/(1+exp(b0[cat]+(b1[cat]*latent_class[1])+(b2[cat]*latent_class[2])))
    cat_prob[cat] = cat_logit[cat]/(1+cat_logit[cat])
  }

  if(return_probs == TRUE){

    return(cat_prob)

  } else {

    return(which.max(cat_prob))

  }
}



