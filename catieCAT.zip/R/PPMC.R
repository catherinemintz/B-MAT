PPMC <- function(STANobject, oldresponses){

  # Cleaning STANobject
  ## Result is a list of Item x Person DF; each list element corresponds to one replication

    STAN_newresponses <- as.data.frame(extract(STANobject, pars = "Y_rep", permuted = TRUE)$Y_rep)

    newresp_split <- split(STAN_newresponses, seq(nrow(STAN_newresponses)))
    newresp_apply <- lapply(newresp_split, function(x){

      x_t <- as.data.frame(t(x))
      colnames(x_t) <- "Y"
      x_t$Person <- sub('.*\\.', '',  rownames(x_t))
      x_t$Item <- sub("\\..*", "",  rownames(x_t))

      x_df <- reshape(x_t, idvar = "Person", timevar = "Item", direction = "wide")
      x_df2 <- x_df[,-c(1)]

      return(x_df2)

    })

  # Calculating Chi-square values on model-generated data

    chi_apply <- lapply(newresp_apply, function(x){

      new_chi <- as.data.frame(apply(combn(1:ncol(x), 2), 2, function(ind){

        chisq.test(x[, ind[1]], x[, ind[2]])$statistic  }))

      colnames(new_chi) <- "ChiSquare"


      new_chi$ItemPairId <- paste(combn(1:ncol(x), 2)[1,],"_" , combn(1:ncol(x), 2)[2,], sep ="")
      new_chi$DF <- "New"
     new_chi$PPV <- NA

      return(new_chi)

})


  # Calculating Chi-square values on observed data

     old_chi <- as.data.frame(apply(combn(1:ncol(oldresponses), 2), 2, function(ind){

       chisq.test(oldresponses[, ind[1]], oldresponses[, ind[2]])$statistic  }))

     colnames(old_chi) <- "ChiSquare"

     old_chi$ItemPairId <- paste(combn(1:ncol(oldresponses), 2)[1,],"_" , combn(1:ncol(oldresponses), 2)[2,], sep ="")

     old_chi$DF <- "Old"

     old_chi$PPV <- NA

  # Comparing Chi-square values


     chi_combine <- do.call(rbind.data.frame, chi_apply)
     chi_combine_both <- rbind(chi_combine, old_chi)

     chi_split <- split(chi_combine_both, chi_combine$ItemPairId)

     chi_results_list <- lapply(chi_split, function(x){

       z <- x$ChiSquare[x$DF == "Old"]

       x$PPV[x$ChiSquare > z] <- 1
       x$PPV[x$ChiSquare <= z] <- 0

       y <- x[which(x$DF == "New"),]

       PPV_sum <- sum(x$PPV)/nrow(x)

       PPV_results <- data.frame(matrix(c(unique(x$ItemPairId)[1], PPV_sum), ncol = 2))

       return(PPV_results)


     })

     chi_results <- do.call(rbind.data.frame, chi_results_list)

     colnames(chi_results) <- c("ItemPairId", "PPV")

     return(chi_results)

}
