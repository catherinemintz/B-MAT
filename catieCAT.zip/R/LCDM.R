#' Item probability under the Log-linear Cognitive Diagnostic Model
#'
#' @param single_item_parameters Vector of item parameters. Assumes two attributes and no interaction
#' @param latent_class Vector containing the latent class for an individual, with each element corresponding to the absence or presence of an attribute
#' @return Probability of answering the item correctly given the individual's latent class

LCDM <- function(single_item_parameters, latent_class){

  score <- 0

  #current_class <- classObject[index_class,]  #use that index to classObject

  logit <- exp(single_item_parameters[[2]]+(single_item_parameters[[3]]*latent_class[1])+(single_item_parameters[[4]]*latent_class[2]))
  prob <- logit/(1+logit)

  if(prob > 0.5){
    score <- 1
  } else {
    score <- 0
  }


  return(score)

}
