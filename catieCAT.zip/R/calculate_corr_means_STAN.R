calculate_corr_means_STAN <- function(STANobject){

  thetaobject_0 <- STANobject$draws("theta")

  thetaobject = NULL
  for (chain in 1:dim(thetaobject_0)[2]){
    thetaobject = rbind(thetaobject, cbind(as.numeric(thetaobject_0[, chain,1]), as.numeric(thetaobject_0[, chain,2])))
  }
  theta_corr_mat <- cor(thetaobject)
  theta_corr <- theta_corr_mat[1,2]
  means <- colMeans(thetaobject)

  return(list(theta_corr,means))

}
