#' Item category probabilities under the MNRM
#'
#' @param single_item_parameters Vector of item parameters. Assumes two latent variables.
#' @param thetas Vector containing the theta values for an individual
#' @return_probs If true, returns the probability of each item category. Otherwise, returns the category score with the highest probability
#' @return Probability of answering the item correctly given the individual's theta values

MNRM <- function(single_item_parameters, thetas, return_probs = FALSE){

  z <- as.data.frame(matrix(NA, nrow = 1, ncol = nrow(single_item_parameters)))

  probs <- as.data.frame(matrix(NA, nrow = 1, ncol = nrow(single_item_parameters)))

  z <- exp((single_item_parameters$a1*thetas[[1]])+(single_item_parameters$a2*thetas[[2]])+single_item_parameters$d)

  z.sum <- sum(z)
  probs <- z/z.sum

  if(return_probs == TRUE){

    return(probs)

  } else {

    return(sample(x = 1:length(probs), size = 1, prob = probs)) #to introduce randomness
    #return(which.max(probs))

  }
}



##-----------------------------------  Unhelpful code
#
#
#   item.cats <- split(item.parameters, item.parameters$Category) #split
#
#       f <- function(x){     #to select within the list
#         y <- x[,4:length(x)]
#         return(y)
#       }
#
#      # A <- lapply(item.cats, f)
#     #  As <- data.frame(matrix(unlist(A), nrow=length(A), byrow=T))
#
#
#      logit.function <- function(x,p){
#
#        for(i in 4:length(x)){
#          for(n in 1:ncol(p)){
#            as <- x[i]*p[n]
#          }
#        }
#        z <- rowsum(as)+x$c
#
#        return(z)
#      }
#
#      logit <- logit.function(x = item.cats, p = persons)
#
#   logit.combined <- do.call("rbind", logit) #combine
#
#   p <- sapply(logit.combined, logit.combined/sum(logit.combined))
#
#   return(p)
#
# }
#
# ir <- nominal_response_parameters(1, 4, 2, seed = T)
# dat <- MNRM(ir, persons)
