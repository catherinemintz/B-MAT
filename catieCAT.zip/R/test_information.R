# nominal_p <- nominal_response_parameters(1,4,2, set.zero = TRUE)
# dich_p <- dichotomous_response_parameters(1,2,TRUE)
# theta.val <- list(matrix(c(1,0.5,0.5,1), nrow = 2), c(0,0))
#
# testobj <- test_information(dich_p, model = "M3PL", item.info = TRUE)


test_information <- function(item_parameters, model, theta.val, item.info = FALSE){

  if(item.info == TRUE){

    if(model == "M3PL"){

        P.0 <- M3PL(single_item_parameters = item_parameters, theta = theta.val[[2]], return_probs = TRUE)
        Q.0 <- 1-P.0

        multiplier <- (Q.0*(P.0-item_parameters$c)^2)/(P.0*(1-item_parameters$c))
        disc.matrix <- matrix(c(item_parameters$a1^2,
                                item_parameters$a1*item_parameters$a2,
                                item_parameters$a1*item_parameters$a2,
                                item_parameters$a2^2), nrow = 2)

        test.info = (drop(multiplier)*disc.matrix)+(solve(theta.val[[1]]))

      tryCatch({test.sem <- solve(test.info)},
               error = function(cond){message(paste("Information Matrix is Singular"))
                 test.sem <<- matrix(NA, nrow = nrow(test.info), ncol = ncol(test.info))})

      test.objects <- list(test.info, test.sem)

     }

    if(model == "MNRM"){

      P.0 <- MNRM(single_item_parameters = item_parameters, theta = theta.val[[2]], return_probs = TRUE)

      Ri.1 <- list()
      Ri.2 <- matrix(NA, nrow = nrow(item_parameters), ncol = length(theta.val[[2]]))
      Ri.3 <- t(Ri.2)

      disc <- as.matrix(item_parameters[grepl("^a", colnames(item_parameters))])

      for(i in 1:nrow(item_parameters)){

        disc.vec <- as.vector(disc[i,])

        Ri.1[[i]] <- (disc.vec%*%t(disc.vec)*drop(P.0[i]))
        Ri.2[i,] <- disc.vec*drop(P.0[i])
        Ri.3[,i] <- t(Ri.2[i,])

      }

      sum.Ri.1 <- -1*Reduce("+", Ri.1)
      sum.Ri.2 <- as.matrix(colSums(Ri.2))              #  2x1 vector
      sum.Ri.3 <- t(rowSums(Ri.3))                      #  2x1 vector

      test.info <- -1*(sum.Ri.1+(sum.Ri.2%*%sum.Ri.3)-(solve(theta.val[[1]])))

        tryCatch({test.sem <- solve(test.info)},
                 error = function(cond){message(paste("Information Matrix is Singular"))
                   test.sem <<- matrix(NA, nrow = nrow(test.info), ncol = ncol(test.info))})


    #  item.sem <- solve(item.information)

      test.objects <- list(test.info, test.sem)
    }


  } else {

    item.split <- split(item_parameters, item_parameters$Item)

    if(model == "M3PL"){

      item.lapply <- lapply(item.split, function(x){

        P.0 <- M3PL(single_item_parameters = x, theta = theta.val[[2]], return_probs = TRUE)
        Q.0 <- 1-P.0

        multiplier <- (Q.0*(P.0-x$c)^2)/(P.0*(1-x$c))
        disc.matrix <- matrix(c(x$a1^2,
                                x$a1*x$a2,
                                x$a1*x$a2,
                                x$a2^2), nrow = 2)

        item.information = (multiplier*disc.matrix)+(solve(theta.val[[1]]))

        return(item.information)

      })

      test.info <- Reduce("+", item.lapply)


      tryCatch({test.sem <- solve(test.info)},
               error = function(cond){message(paste("Information Matrix is Singular"))
                 test.sem <<- matrix(NA, nrow = nrow(test.info), ncol = ncol(test.info))})

  #    test.sem <- solve(test.info)

      test.objects <- list(test.info, test.sem)

    }

    if(model == "MNRM"){

      item.lapply <- lapply(item.split, function(x){

        P.0 <- MNRM(single_item_parameters = item_parameters, theta = theta.val[[2]], return_probs = TRUE)

        Ri.1 <- list()
        Ri.2 <- matrix(NA, nrow = nrow(item_parameters), ncol = length(theta.val[[2]]))
        Ri.3 <- t(Ri.2)

        disc <- as.matrix(item_parameters[grepl("^a", colnames(item_parameters))])

        for(i in 1:nrow(item_parameters)){

          disc.vec <- as.vector(disc[i,])

          Ri.1[[i]] <- (disc.vec%*%t(disc.vec)*drop(P.0[i]))
          Ri.2[i,] <- disc.vec*drop(P.0[i])
          Ri.3[,i] <- t(Ri.2[i,])

        }

        sum.Ri.1 <- -1*Reduce("+", Ri.1)
        sum.Ri.2 <- as.matrix(colSums(Ri.2))              #  2x1 vector
        sum.Ri.3 <- t(rowSums(Ri.3))                      #  2x1 vector

        item.information <- -1*(sum.Ri.1+(sum.Ri.2%*%sum.Ri.3)-(solve(theta.val[[1]])))

        return(item.information)

      })

      test.info <- Reduce("+", item.lapply)

      tryCatch({test.sem <- solve(test.info)},
               error = function(cond){message(paste("Information Matrix is Singular"))
                 test.sem <<- matrix(NA, nrow = nrow(test.info), ncol = ncol(test.info))})

      test.objects <- list(test.info, test.sem)
    }

  }

  return(test.objects)

}
