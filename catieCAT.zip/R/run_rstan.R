run_rstan <- function(STAN_file,
                                      x,
                                      num_theta,
                                      item_params,
                                      item_priors){

  rstan::rstan_options(auto_write = TRUE)

  STAN_file <<- STAN_file
  item_priors <<- item_priors

  modcode = readr::read_file(STAN_file)

  modstan = rstan::stan_model(model_code = modcode) # compile stan model


  if("maxCategory" %!in% names(item_priors)){

    moddata = list(nItems = length(unique(item_params[,1])),
                   #mu = item_priors[["mu"]],
                   #lambdaDim = item_priors[["lambdaDim"]],
                   #guess = item_priors[["guess"]],
                   mu = as.array(item_params[,which(grepl('^d', colnames(item_params)) == TRUE)]),
                   lambdaDim = t(as.matrix(item_params[,which(grepl('^a', colnames(item_params)) == TRUE)])),
                   guess = as.array(item_params[,which(grepl('^c', colnames(item_params)) == TRUE)]),
                   Y = x,
                   nFactors = length(item_priors[["mu_theta"]]),
                   meanTheta = item_priors[["mu_theta"]],
                   Sigma = item_priors[["Sigma"]],
                   #Sigma_Strength = item_priors[["Sigma_Strength"]],
                   Theta_Strength = item_priors[["Theta_Strength"]]) # define model data as specified in the rstan model syntax's data block (just like cmdstanr)

  } else {

    moddata = list(nObs = 1,
                   maxCategory = item_priors[["maxCategory"]],
                   nItems = length(unique(item_params[,1])),
                   #Qmatrix = item_priors[["Qmatrix"]],
                   #mu = as.array(item_params[,which(grepl('^d', colnames(item_params)) == TRUE)]),
                   #lambdaDim = t(as.matrix(item_params[,which(grepl('^a', colnames(item_params)) == TRUE)])),
                   mu = item_priors[["mu"]],
                   lambdaDim = item_priors[["lambdaDim"]],
                   Y = x,
                   nFactors = length(item_priors[["mu_theta"]]),
                   meanTheta = item_priors[["mu_theta"]],
                   Sigma = item_priors[["Sigma"]],
                  # Sigma_Strength = item_priors[["Sigma_Strength"]],
                   Theta_Strength = item_priors[["Theta_Strength"]]) # define model data as specified in the rstan model syntax's data block (just like cmdstanr)

  }

  if(is.null(dim(moddata[["Y"]]))){

    moddata[["Y"]] <- as.matrix(moddata[["Y"]])

  }

  initfunc <- function(chain_id = 1) {
    # cat("chain_id =", chain_id, "\n")
    list(theta = runif(length(item_priors[["mu_theta"]]), -6, 6))
  }

  n_chains <- 4
  init_ll <- lapply(1:n_chains, function(id) initfunc(chain_id = id))

  modrun = rstan::sampling(modstan,
                    data = moddata,
                    chains = n_chains,
                    warmup = 400,
                    iter = 500,
                    #thin = 50,
                    init = init_ll,
                    # open_progress = TRUE,
                    refresh = 50) # run sampler with default settings (see rstan documentation at https://mc-stan.org/rstan/reference/stanmodel-method-sampling.html for more options, if needed)

  modsum = posterior::summarise_draws(modrun) # summarizes the posterior draws after sampling

  current_posterior_STAN = as.data.frame(modrun) # saves the posterior's draws to a data.frame object (this will be used to create a .csv file later)


    return(current_posterior_STAN)

}
