#' Generates simulated item parameters for nominal data
#'
#' @param items Desired number of simulated items
#' @param categories Desired number of item categories per item
#' @param dimensions Desired number of dimensions
#' @param latent.variable.type The distribution type of the latent variable(s). Takes either "continuous" or "categorical" as input
#' @param seed Whether to set a seed for results
#' @return Matrix of item parameters, with columns corresponding to Question ID, item category, item discrimination(s), and item difficulty/difficulties.

nominal_response_parameters <- function(items, categories, dimensions,set.zero = FALSE, latent_variable_type = "continuous", seed = FALSE){

  if(seed == TRUE){
    set.seed(9252020)
  }

  maxCat = categories

  nominal.items <- list()
  tparam <- dimensions + 3 # discriminations per dimension, difficulty column, categeory descriptor, & item #

  for(n in 1:items){

    num = n

    item.parameters <- as.data.frame(matrix(NA, nrow = categories, ncol = tparam))

    if(latent_variable_type == "continuous"){

        colnames(item.parameters) <- c( "Item", "Category","d", paste("a", 1:dimensions, sep = ""))
        item.parameters$Item <- rep(num, categories)


        # Item category difficulties

       # difficulties <- runif(n= categories, min = -4, max = 4) #Changed from -3 to 3

          seq.range <- abs(-3-3)/categories
          diff.seq <- seq(-3,3, by = seq.range)

          difficulties <- vector()

          for(i in 1:categories){

            difficulties[i] <- runif(1, min = diff.seq[i], max = diff.seq[i+1])

          }


       # difficulties <- runif(n= categories, min = -3, max = 3)
        difficulties <- sort(difficulties)

        item.parameters$d <- difficulties #adding difficulties to item parameter df
        item.parameters$Category <- c(1:categories)

        # Item category discriminations

        disc <- matrix(NA, nrow = categories, ncol = dimensions)

        for(j in 1:ncol(disc)){
          for(i in 1:nrow(item.parameters)){

            if(item.parameters$Category[i] == 1){
              if(item.parameters$d[i] <= -3){
               # disc[i,j] <- runif(1, min = -1, max = 0) #changed from -1 to -0.5,
                disc[i,j] <- runif(1, min = -1, max = -0.5)
              } else{
                disc[i,j] <- runif(1, min = -2, max = -1)
              }
            }

            if(item.parameters$Category[i] == maxCat){
              if(item.parameters$d[i] >= 3){
                #disc[i,j] <- runif(1, min = 0, max = 1)  #changed from 0 to -1
                disc[i,j] <- runif(1, min = 0.5, max = 1)
              } else{
                disc[i,j] <- runif(1, min = 1, max = 2)
              }
            }

            else{

              disc[i,j] = runif(1, min = -2, max = 0) #changed from -1 to -0.5
              #disc[i,j] = runif(1, min = -1, max = -0.5)
            }

          }

          if(set.zero == TRUE){
            disc[i,j] <- disc[i,j]-disc[categories,j]
          }

        }

        if(set.zero == TRUE){

          item.parameters$d <- item.parameters$d-item.parameters$d[categories]
        }

        item.parameters[, 4:ncol(item.parameters)] <- disc

     }

    if(latent_variable_type == "dichotomous"){

      colnames(item.parameters) <- c( "Item", "Category","B0", paste("B", 1:dimensions, sep = ""))
      item.parameters$Item <- rep(num, categories)

      difficulties <- runif(n= categories, min = -1, max = 1)   # Item category difficulties
      difficulties <- sort(difficulties)

      item.parameters$B0 <- difficulties #adding difficulties to item parameter df
      item.parameters$Category <- c(1:categories)


      disc <- matrix(NA, nrow = categories, ncol = dimensions) # Item category discriminations

      for(j in 1:ncol(disc)){
        for(i in 1:nrow(item.parameters)){  #if the keyed response

          if(item.parameters$Category[i] == maxCat){
             disc[i,j] <- runif(1, min = 0, max = 2)
            } else{
              disc[i,j] <- runif(1, min = -1, max = -0.5)
            }
        }

        if(set.zero == TRUE){
          disc[i,j] <- disc[i,j]-disc[categories,j]
        }

      }

      if(set.zero == TRUE){

        item.parameters$B0 <- item.parameters$d-item.parameters$B0[categories]
      }

      item.parameters[, 4:ncol(item.parameters)] <- disc

    }


    nominal.items[[length(nominal.items)+1]] = item.parameters
  }

  nominal.items <- do.call(rbind.data.frame, nominal.items)

  return(nominal.items)
}



##===================

# prac_nom <- nominal_response_parameters(items = 4, categories = 4, latent.variable.type = "continuous", dimensions = 2, seed = TRUE)
# prac_nom_single <- nominal_response_parameters(items = 6, categories = 4, latent.variable.type = "continuous", dimensions = 1, seed = TRUE)
# prac_nom_single$a2 <- 0
#
# for(i in 1:nrow(prac_nom_single)){
#   if(prac_nom_single[i,1] >= 4){
#     prac_nom_single$a2[i] <- prac_nom_single$a1[i]
#     prac_nom_single$a1[i] <- 0
#   }
# }
#
# prac_nom <- rbind(prac_nom, prac_nom_single)
#

