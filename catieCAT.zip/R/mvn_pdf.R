mvn_pdf <- function(x, mu, Sigma){

 density <- ((1/(2*pi))^(length(x)/2))*(det(Sigma)^-0.5)*(exp(-0.5*(t(x-mu)%*%solve(Sigma)%*%(x-mu))))

 return(density)

}

#mvn_pdf(c(1,1), c(0,0), matrix(c(1,0.5, 0.5,1), nrow = 2))

#f = apply(dimension_combinations, MARGIN = 1, FUN = function(x){

#  mvn_pdf(x, c(0,0), matrix(c(1,0.5, 0.5,1), nrow = 2))

#})

#all.equal(f, current_posterior_probs, check.attributes = FALSE)
