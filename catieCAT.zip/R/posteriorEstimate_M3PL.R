#' Obtain the posterior distribution for a single individual under the two-dimensional M3PL
#'
#'  @param response_array_and_score_vec A vector of item responses
#'  @param item_parameters An item x item parameters matrix
#'  @param curent_posterior_jags JAGS object for the current posterior, if applicable
#'  @param prior_strength Integer specifying the strength of the prior for theta (lower values = stricter priors)
#'  @return posterior distribution of the individual's theta values

posteriorEstimate_M3PL_old <- function(response_array_and_score_vec, item_parameters, curent_posterior_jags, prior_strength){

  discrims <- item_parameters[,3:4] #make sure these are the right columns

  model.function = function(){
    # measurement model specification
    for(item in 1:I){
      X[item] ~ dbern(c[item]+((1-c[item])*phi(mu[item] + lambda[item,1]*theta[1] + lambda[item,2]*theta[2])))
    }

    theta[1:2] ~ dmnorm(kappa[1:2], inv.phi[1:2,1:2])
    kappa <- current_posterior_jags[["BUGSoutput"]][["mean"]][["theta"]]
    theta.cov[1:2,1:2] <- current_posterior_jags[["BUGSoutput"]][["mean"]][["theta.cov"]]

    for(item in 1:I){
      mu[item] <- itemparams[item,2] #make sure these are on the right scale
    }

    for(item in 1:I){
      c[item] <- itemparams[item,5] #make sure these are on the right scale
    }

    for(item in 1:I){
      for(t in 1:2){
        lambda[item,t] <- discrims[item,t] #make sure these are also on the right scale
      }
    }

  }

  # specification of prior values for measurement model parameters:

  theta.cov.0 = diag(2)
  theta.invcov.0 = solve(theta.cov.0)
  theta.invcov.df.0 = prior_strength

  # next, create data for JAGS to use:
  model.data = list(
    X = response_array_and_score_vec,
    I = length(response_array_and_score_vec),
    itemparams = item_parameters,
    discrims = discrims,
    theta.invcov.0 = theta.invcov.0,
    theta.invcov.df.0 = theta.invcov.df.0)

  model.parameters = c("theta.cov", "theta")

  model.seed = 06042019

  model.r2jags =  jags.parallel(
    data = model.data,
    parameters.to.save = model.parameters,
    model.file = model.function,
    n.chains = 4,
    n.iter = 5000,
    n.thin = 5,
    n.burnin = 4000,
    n.cluster = 4,
    jags.seed = model.seed
  )

  return(model.r2jags)

}
