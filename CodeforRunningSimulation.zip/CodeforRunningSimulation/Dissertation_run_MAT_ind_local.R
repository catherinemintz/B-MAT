
#myArgs = commandArgs(trailingOnly = TRUE) #this will have all the specified arguments

#save(myArgs, file = paste("/Users/mathers/Dissertation/myArgs_", iteration, ".RData", sep = ""))

#save(myArgs, file = paste("/Users/mathers/Dissertation/myArgs_", ".RData", sep = ""))

options(scipen=999)

model = "MNRM"
itemselect = "Dopt"
testterm = 40
priorstrength = 10

if(itemselect == "MI"){
  
  itemselect <- "Mutual Information"
  
}

if(itemselect == "Dopt"){
  
  itemselect <- "D-Optimality"
  
}

#save(myArgs, file = paste("/Users/mathers/Dissertation/myArgs_", iteration, ".RData", sep = ""))


####========================================================================== Reading in necessary functions and packages ####

library("MASS")
library("reshape2")
library("gtools")
#library("data.table")
#library("rstan")

for(i in 1:length(list.files(path = "~/hpchome/catieCAT/R"))){
  
  file <- paste("~/hpchome/catieCAT/R/", list.files(path = "~/hpchome/catieCAT/R")[i], sep="")
  
  source(file, encoding="utf-8")
}



for(iteration in 1:10000){
  
# set random number seed
  seed = 0813 + iteration
  set.seed(seed = seed)
  
####========================================================================== Reading in data ####
  
  conditions <- as.data.frame(expand.grid(c(1:100), c(1:100)))
  colnames(conditions) <- c("Person", "Bank")
  conditions$Iteration <- 1:nrow(conditions)
  
  cond = conditions[which(conditions$Iteration == iteration),]
  Person = cond$Person
  Bank = cond$Bank
  
  load(file = paste("~/LSS/lss_jtemplin/Mintz/Dissertation/Generating_Parameters/Iteration_", Bank, ".RData", sep=""))
  
  if(model == "MNRM"){
    
    load(file = paste("~/LSS/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/", model, "/", "Iteration_", Bank, ".RData", sep=""))
    
  }
  
  if(model == "M3PL"){
    
    load(file = paste("~/LSS/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/", model, "/mirt/", model, "_Item_Bank_", Bank, ".RData", sep=""))
    
  }
  
  
  ####========================================================================== Running the MATs across the conditions (2 termination, 2 selection, 3 Bayesian) ####
  
  #wd <- "/Users/mathers/stan_models/" #where the model text exists
  wd <- "~/hpchome/stan_models/" #for local
  
  #conditions_list_dich <- list(c(20,40), c("Mutual Information", "D-Optimality"), c(10,1000,1000000), c("dichotomous"), list(dichotomous_item_bank), paste(wd, "m3pl_fi_fc_syntax.txt", sep =""), paste(wd, "m3pl_fi_fc_syntax_first.txt", sep =""))
  #conditions_list_nom <- list(c(20,40), c("Mutual Information", "D-Optimality"), c(10,1000,1000000), c("nominal"), list(nominal_item_bank), paste(wd, "mnrm_fi_fc_syntax.txt", sep =""), paste(wd, "mnrm_fi_fc_syntax_first.txt", sep =""))
  
  
  if(model == "M3PL"){
    
    colnames(item_bank) <- c("Item", "d", "a1","a2", "c") 
    
    x = sim_examinees_split[[Person]]
    
    person.cond <- MAT(item_pool = item_bank,
                       item_selection_criterion = itemselect,
                       test_termination_criterion = testterm,
                       data_type = "dichotomous",
                       true_theta = x,
                       priors = list(
                         mu_theta = c(0,0),
                         Sigma=matrix(c(1,0.5, 0.5,1), nrow = 2),
                         Sigma_Strength = priorstrength,
                         Theta_Strength= priorstrength), #for correlation matrix
                       working_directory = wd,
                       model_text_file = paste(wd, "m3pl_fi_fc_syntax.txt", sep =""),
                       first_item_text_file = paste(wd, "m3pl_fi_fc_syntax_first.txt", sep =""),
                       Bank = Bank,
                       Person = Person,
                       stan.its = 2000)
    
  }
  
  if(model == "MNRM"){
    
    item_bank = sim_items_nom
    
    colnames(item_bank) <- c("Item", "Category", "d", "a1","a2") 
    
    x = sim_examinees_split[[Person]]
    
    person.cond <- MAT(item_pool = item_bank,
                       item_selection_criterion = itemselect,
                       test_termination_criterion = 6,
                       data_type = "nominal",
                       true_theta = x,
                       priors = list(
                         maxCategory = 4,
                         mu_theta = c(0,0),
                         Sigma=matrix(c(1,0.5, 0.5,1), nrow = 2),
                         Sigma_Strength = priorstrength,
                         Theta_Strength= priorstrength), #for correlation matrix
                       working_directory = wd,
                       model_text_file = paste(wd, "mnrm_fi_fc_syntax.txt", sep =""),
                       first_item_text_file = paste(wd, "mnrm_fi_fc_syntax_first.txt", sep =""),
                       Bank = Bank,
                       Person = Person, 
                       stan.its = 2000)
    
    person.cond_MI <- MAT_MI(item_pool = item_bank,
                       item_selection_criterion = itemselect,
                       test_termination_criterion = 6,
                       data_type = "nominal",
                       true_theta = x,
                       priors = list(
                         maxCategory = 4,
                         mu_theta = c(0,0),
                         Sigma=matrix(c(1,0.5, 0.5,1), nrow = 2),
                         Sigma_Strength = priorstrength,
                         Theta_Strength= priorstrength), #for correlation matrix
                       working_directory = wd,
                       model_text_file = paste(wd, "mnrm_fi_fc_syntax.txt", sep =""),
                       first_item_text_file = paste(wd, "mnrm_fi_fc_syntax_first.txt", sep =""),
                       Bank = Bank,
                       Person = Person, 
                       stan.its = 2000)
    
  }
  
  #assign(paste("Condition", Bank, Person, model, itemselect, testterm, priorstrength, sep = "_"), person.cond)
  
  save(x = person.cond, file = paste("~/LSS/lss_jtemplin/Mintz/Dissertation/MAT_Results/", itemselect,"_",testterm, "_", priorstrength, "/", model, "/", model, "_Bank_", Bank, "_Person_", Person, ".RData", sep=""))
  
}