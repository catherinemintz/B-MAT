#' Generates simulated item parameters for dichotomously-scored data
#'
#' @param items Desired number of simulated items
#' @param dimensions Desired number of dimensions
#' @param guessing Whether to generate a guessing parameter
#' @param latent_variable_type The distribution type of the latent variable(s). Takes either "continuous" or "categorical" as input
#' @param seed Whether to set a seed for results
#' @return Matrix of item parameters, with columns corresponding to Question ID, item discrimination(s), and item difficulty/difficulties. Does not generate a guessing parameter.

dichotomous_response_parameters <- function(items, dimensions, guessing = FALSE, latent_variable_type = "continuous", seed = FALSE){

  if(seed == TRUE){
    set.seed(9252020)
  }

  if(guessing == TRUE & latent_variable_type == "categorical"){
    print("ERROR: Function not programmed for DCMs with guessing parameters")
  }

  dichotomous.items <- list()


  if(guessing == TRUE){

    tparam <- dimensions + 3 # discriminations per dimension, difficulty column, guessing column, & item #

  } else {

    tparam <- dimensions + 2 # discriminations per dimension, difficulty column, & item #

  }


  for(n in 1:items){

    num = n

    item.parameters <- as.data.frame(matrix(NA, ncol = tparam))

    if(latent_variable_type == "continuous"){

      colnames(item.parameters) <- c( "Item", "d", paste("a", 1:dimensions, sep = ""), "c")
      item.parameters$d <- runif(n= 1, min = -3, max = 3)  #adding difficulties to item parameter df
      item.parameters$Item <- num

      disc <- matrix(NA, ncol = dimensions)       # Item category discriminations


      for(i in 1:nrow(item.parameters)){

        for(j in 1:ncol(disc)){

          if(item.parameters$d[i] <= -3 | item.parameters$d[i] >= 3){

            disc[i,j] <- runif(1, min = 0.5, max = 1)

          } else {

            disc[i,j] <- runif(1, min = 0.75, max = 1.5)

            }
          }
        }

      for(i in 1:nrow(item.parameters)){

        if(item.parameters$d[i] <= -2){

          item.parameters$c[i] <- runif(1, min = 0, max = .10)

        }

        if(item.parameters$d[i] > -2 & item.parameters$d[i] < 2){

          item.parameters$c[i] <- runif(1, min = .10, max = .25)

        } else {

          item.parameters$c[i] <- runif(1, min = 0, max = .10)

        }
      }

      disc.end <- ncol(item.parameters)-1
      item.parameters[, 3:disc.end] <- disc
      itemparams2 <- item.parameters

    }

    if(latent_variable_type == "categorical"){

      colnames(item.parameters) <- c( "Item", "B0", paste("B", 1:dimensions, sep = ""))
      item.parameters$Item <- num

      item.parameters$B0 <- runif(n= 1, min = -1, max = 1) #adding difficulties to item parameter df
      item.parameters$B1 <- runif(n= 1, min = 0, max = 2)
      item.parameters$B2 <- runif(n= 1, min = 0, max = 2)

    }


    dichotomous.items[[length(dichotomous.items)+1]] = item.parameters
  }

  dichotomous.items <- do.call(rbind.data.frame, dichotomous.items)

  return(dichotomous.items)
}

