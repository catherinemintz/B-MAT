
modellcdm.file <- "
data{
int<lower=1> D;  // number of latent dimensions
int<lower=1> C; //number of classes
int<lower=1> I;  // number of items
int<lower=0> Y[I];
vector<lower=0>[I] a1; // discrim parms for trait 1
vector<lower=0>[I] a2; // discrim parms for trait 2
vector[I] diff;


//User-specified priors

simplex[C] Vc_prior; //will need to be fixed to 1
}


parameters {
simplex[C] Vc;
}


model{


target += lkj_corr_lpdf(theta_corr | lkj_theta);
target += multi_normal_lpdf(theta | mu_theta, quad_form_diag(theta_corr, sigma_theta)); //is this right?

for(i in 1:I){
real y_ = inv_logit(a1[i] .* theta[1] + a2[i] .* theta[2] + diff[i]);

target += bernoulli_logit_lpmf(Y[n] | y_);
target += beta_lpdf(y_  | a, b);

}
}

"
