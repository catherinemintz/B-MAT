
myArgs = commandArgs(trailingOnly = TRUE) #this will have all the specified arguments

iteration = as.numeric(myArgs[1])

#save(myArgs, file = paste("/Users/mathers/Dissertation/myArgs_", iteration, ".RData", sep = ""))

# set random number seed
seed = 0813 + iteration
set.seed(seed = seed)

####========================================================================== Reading in necessary functions and packages ####

library("MASS")
library("reshape2")
library("gtools")
#library("data.table")
#library("rstan")

for(i in 1:length(list.files(path = "/Users/mathers/catieCAT/R"))){
  
  file <- paste("/Users/mathers/catieCAT/R/",list.files(path = "/Users/mathers/catieCAT/R")[i], sep="")
  
  source(file, encoding="utf-8")
  
}

## Local sourcing
# for(i in 1:length(list.files(path = "~/hpchome/catieCAT/R"))){
#
#   file <- paste("~/hpchome/catieCAT/R/",list.files(path = "~/hpchome/catieCAT/R")[i], sep="")
#
#   source(file, encoding="utf-8")
#
# }

####========================================================================== Reading in data ####

load(file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Generating_Parameters/Iteration_", iteration, ".RData", sep=""))
#load(file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/MNRM/Iteration_", iteration, ".RData", sep=""))
#load(file = paste("/home/mathers/LSS/lss_jtemplin/Mintz/Dissertation/Generating_Parameters/Iteration_", 1, ".RData", sep=""))


####========================================================================== Creating rstan inputs ####

# data dimensions
nObs = nrow(sim_people)
nItems = ncol(sim_response_dich_df)
nFactors = 2

thetaMean = rep(0, 2)

dim1 <- c(rep(0, unidim_items), rep(1, unidim_items), rep(1, multidim_items))
dim2 <- c(rep(1, unidim_items), rep(0, unidim_items), rep(1, multidim_items))
Qmatrix <- t(rbind(dim1, dim2))


sumscores =  as.matrix(sim_response_dich_df) %*% Qmatrix
meanSumScores = apply(sumscores, 2, mean)
sdSumScores = apply(sumscores, 2, sd)

startingThetas = cbind(
  (sumscores[,1] - meanSumScores[1])/sdSumScores[1],
  (sumscores[,2] - meanSumScores[2])/sdSumScores[2]
)

initf2 <- function(chain_id = 1) {
  # cat("chain_id =", chain_id, "\n")
  list(theta = startingThetas)
}

# generate a list of lists to specify initial values
n_chains <- 4
init_ll <- lapply(1:n_chains, function(id) initf2(chain_id = id))


num_its = 5000
burnin = round(num_its*(2/3),0)
####========================================================================== Simulating Item Banks ####

  modcode_m3pl = readr::read_file("/Users/mathers/stan_models/m3pl_syntax.txt") # read in stan model syntax from a .txt file stored on your HPC home drive (replace <hawkid> (without brackets) with your HawkID and <stanfile> with the name of your stan model syntax file)
  
  # modcode_m3pl = readr::read_file("~/hpchome/stan_models/m3pl_syntax.txt") # for use on local system
  
moddata_m3pl = list(
  nObs = nObs,
  nItems = nItems,
  Qmatrix = Qmatrix,
  Y = t(sim_response_dich_df),
  nLoadingsInput = sum(Qmatrix),
  meanMu = 0,
  covMu = 1,
  meanLambda = rep(0, sum(Qmatrix)),
  covLambda = diag(1, sum(Qmatrix)),
  nFactors = nFactors,
  meanTheta = thetaMean) # define model data as specified in the rstan model syntax's data block (just like cmdstanr)

modstan_m3pl = rstan::stan_model(model_code = modcode_m3pl) # compile stan model

modrun_m3pl = rstan::sampling(modstan_m3pl,
                              data = moddata_m3pl,
                              chains = 4,
                              warmup = burnin,
                              iter = num_its,
                              init = init_ll,
                              #thin = 50,
                              #open_progress = TRUE,
                              refresh = 50)

  modsum_m3pl = posterior::summarise_draws(modrun_m3pl) # summarizes the posterior draws after sampling
  
  moddraws_m3pl = as.data.frame(modrun_m3pl) # saves the posterior's draws to a data.frame object (this will be used to create a .csv file later)
  
 # save(modrun_m3pl, modsum_m3pl, moddraws_m3pl, file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/M3PL/M3PL_Raw_Iteration_", iteration, ".RData", sep=""))
  
  save(moddraws_m3pl, sim_response_dich_df, modsum_m3pl, file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/M3PL/M3PL_Raw_Iteration_", iteration, ".RData", sep=""))
  
  
  item_bank <- STAN_output_to_item_bank(x = modsum_m3pl,   
                                                    item_type = "dichotomous",
                                                    parameter_names <- c("mu", "lambdaDim", "guess"),
                                                    dimensions = c(2,3,2),
                                                    output_names <- list("d", c("a1", "a2"), "c"))
  
  save(item_bank, file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/M3PL/M3PL_Item_Bank_", iteration, ".RData", sep=""))
  
  save(modrun_m3pl, file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/M3PL/M3PL_STAN_Iteration_", iteration, ".RData", sep=""))
  
  


