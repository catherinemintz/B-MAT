# https://github.com/jonathantemplin/MultidimensionalMeasurementModels2023/blob/main/materials/Week07/mirt/07_R_mirt.R


myArgs = commandArgs(trailingOnly = TRUE) #this will have all the specified arguments

iteration = as.numeric(myArgs[1])

#save(myArgs, file = paste("/Users/mathers/Dissertation/myArgs_", iteration, ".RData", sep = ""))

# set random number seed
seed = 0813 + iteration
set.seed(seed = seed)

####========================================================================== Reading in necessary functions and packages ####

library("MASS")
library("reshape2")
library("gtools")
library(mirt)

#library("data.table")
#library("rstan")

for(i in 1:length(list.files(path = "/Users/mathers/catieCAT/R"))){
  
  file <- paste("/Users/mathers/catieCAT/R/",list.files(path = "/Users/mathers/catieCAT/R")[i], sep="")
  
  source(file, encoding="utf-8")
  
}

####========================================================================== Reading in data ####

load(file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Generating_Parameters/Iteration_", iteration, ".RData", sep=""))


# Generate Simulated Data =============================================================================================

nItems = ncol(sim_response_dich_df)
nExaminees = nrow(sim_people)
nFactors = 2


dim1 <- c(rep(0, unidim_items), rep(1, unidim_items), rep(1, multidim_items))
dim2 <- c(rep(1, unidim_items), rep(0, unidim_items), rep(1, multidim_items))
Qmatrix <- t(rbind(dim1, dim2))


# Build Q-matrices for analysis =======================================================================================

estCov2D_lowerEchelon = matrix(data = FALSE, nrow = 2, ncol = 2)

estCov2D_correct = matrix(data = TRUE, nrow = 2, ncol = 2)
estCov2D_correct[1,1] = estCov2D_correct[2,2] = FALSE


# IRT Models in mirt using MML via Quasi Monte Carlo Integration ======================================================

# Confirmatory M3PL IRT model with correct Q-matrix
IRT_correct = mirt(data = sim_response_dich_df, 
                   model = mirt.model(Qmatrix, COV = estCov2D_correct), 
                   itemtype = "3PL",
                   SE = TRUE, 
                   method = "EM", 
                   technical = list(NCYCLES = 10000))

grouppar <- ncol(sim_response_dich_df)+1

item.params <- coef(IRT_correct, printSE = TRUE)[-grouppar]
item.params.list <- lapply(item.params, FUN = function(x){
  y <- x[1,c(1:4)]
  return(y)
  
})

item_bank <- do.call(rbind.data.frame, item.params.list)
colnames(item_bank) <- c("a1", "a2", "d", "c")
item_bank$Item <- 1:nrow(item_bank)
item_bank <- item_bank[,c(5,3,1,2,4)]

item_bank

# Comparing to STAN results ======================================================

save(item_bank, IRT_correct, file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/M3PL/mirt/M3PL_Item_Bank_", iteration, ".RData", sep=""))
#save(IRT_correct, file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/M3PL/mirt/M3PL_mirt_Iteration_", iteration, ".RData", sep=""))



