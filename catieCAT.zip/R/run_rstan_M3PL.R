run_rstan_M3PL <- function(STAN_file,
                           x,
                           num_theta,
                           item_params,
                           working_directory,
                           single_item = FALSE,
                           priors = list(
                             mu_theta = c(0,0),
                             sigma_theta = c(1,1),
                             lkj_theta=1, #for correlation matrix
                             sigma_theta_corr = rep(1,2),
                             theta_corr_input = .5)){


    stan_z <- STAN_file
    path_name <- paste(working_directory,"model.stan", sep="/")

    STAN_file_c <- as.character(stan_z)

    fileConn <- file(path_name)
    writeLines(STAN_file_c, fileConn)
    #writeLines(STAN_file, fileConn)
    close(fileConn)

    file_m3pl <- file.path(path_name)

    m3PL_file <- cmdstan_model(file_m3pl)

    a1 <- item_params[,which("a1" == colnames(item_params))]
    a2 <- item_params[,which("a2" == colnames(item_params))]
    guess <- item_params[,which("c" == colnames(item_params))]
    diff <- item_params[,which("d" == colnames(item_params))]

  if(single_item == TRUE){

    y1[,1] <- I <- 1

  } else {

    y1 <- as.matrix(t(rbind(as.numeric(c(1:length(x))), x)))

    I <- length(x)

  }

  stanData <- list(D=num_theta,
                   I=I,
                   a1=a1,
                   a2 = a2,
                   diff = diff,
                   guess = guess,
                   Y=y1[,2], #begin specifying priors
                   mu_theta = priors[["mu_theta"]],
                   sigma_theta = priors[["sigma_theta"]],
                   sigma_theta_corr = priors[["sigma_theta_corr"]],
                   theta_corr_input = priors[["theta_corr_input"]],
                   lkj_theta= priors[["lkj_theta"]]) #for correlation matrix)


  model_mcmc <- m3PL_file$sample(
    data = stanData,
    chains = 4,
    parallel_chains = 4,
    iter_warmup = 5000,
    iter_sampling = 10000,
    show_messages = TRUE)

  #model_params <- m3PL_mcmc$summary()

  return(model_mcmc)

}
