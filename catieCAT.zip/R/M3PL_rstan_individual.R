#' posterior estimate of the M3PL fitted to a data set with N == 1 people
#'
#' @param Vector of 0/1 scores
#' @param num_theta The number of latent variables to be estimated
#' @param working_directory Where the STAN file should be stored
#' @return posterior distribution of latent variables and item parameters. Future plans to include user-specified priors.

posteriorEstimate_M3PL_individual_old <- function(x, num_theta, itemParams, working_directory, first_it = FALSE){

  if(first_it == TRUE){

    mu = c(0,0)
    mu_corr <- matrix(c(1,0,0,1), length(num_theta), length(num_theta))

  } else {
    mu = currentPosterior@inits[[4]][["theta"]]
    mu_corr = currentPosterior@inits[[4]][["theta_corr"]]
  }

  N <- I <- length(x)
  D <- num_theta

  disc_index <- ncol(itemParams)-1

  diff <- itemParams[,2]
  disc <- itemParams[,c(3:disc_index)]
  guess <- itemParams[,ncol(itemParams)]

  stanData = list(P =1,
                  I = I,
                  D = D,
                  N = N,
                  diff = diff,
                  disc = disc,
                  guess = guess,
                  y = x,
                  mu = mu,
                  mu_Sigma = mu_Sigma,
                  mu_corr = mu_corr)


  model.file <- "
  data {
  int P;
  int<lower=1> I;                // number of questions
  int<lower=1> N;                // number of observations
  int y[I];                   // correctness of observation n
  int<lower=1> D;                // number of latent dimensions
  vector[I] diff;                    //difficulties
  vector[I] guess;                   // guessing parameters
  matrix[I,D] disc;        // matrix of discrimination parameters
  vector[D] mu;
  corr_matrix[D] mu_corr;

  }


  parameters {
    vector[D] theta;         //person parameter matrix
    corr_matrix[D] theta_corr; // standardized theta variance-covariance matrix
    vector<lower=0>[D] sigma_theta_corr;

  }

  transformed parameters{

  cov_matrix[D] Sigma_theta_cov;
  cov_matrix[D] mu_Sigma;
  Sigma_theta_cov = quad_form_diag(theta_corr, sigma_theta_corr);
  mu_Sigma = quad_form_diag(mu_corr, ) //CATIE

  }

  model {

//Variable declaration
    real nu;  //vector of predictor terms
    real logitSum;

  // the priors
    theta ~ multi_normal(mu, mu_corr);
    sigma_theta_corr ~ cauchy(0, 5); // prior on the standard deviations;need to change from Cauchy?
    theta_corr ~ lkj_corr(1); // LKJ prior on the correlation matrix

  // the likelihood

    for(i in 1:I){

        logitSum = 0;

        for(d in 1:D){

          logitSum = logitSum+theta[d]*disc[i, d];

        }

      nu = guess[i]+(1-guess[i])*inv_logit(logitSum + diff[i]);

      y[i] ~ bernoulli_logit(nu);
      }
}"

  fileConn <-file(paste(working_directory,"model.stan", sep="/"))
  writeLines(model.file, fileConn)
  close(fileConn)

  m3PL_file <- stan(
    file = paste(working_directory,"model.stan", sep="/"),  # Stan program
    data = stanData,
    chains = 4,             # number of Markov chains
    warmup = 1000,          # number of warmup iterations per chain
    iter = 2000,            # total number of iterations per chain
    cores = 1,              # number of cores (could use one per chain)
    refresh = max(2000/10, 1) # show progress
  )

  return(m3PL_file)

}
