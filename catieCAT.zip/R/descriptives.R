descriptives <- function(vars, group, dataframe){

  x <- split(dataframe, by = dataframe$group)

  x.apply <- lapply(x, function(y){

      y.vars <- as.list(y)

      desc <- lapply(y.vars, function(w){

        w.df <- matrix(NA, row = 1, ncol = 6)
        w.df[,1] <- mean(w.df)
        w.df[,2] <- sd(w.df)
        w.df[,3] <- min(w.df)
        w.df[,4] <- max(w.df)
        w.df[,5] <- length(w.df)
        w.df[,6] <- names(w.df)

        colnames(w.df) <- c("Mean", "SD", "Min", "Max", "N", "Variable")

        return(w.df)


      })

      desc.comb <- do.call(rbind.data.frame, desc)

      desc.comb$Group <- NA #update this

      return(desc.comb)


  })


  x.combine <- do.call(rbind.data.frame, x.apply)
  return(x.combine)
}
