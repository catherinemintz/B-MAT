#' Introducting randomnness into a score for a single individiaul
#'
#' @param cat_probs Vector containing the item category probabilities for a single person
#' @param set.seed The number of latent variables to be estimated
#' @return random_score item category score with randomness introduced

rrandom <- function(cat_probs, set_seed){

  if(set_seed == TRUE){
    set.seed(03052022)
  }

  random_var <- runif(n = 1, min = 0, max = 1)

  adj_weights <- c(-1,1)

  nom_score <- which.max(cat_probs)

  if(random_var > nom_score){

    if(nom_score == 2 | nom_score == 3){

      adj_weight <- sample(adj_weights)
      nom_score_adjusted <- nom_score + adj_weight

    }

    if(nom_score == 1){

      nom_score_adjusted <- 2

    }

    if(nom_score == 4){

      nom_score_adjusted <- 3

    }

  }

  return(nom_score_adjusted)

}
