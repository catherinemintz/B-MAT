#source("C:\\Users\\CatieM\\Dropbox\\Dissertation\\Dissertation R Package\\functions\\DCMloglike.R")
#source("C:\\Users\\CatieM\\Dropbox\\Dissertation\\Dissertation R Package\\functions\\posteriorEstimate.R")
#source("C:\\Users\\CatieM\\Dropbox\\Dissertation\\Dissertation R Package\\functions\\jointloglike.R")
#source("C:\\Users\\CatieM\\Dropbox\\Dissertation\\Dissertation R Package\\functions\\MI_conditional_logits.R")

item_shannon_entropy = function(current_posterior, items_administered, item_parameters, classObject, data_type){

  if(data_type == "dichotomous"|data_type == "Dichotomous"){

      b0 <- item_parameters[,2]
      b1 <- item_parameters[,3]
      b2 <- item_parameters[,4]

      # current_posterior = p(\alpha_c|_yn-1)
      # classObject == attribute profile for each class

      condLogit <- vector(length = length(current_posterior))
      condProb_1 <- vector(length = length(current_posterior))
      condProb_0 <- vector(length = length(current_posterior))

        for (classNum in 1:length(current_posterior)){
          condLogit[classNum] = b0+(b1*classObject[classNum,1])+(b2*classObject[classNum,2])
          condProb_1[classNum] = exp(condLogit[classNum])/(1+exp(condLogit[classNum])) #P(Y=1|a_c)
          condProb_0[classNum] = 1-condProb_1[classNum] #P(Y=0|a_c)

          Prob1[classNum] = condProb_1[classNum]*current_posterior[classNum]
          Prob0[classNum] = condProb_0[classNum]*current_posterior[classNum]
        }

      binary_response <- matrix(c(0,1), nrow = 2)
      posterior_class <- matrix(NA, nrow =classNum, ncol = length(binary_response))
      term_prod = vector(length=length(binary_response))

      score_vec <- vector()
      first_term <- vector()

      for(score in 1:length(binary_response)){

        if(score == 1){
          score_vec = 0
          condl_prob = condProb_0

        } else {
          score_vec = 1
          condl_prob = condProb_1

        }


        posterior_given_n_and_n_minus_1 <- posteriorEstimate(response = score_vec,
                                                             item_parameters = item_parameters,
                                                             class_prior = current_posterior,
                                                             num_att = 2,
                                                             data_type = "dichotomous") #P(a_c|Y, y-1)

        for (classNum in 1:length(current_posterior)){

          first_term[classNum] = posterior_given_n_and_n_minus_1[classNum]*log(1/posterior_given_n_and_n_minus_1[classNum])
          second_term = condl_prob*current_posterior

        }

        first_sum_over_class = sum(first_term)
        second_sum_over_class = sum(second_term)
        term_prod[score] = first_sum_over_class*second_sum_over_class

      }
      SHE = sum(term_prod)
  }

  ##----------------------------------------------------------------------------------

  if(data_type == "nominal"|data_type == "Nominal"){

    applied_ia_ic <- MI_conditional_logits(DF = item_parameters, current_posterior = current_posterior, classObject = classObject)

    nominal_response <- matrix(c(1,2,3,4), nrow = 4)
    posterior_class <- matrix(NA, nrow =ncol(classObject), ncol = length(nominal_response))

    first_term <- vector()
    second_term <- vector()

    for(score in 1:length(nominal_response)){

      score_vec <- nominal_response[score,]
      condl_prob = applied_ia_ic[score,]

      posterior_given_n_and_n_minus_1 <- posteriorEstimate(response = score_vec,
                                                           item_parameters = item_parameters,
                                                           class_prior = current_posterior,
                                                           num_att = 2,
                                                           data_type = "nominal") #P(a_c|Y, y-1)

      for (classNum in 1:length(current_posterior)){

        first_term[classNum] = posterior_given_n_and_n_minus_1[classNum]*log(1/posterior_given_n_and_n_minus_1[classNum])
        second_term = condl_prob*current_posterior

      }

      first_sum_over_class = sum(first_term)
      second_sum_over_class = sum(second_term)
      term_prod[score] = first_sum_over_class*second_sum_over_class

    }
    SHE = sum(term_prod)
  }

  return(SHE)
}
