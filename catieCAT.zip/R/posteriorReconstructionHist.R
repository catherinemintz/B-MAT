#' Convert continuous distribution to discrete densities
#'
#'  @param STANobject Current posterior distribution obtained using one of the posteriorEstimate functions
#'  @param thetaname How theta values were named in the posteriorEstimate function (i.e., how they are labeled in the JAGS output). Unless manually changed, will be "theta".
#'  @param bins Number of bins per latent variable. Not used if set_limits = TRUE
#'  @param set_limits If TRUE, min and max of the theta values will be set to -6 and 6, respectively. If FALSE, min and max will be pulled from the JAGS object
#'  @param target_length Used in lieu of bins when set_limits = TRUE
#'  @return Matrix with four columns: 1) Theta 1 value, 2) Theta 2 value, 3) Frequency, 4) Proportion

posterior_reconstruction_hist <- function(STANobject, bins, set_limits = TRUE, target_length = NULL){

  target_length = target_length

 # thetaobject_0 <- STANobject$draws("theta") #makes no assumptions about what theta has been labeled in the JAGS script

  # thetaobject = NULL
  # for (chain in 1:dim(thetaobject_0)[2]){
  #   thetaobject = rbind(thetaobject, cbind(as.numeric(thetaobject_0[, chain,1]), as.numeric(thetaobject_0[, chain,2])))
  # }

  thetaobject <- STANobject #since it's being read in as a df already, no need to do weird extractions

  ## Finding max and mins for each dimension

  if(set_limits == TRUE){

    dim1.min <- dim2.min <- -6
    dim1.max <- dim2.max <- 6

    dim1.bins <- seq(from = dim1.min, to = dim1.max, length.out = sqrt(target_length))
    dim2.bins <- seq(from = dim2.min, to = dim2.max, length.out = sqrt(target_length))

    dim1.increment <- (dim1.max-dim1.min)/length(dim1.bins)
    dim2.increment <- (dim2.max-dim2.min)/length(dim2.bins)

    dim1.labels <- dim1.bins
    dim2.labels <- dim2.bins

  } else{

    dim1.min <- min(thetaobject[,1])
    dim2.min <- min(thetaobject[,2])

    dim1.max <- max(thetaobject[,1])
    dim2.max <- max(thetaobject[,2])

    ## Creating the bins
    dim1.increment <- (dim1.max-dim1.min)/bins
    dim2.increment <- (dim2.max-dim2.min)/bins

    dim1.bins <- seq(from = dim1.min, to = dim1.max, by = dim1.increment)
    dim2.bins <- seq(from = dim2.min, to = dim2.max, by = dim2.increment)

    ## Begin calculating counts in each cell

    #new way

    dim1.labels <- vector()
    dim2.labels <- vector()

    stop.val1 <- length(dim1.bins)-1
    for(i in 1:stop.val1){
      dim1.labels[i] <- mean(c(dim1.bins[i], dim1.bins[i+1]))
    }

    stop.val2 <- length(dim2.bins)-1
    for(i in 1:stop.val2){
      dim2.labels[i] <- mean(c(dim2.bins[i], dim2.bins[i+1]))
    }
  }


  thetaobject_withcounts <- as.data.frame(table(cut(thetaobject[,1], breaks = seq.int(from = dim1.min, to = dim1.max, by = dim1.increment), labels = dim1.labels),
                                                cut(thetaobject[,2], breaks = seq.int(from = dim2.min, to = dim2.max, by = dim2.increment), labels = dim2.labels)))


  thetaobject_withcounts[,1] <- as.numeric(as.character(thetaobject_withcounts[,1]))
  thetaobject_withcounts[,2] <- as.numeric(as.character(thetaobject_withcounts[,2]))
  thetaobject_withcounts[,3] <- as.numeric(as.character(thetaobject_withcounts[,3]))

  ## Calculating proportions

  thetaobject_withcounts$Proportion <- thetaobject_withcounts$Freq/sum(thetaobject_withcounts$Freq)

  if(sum(thetaobject_withcounts$Freq) == 0){

    thetaobject_withcounts$Proportion <- 0

  }

  return(thetaobject_withcounts)

} #end bracket
