#' calculate_bias
#'
#' @param parameters Vector of item parameters (e.g., unidimensional discrimination parameter)
#' @param estimates Vector of estimates for item parameters specified in the parameters argument
#' @param identifiers For dichotomous items, dataframe of Item ids and dimension specifiers (e.g., "1" if the item loads on to dimension 1, "2" if dimenison 2, and "1-2" if both). For nominal items, Category id should be included
#' @param data.type "dichotomous" for dichotomous data and "nominal" for either ordered or unordered polytomous data.
#' @param summary.statistic Logical. Whether to return summary statistics of bias 
#' @param by.dim Logical. Whether to compute bias by the dimensions onto which the item loads.
#' @return Depending on whether comparison_examinee_results is implemented, returns either 1) a data frame of the percent of examinees given each item or 2) a list of data frames of the percent of examinees given each item.


calculate_bias <- function(parameters, estimates, identifiers, data.type = "dichotomous", summary.statistics = FALSE, by.dim = FALSE){
  
 bias <- as.data.frame(estimates-parameters)
 bias_results <- cbind(identifiers, bias)

 
 if(data.type == "dichotomous"){colnames(bias_results) <- c("Item", "Dimension", "Bias")}
 
 if(data.type == "nominal"){colnames(bias_results) <- c("Item", "Category", "Dimension", "Bias")}

 if(summary.statistics == TRUE){
   
   if(data.type == "nominal"){
     
     cat_split <- split(bias_results, bias_results$Category)
     
     cat_apply <- lapply(cat_split, function(x){
       
       cat <- unique(x$Category)[1]
       mean.x <- mean(x$Bias)
       median.x <- median(x$Bias)
       sd.x <- sd(x$Bias)
       max.x <- max(x$Bias)
       min.x <- min(x$Bias)
       
       stat.sum <- c(cat, mean.x, median.x, sd.x, max.x, min.x)
       
       colnames(stat.sum) <- c("Category", "Mean", "Median", "SD", "Max", "Min")
       
       return(stat.sum)
       
     })
     
     bias_results <- do.call(rbind.data.frame, cat_apply)
     
   }
  
   if(data.type == "dichotomous"){
     
     mean.x <- mean(bias_results$Bias)
     median.x <- median(bias_results$Bias)
     sd.x <- sd(bias_results$Bias)
     max.x <- max(bias_results$Bias)
     min.x <- min(bias_results$Bias)
     
     bias_results <- c(mean.x, median.x, sd.x, max.x, min.x)
     
     colnames(bias_results) <- c("Mean", "Median", "SD", "Max", "Min")
     
   }
   
   if(by.dim == TRUE){
     
     dim_split <- split(bias_results, bias_results$Dimension)
     
     dim_apply <- lapply(dim_split, function(y){
       
       if(data.type == "nominal"){
         
         cat_split <- split(y, y$Category)
         
         cat_apply <- lapply(cat_split, function(x){
           
           cat <- unique(x$Category)[1]
           mean.x <- mean(x$Bias)
           median.x <- median(x$Bias)
           sd.x <- sd(x$Bias)
           max.x <- max(x$Bias)
           min.x <- min(x$Bias)
           
           stat.sum <- c(cat, mean.x, median.x, sd.x, max.x, min.x)
           
           colnames(stat.sum) <- c("Category", "Mean", "Median", "SD", "Max", "Min")
           
         })
         
         bias_results <- do.call(rbind.data.frame, cat_apply)
         
       }
       
       if(data.type == "dichotomous"){
         
         mean.x <- mean(y$Bias)
         median.x <- median(y$Bias)
         sd.x <- sd(y$Bias)
         max.x <- max(y$Bias)
         min.x <- min(y$Bias)
         
         stat.sum <- c(mean.x, median.x, sd.x, max.x, min.x)
         
         colnames(stat.sum) <- c("Mean", "Median", "SD", "Max", "Min")
         
         
       }
       
       return(stat.sum)
  
     })
     
     bias_results <- do.call(rbind.data.frame, dim_apply)
     
   }
     
 }
 
 
 return(bias_results)
  
  
}