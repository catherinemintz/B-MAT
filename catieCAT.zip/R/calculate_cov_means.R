calculate_cov_means <- function(STAN, method = "across"){


  if(method == "across"){

    STANdf = as.data.frame(STAN) # saves the posterior's draws to a data.frame object (this will be used to create a .csv file later)

    thetaobject <- STANdf[,(grep('theta\\[', colnames(STANdf)))]

    theta_cov_mat <- cov(thetaobject)
    means_vec <- colMeans(thetaobject)


  }

  if(method == "within"){

    STAN_list <- STAN@sim[["samples"]]
    STAN_apply <- lapply(STAN_list, function(x){

      theta_mean <- x[(grep('theta\\[', names(x)))]
      means <- t(matrix(unlist(lapply(theta_mean, mean))))

      if(grep('thetaCov\\[', names(x)) == TRUE){

        theta_var_cov <- x[(grep('thetaCov\\[', names(x)))]
        var_cov <- t(matrix(unlist(lapply(theta_var_cov, mean))))

      } else {

        var_cov <- cov(means)

      }



      return(list(var_cov,means))

    })

    STAN_cov <- lapply(STAN_apply, `[[`, 1)
    cov_df <- do.call(rbind.data.frame, STAN_cov)
    cov_df_means <- colMeans(cov_df)
    theta_cov_mat <- matrix(cov_df_means, nrow = sqrt(length(cov_df_means)))

    STAN_means <- lapply(STAN_apply, `[[`, 2)
    means_df <- do.call(rbind.data.frame, STAN_means)
    means_vec <- matrix(colMeans(means_df), ncol = ncol(means_df))

  }


  return(list(theta_cov_mat,means_vec))

}
