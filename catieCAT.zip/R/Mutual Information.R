#' Mutual Information statistic for a single auditioned item.
#'
#' @param response_array Vector of responses to previously administered items
#' @param current_posterior Current posterior estimate as returned from the posteriorReconstructionHist function. NOTE: posterior densities with zero probability have a small decimal added to them.
#' @param item_parameters Parameters/parameter estimates for the auditioned item
#' @param items_administered Parameters/parameter estimates for the previously administered items
#' @param latent_variable_type How the latent variables are distributed. Takes "continuous" or "categorical" as input
#' @param data_type Takes input of "dichotomous" or "nominal"
#' @return MI statistic for auditioned item

item_mututal_information_STAN = function(STAN_file = NULL,
                                    response_array,
                                    current_posterior,
                                    item_parameters,
                                    items_administered,
                                    latent_variable_type,
                                    data_type,
                                    num_theta,
                                    working_directory = NULL,
                                    item_priors){
  nt <- num_theta
  wd <- working_directory
  item_priors <<- item_priors
  item_parameters <<- item_parameters
  model.file <- STAN_file

  posterior_list <- list()


  if(latent_variable_type == "categorical"){

    classObject <- matrix(c(0,0,1,1,0,1,0,1), nrow = 4, ncol = 2)

    if(data_type == "dichotomous"){

      b0 <- item_parameters[,2]
      b1 <- item_parameters[,3]
      b2 <- item_parameters[,4]

      # current_posterior = p(\alpha_c|_yn-1)
      # classObject == attribute profile for each class

      condLogit <- vector(length = length(current_posterior))
      condProb_1 <- vector(length = length(current_posterior))
      condProb_0 <- vector(length = length(current_posterior))


      Prob1 = matrix(NA, nrow = length(current_posterior))
      Prob0 = matrix(NA, nrow = length(current_posterior))

      for(classNum in 1:length(current_posterior)){
        condLogit[classNum] = b0+(b1*classObject[classNum,1])+(b2*classObject[classNum,2])
        condProb_1[classNum] = exp(condLogit[classNum])/(1+exp(condLogit[classNum])) #P(Y=1|a_c)
        condProb_0[classNum] = 1-condProb_1[classNum] #P(Y=0|a_c)

        Prob1[classNum] = condProb_1[classNum]*current_posterior[classNum]
        Prob0[classNum] = condProb_0[classNum]*current_posterior[classNum]
      }


      binary_response <- matrix(c(0,1), nrow = 2)
      posterior_class <- matrix(NA, nrow =classNum, ncol = length(binary_response))
      term_prod = vector(length=length(binary_response))

      score_vec <- vector()
      first_term <- vector()
      second_term <- vector(length = length(current_posterior)) #CATIE

      for(score in 1:length(binary_response)){

        if(score == 1){
          score_vec = 0
          condl_prob = condProb_0
          marg_prob <- sum(Prob0)

        } else {
          score_vec = 1
          condl_prob = condProb_1
          marg_prob <<- sum(Prob1)

        }


        posterior_given_n_and_n_minus_1 <- posteriorEstimate(response = score_vec,
                                                             item_parameters = item_parameters,
                                                             class_prior = current_posterior,
                                                             num_att = 2,
                                                             data_type = "dichotomous") #P(a_c|Y, y-1)

        for (classNum in 1:length(current_posterior)){
          second_term[classNum] <- posterior_given_n_and_n_minus_1[classNum]*log(posterior_given_n_and_n_minus_1[classNum]/current_posterior[classNum])
        }

        first_term <- marg_prob
        second_sum_over_class = sum(second_term)
        term_prod[score] = first_term*second_sum_over_class


        posterior_list[[score]] <- posterior_given_n_and_n_minus_1

      }
      MI = sum(term_prod)
    }


    ##------------------------------------------------Nominal Condition
    if(data_type == "nominal"){

      applied_ia_ic <- MI_conditional_logits_DCM(DF = item_parameters, current_posterior = current_posterior, classObject = classObject)

      marg_cat_probs <- matrix(NA, nrow = 4, ncol = length(current_posterior))

      for (classNum in 1:length(current_posterior)){
        for(u in 1:nrow(applied_ia_ic)){
          marg_cat_probs[u, classNum] <- applied_ia_ic[u, classNum]*current_posterior[classNum]
        }
      }


      nominal_response <- matrix(c(1,2,3,4), nrow = 4)
      posterior_class <- matrix(NA, nrow =ncol(classObject), ncol = length(nominal_response))

      first_term <- vector()
      second_term <- vector()

      for(score in 1:length(nominal_response)){

        score_vec <- nominal_response[score,]
        condl_prob = applied_ia_ic[score,]
        marg_cat_probs_sum <- sum(marg_cat_probs[score,])

        posterior_given_n_and_n_minus_1 <- posteriorEstimate(response = score_vec,
                                                             item_parameters = item_parameters,
                                                             class_prior = current_posterior,
                                                             num_att = 2,
                                                             data_type = "nominal") #P(a_c|Y, y-1)

        for (classNum in 1:length(current_posterior)){
          second_term[classNum] <- posterior_given_n_and_n_minus_1[classNum]*log(posterior_given_n_and_n_minus_1[classNum]/current_posterior[classNum])
        }

        first_term <- marg_cat_probs_sum
        second_sum_over_class = sum(second_term)
        term_prod[score] = first_term*second_sum_over_class


        posterior_list[[score]] <- posterior_given_n_and_n_minus_1

      }

      MI = sum(term_prod)
    }
  }

  ##------------------------------------------------------------------------------------------------------------

  if(latent_variable_type == "continuous"){
    if(data_type == "dichotomous"){

      item_with_administered <- rbind(items_administered, item_parameters)

     #  item_priors[["mu"]] <- as.array((item_with_administered[,which(grepl('d', colnames(item_with_administered)) == TRUE)]))
    #   item_priors[["lambdaDim"]] <- as.matrix((item_with_administered[,which(grepl('a', colnames(item_with_administered)) == TRUE)]))
    #   item_priors[["guess"]] <- as.array((item_with_administered[,which(grepl('c', colnames(item_with_administered)) == TRUE)]))


      Prob1 <- Prob0 <- condProb_0 <- condProb_1 <- condLogit <- vector(length = nrow(current_posterior))

      ## Since we don't have set classes, creating the various combinations of theta values

      ## Creating the bins

      dim.min <- dim.min <- -6
      dim.max <- dim.max <- 6

      dim.bins <- seq(from = dim.min, to = dim.max, length.out = sqrt(nrow(current_posterior)))
      dimension_combinations_ls <- expand.grid(x = dim.bins, y = dim.bins)
      dimension_combinations <- do.call(cbind.data.frame, dimension_combinations_ls)


      for(dimcomb in 1:nrow(dimension_combinations)){

        condProb_1[dimcomb] <- M3PL(single_item_parameters = item_parameters, theta = dimension_combinations[dimcomb,1:2], return_probs = TRUE)
        condProb_0[dimcomb] <- 1-condProb_1[dimcomb]


        Prob1[dimcomb] = condProb_1[dimcomb]*current_posterior[dimcomb,4] #assumes that the posterior and dimcomb have the same # of rows. need to troubleshoot problems
        Prob0[dimcomb] = condProb_0[dimcomb]*current_posterior[dimcomb,4]

      }

      binary_response <- c(0,1)
      term_prod = vector(length=length(binary_response))

      score_vec <- vector()
      first_term <- vector()
      second_term <- vector(length = nrow(dimension_combinations))

      for(score in 1:length(binary_response)){

        if(score == 1){

          score_vec = 0
          condl_prob = condProb_0
          marg_prob = Prob0

        }

        if(score == 2){

          score_vec = 1
          condl_prob = condProb_1
          marg_prob = Prob1

        }

        response_array_plus_score_vec <- as.matrix(c(response_array, score_vec), ncol = 1)

        p_n_minus_1 <- run_rstan(STAN_file = model.file,
                                      x = response_array_plus_score_vec,
                                      num_theta = nt,
                                      item_params = item_with_administered,
                                      item_priors = item_priors)


        posterior_given_n_and_n_minus_1 <- posterior_reconstruction_hist(p_n_minus_1,
                                                                         bins = 30,
                                                                         set_limits = TRUE,
                                                                         target_length = 900)

        posterior_given_n_and_n_minus_1 <- as.data.frame(posterior_given_n_and_n_minus_1)
        colnames(posterior_given_n_and_n_minus_1) <- c("Dim1", "Dim2", "Freq", "Prop")

        posterior_given_n_and_n_minus_1_zerocorrection <- posterior_given_n_and_n_minus_1

        # for(i in 1:nrow(posterior_given_n_and_n_minus_1_zerocorrection)){
        #   if(posterior_given_n_and_n_minus_1_zerocorrection[i,4] == 0){
        #     posterior_given_n_and_n_minus_1_zerocorrection[i,4] <- posterior_given_n_and_n_minus_1_zerocorrection[i,4]+.Machine$double.xmin
        #   }
        # }

       # posterior_given_n_and_n_minus_1_zerocorrection$Prop[posterior_given_n_and_n_minus_1_zerocorrection$Prop == 0] <- .Machine$double.xmin

        if(0 %in% posterior_given_n_and_n_minus_1_zerocorrection$Prop){

          posterior_given_n_and_n_minus_1_zerocorrection$Prop[posterior_given_n_and_n_minus_1_zerocorrection$Prop == 0] <- .Machine$double.xmin

        }



        current_posterior_zerocorrection <- current_posterior

        colnames(current_posterior_zerocorrection) <-  c("Dim1", "Dim2", "Freq", "Prop")

        if(0 %in% current_posterior_zerocorrection$Prop){

          current_posterior_zerocorrection$Prop[current_posterior_zerocorrection$Prop == 0] <- .Machine$double.xmin

        }


        # for(i in 1:nrow(current_posterior)){
        #   if(current_posterior[i,4] == 0){
        #     current_posterior_zerocorrection[i,4] <- current_posterior[i,4]+.Machine$double.xmin
        #   }
        # }




        ###CATIE: NEED TO confirm PROBABLITY(score|responses)is correct

        # for(dc in 1:nrow(dimension_combinations)){
        #   first_term[dc] = posterior_given_n_and_n_minus_1_zerocorrection[dc,4]*log(posterior_given_n_and_n_minus_1_zerocorrection[dc,4]/(current_posterior[dc,4]*marg_prob))
        #   second_term = condl_prob*current_posterior
        # }

        marg_prob_across_theta <- sum(marg_prob)

        for(dc in 1:nrow(dimension_combinations)){
          second_term[dc] <- posterior_given_n_and_n_minus_1_zerocorrection[dc,4]*log(posterior_given_n_and_n_minus_1_zerocorrection[dc,4]/(current_posterior_zerocorrection[dc,4]))
        }

        first_term <- marg_prob_across_theta
        second_term_sum <- sum(second_term)
        term_prod[score] <- first_term*second_term_sum

        posterior_list[[score]] <- p_n_minus_1

      }

      MI <- sum(term_prod)

    }

    if(data_type == "nominal"){

      condl_cat_probs <- MI_conditional_logit_MIRT(item_parameters, current_posterior = current_posterior, set_limits = TRUE)

      item_with_administered <- rbind(items_administered, item_parameters)

      num_items_admin <- length(unique(item_with_administered$Item))
      unique_items_admin <- unique(item_with_administered$Item)

      item_priors[["mu"]] <- array(dim = c(num_items_admin, item_priors[["maxCategory"]]))

      for(i in 1:num_items_admin){

        #item_priors[["mu"]][i,]  <- item_with_administered[grepl(unique_items_admin[i], item_with_administered[,1]) == TRUE, grepl('d', colnames(item_with_administered)) == TRUE]
        item_priors[["mu"]][i,]  <- item_with_administered[unique_items_admin[i] == item_with_administered[,1], grepl('d', colnames(item_with_administered)) == TRUE]


      }

      lambdaDim <- array(dim = c(num_theta, num_items_admin,  item_priors[["maxCategory"]]))

      for(p in 1:num_theta){

        patt <- paste('^a', p, sep ="")

        for(m in 1:num_items_admin){

          for(k in 1:item_priors[["maxCategory"]]){

            itemcat <- item_with_administered[which(item_with_administered$Item == unique_items_admin[m] & item_with_administered$Category == k),]

            lambdaDim[p,m,k] <- itemcat[,which(grepl(patt, colnames(itemcat)) == TRUE)]

          }


        }

      }

      ## Creating the bins

      dim.min <- dim.min <- -6
      dim.max <- dim.max <- 6

      dim.bins <- seq(from = dim.min, to = dim.max, length.out = sqrt(nrow(current_posterior)))
      dimension_combinations <- expand.grid(x = dim.bins, y = dim.bins)

      current_posterior_zerocorrection <- current_posterior

      colnames(current_posterior_zerocorrection) <-  c("Dim1", "Dim2", "Freq", "Prop")

      if(0 %in% current_posterior_zerocorrection$Prop){

        current_posterior_zerocorrection$Prop[current_posterior_zerocorrection$Prop == 0] <- .Machine$double.xmin

      }


      # for(i in 1:nrow(current_posterior)){
      #   if(current_posterior[i,4] == 0){
      #     current_posterior_zerocorrection[i,4] <- current_posterior[i,4]+.Machine$double.xmin
      #   }
      # }


      marg_cat_probs <- matrix(NA, nrow = nrow(dimension_combinations), ncol = ncol(condl_cat_probs))

      for (dimcomb in 1:nrow(dimension_combinations)){
        for(u in 1:ncol(condl_cat_probs)){
          marg_cat_probs[dimcomb, u] = condl_cat_probs[dimcomb,u]*current_posterior_zerocorrection[dimcomb,4]  #assumes that the posterior and dimcomb have the same # of rows. need to troubleshoot problems
        }
      }

      nominal_response <- c(1,2,3,4)
      term_prod = vector(length=length(nominal_response))

      score_vec <- vector()
      second_term <- vector()

      marg_cat_probs_sum <- colSums(marg_cat_probs)

      for(score in 1:length(nominal_response)){

        score_vec <- nominal_response[score]
        condl_prob <- condl_cat_probs[,score]
        marg_prob <- marg_cat_probs_sum[score]


        response_array_plus_score_vec <- c(response_array, score_vec)

        p_n <- run_rstan(STAN_file = STAN_file,
                              x = response_array_plus_score_vec,
                              num_theta = num_theta,
                              item_params = item_with_administered,
                                item_priors = item_priors)

        posterior_given_n_and_n_minus_1 <- posterior_reconstruction_hist(p_n,
                                                                         bins = 30,
                                                                         set_limits = TRUE,
                                                                         target_length = 900)

        if(is.factor(posterior_given_n_and_n_minus_1[,1]) == TRUE){
          posterior_given_n_and_n_minus_1[,1] <- as.numeric(as.character(posterior_given_n_and_n_minus_1[,1]))
          posterior_given_n_and_n_minus_1[,2] <- as.numeric(as.character(posterior_given_n_and_n_minus_1[,2]))
        }

        posterior_given_n_and_n_minus_1 <- as.data.frame(posterior_given_n_and_n_minus_1)
        colnames(posterior_given_n_and_n_minus_1) <- c("Dim1", "Dim2", "Freq", "Prop")

        posterior_given_n_and_n_minus_1_zerocorrection <- posterior_given_n_and_n_minus_1

        if(0 %in% posterior_given_n_and_n_minus_1_zerocorrection$Prop){

          posterior_given_n_and_n_minus_1_zerocorrection$Prop[posterior_given_n_and_n_minus_1_zerocorrection$Prop == 0] <- .Machine$double.xmin

        }


        #posterior_given_n_and_n_minus_1_zerocorrection$Prop[posterior_given_n_and_n_minus_1_zerocorrection$Prop == 0] <- .Machine$double.xmin

        # for(i in 1:nrow(posterior_given_n_and_n_minus_1_zerocorrection)){
        #   if(posterior_given_n_and_n_minus_1_zerocorrection[i,4] == 0){
        #     posterior_given_n_and_n_minus_1_zerocorrection[i,4] <- posterior_given_n_and_n_minus_1_zerocorrection[i,4]+.Machine$double.xmin
        #   }
        # }



        for(dc in 1:nrow(dimension_combinations)){
          second_term[dc] <- posterior_given_n_and_n_minus_1_zerocorrection[dc,4]*log(posterior_given_n_and_n_minus_1_zerocorrection[dc,4]/(current_posterior_zerocorrection[dc,4]))
        }

        first_term <- marg_prob
        second_term_sum = sum(second_term)
        term_prod[score] = first_term*second_term_sum


        posterior_list[[score]] <- p_n

      }

      MI = sum(term_prod)

    }
  }

  MI_post <- list(MI, posterior_list)

  return(MI_post)

}

