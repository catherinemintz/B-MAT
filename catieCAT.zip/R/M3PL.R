#' Item probability under the Multidimensional Three-Parameter Logistic Model
#'
#' @param single_item_parameters Vector of item parameters. Assumes two dimensions and that item parameters are labeled 'c' (guessing), 'a1', 'a2', and 'd'.
#' @param theta Vector containing two theta values for an individual
#' @param return_probs Whether to return the individual's probability of answering the item correctly (TRUE) or the individual's predicted score (FALSE)
#' @return Depending on input of return_probs, either the orobability of answering the item correctly given the individual's theta values or the individual's predicted score

M3PL <- function(single_item_parameters, theta, return_probs = FALSE){

    # z <- exp((single_item_parameters$a1*theta[1])+(single_item_parameters$a2*theta[2])+single_item_parameters$d)
    #
    # prob <- as.numeric(single_item_parameters$c + (1-single_item_parameters$c)*(z/(1+z)))


  z <- exp((single_item_parameters[3]*theta[1])+(single_item_parameters[4]*theta[2])+single_item_parameters[2])

  prob <- as.numeric(single_item_parameters[5] + (1-single_item_parameters[5])*(z/(1+z)))

    score <-NA

    sp <- runif(1)

    if(prob >= sp){

      score <- 1

    } else {

      score <- 0

    }

    if(return_probs == TRUE){

      return(prob)

    } else{

      return(score)

    }
}
