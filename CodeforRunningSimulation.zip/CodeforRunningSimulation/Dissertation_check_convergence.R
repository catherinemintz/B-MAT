
myArgs = commandArgs(trailingOnly = TRUE) #this will have all the specified arguments

iteration = as.numeric(myArgs[1])

#save(myArgs, file = paste("/Users/mathers/Dissertation/myArgs_", iteration, ".RData", sep = ""))

# set random number seed
seed = 0813 + iteration
set.seed(seed = seed)

####========================================================================== Reading in necessary functions and packages ####

library("MASS")
library("reshape2")
library("gtools")
#library("data.table")
#library("rstan")

for(i in 1:length(list.files(path = "/Users/mathers/catieCAT/R"))){
  
  file <- paste("/Users/mathers/catieCAT/R/",list.files(path = "/Users/mathers/catieCAT/R")[i], sep="")
  
  source(file, encoding="utf-8")
  
}


####========================================================================== Loading Data ####
load(paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/M3PL/M3PL_Raw_Iteration_", iteration, ".RData", sep=""))

moddraws_m3pl_d = posterior::as_draws(moddraws_m3pl)

modsum_m3pl = posterior::summarise_draws(moddraws_m3pl) # summarizes the posterior draws after sampling


####==========================================================================Extracting Parameters ####

## SE Check

se.check <- check_se(modsum_m3pl, sample.size = nrow(moddraws_m3pl_d))

if(length(se.check) == 1){
  
  se.check <- as.data.frame(se.check)
  se.check$Iteration <- iteration
  
} else {
  
  se.check$Iteration <- iteration
}


save(se.check, file = "/Shared/lss_jtemplin/Mintz/Dissertation/Convergence/Check_",iteration,".RData")
