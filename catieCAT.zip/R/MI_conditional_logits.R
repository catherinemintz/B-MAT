
MI_conditional_logits <- function(DF, current_posterior, classObject){
  DF = DF
  current_posterior = current_posterior
  classObject = classObject

  condLogit <- matrix(NA, nrow = nrow(DF), ncol = length(current_posterior))
  condProb <- matrix(NA, nrow = nrow(DF), ncol = length(current_posterior))
  denom <- vector(length = nrow(DF))

  for (classNum in 1:length(current_posterior)){
    for(cat in 1:nrow(DF)){
      condLogit[cat, classNum] = exp(DF[cat,3]+(DF[cat,4]*classObject[classNum,1])+(DF[cat,5]*classObject[classNum,2]))
      }
  }

    denom <- colSums(condLogit)

  for (classNum in 1:length(current_posterior)){
    for(cat in 1:nrow(DF)){
      condProb[cat, classNum] <- condLogit[cat, classNum]/denom[classNum]
      }
    }


#
#     condLogit1[classNum] = DF[1,3]+(DF[1,4]*classObject[classNum,1])+(DF[1,5]*classObject[classNum,2])
#     condLogit2[classNum] = DF[2,3]+(DF[2,4]*classObject[classNum,1])+(DF[2,5]*classObject[classNum,2])
#     condLogit3[classNum] = DF[3,3]+(DF[3,4]*classObject[classNum,1])+(DF[3,5]*classObject[classNum,2])
#     condLogit4[classNum] = DF[4,3]+(DF[4,4]*classObject[classNum,1])+(DF[4,5]*classObject[classNum,2])
    #
    # condProb_1[classNum] = exp(condLogit1)/(1+exp(condLogit1)) #P(Y=1|a_c)
    # condProb_2[classNum] = exp(condLogit2)/(1+exp(condLogit2)) #P(Y=2|a_c)
    # condProb_3[classNum] = exp(condLogit3)/(1+exp(condLogit3)) #P(Y=3|a_c)
    # condProb_4[classNum] = exp(condLogit4)/(1+exp(condLogit4)) #P(Y=4|a_c)
    #
  #  Prob1 = condProb_1*current_posterior[classNum] #summing across classes
  #  Prob2 = condProb_2*current_posterior[classNum]
  #  Prob3 = condProb_3*current_posterior[classNum]
  #  Prob4 = condProb_4*current_posterior[classNum]

 # ProbX <- c(condProb_1, condProb_2, condProb_3, condProb_4)

  return(condProb)
}

##
