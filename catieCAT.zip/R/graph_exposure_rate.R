#' graph_exposure_rate
#'
#' @param exposure_rate_output List of item exposure rates produced by calculate_exposure_rate. Each list element should be the exposure rates for a single MAT administration.
#' @param compare Logical, default is FALSE. If TRUE, assumes each exposure_rate_output element is a list of data frames that should be compared. Used to compare different item pool parameterizations.
#' @return D-optimality value for the auditioned item.


graph_exposure_rate <- function(exposure_rate_output, compare = FALSE){

   exposure_rate_df <- do.call(rbind.data.frame,exposure_rate_output)

  # categories <- as.data.frame(matrix(NA, nrow = 10))
  # categories$UpperLimits <-seq(10, 100, by = 10)
  # categories$LowerLimits <- seq(0,90, by = 10)
  # categories <- categories[,c(2:3)]
  # categories$Count <- NA
  #
  # for(i in 1:10){
  #   categories$Count[i] <- nrow(exposure_rate_df[which(exposure_rate_df$`Exposure Rate` %between% c(categories$LowerLimits[i], categories$UpperLimits[i])),])
  # }

 plots_return <- ggplot2::ggplot(data = exposure_rate_df)+
    geom_histogram(aes(x = `Exposure Rate`))+
    scale_y_continuous(name = "Count")+
    scale_x_continuous(breaks = seq(0,100, by = 10))+
    theme_bw()

  if(compare == TRUE){

    exposure_rate_long <- reshape2::melt(exposure_rate_df[,c(1:3)], id.vars = colnames(exposure_rate_df)[1], variable.name = "Model", value.name = "Exposure Rate")

   difference_plot_hist <- ggplot2::ggplot(data = exposure_rate_df)+
      geom_histogram(aes(x = `Exposure Rate Difference`))+
      scale_y_continuous(name = "Count")+
      scale_x_continuous(breaks = seq(-100,100, by = 10))+
      theme_bw()

   difference_plot_point <- ggplot2::ggplot(data = exposure_rate_df)+
     geom_point(aes(x = exposure_rate_df[,2], y = exposure_rate_df[,3]))+
     scale_y_continuous(name = paste("Item-Level Exposure Rate for ", colnames(exposure_rate_df)[3], sep = ""), breaks = seq(-100,100, by = 10))+
     scale_x_continuous(name = paste("Item-Level Exposure Rate for ", colnames(exposure_rate_df)[2], sep = ""), breaks = seq(-100,100, by = 10))+
     theme_bw()

   rates_plot <- ggplot2::ggplot(data = exposure_rate_long)+
     geom_histogram(aes(x = `Exposure Rate`))+
     scale_y_continuous(name = "Count")+
     scale_x_continuous(breaks = seq(0,100, by = 10))+
     facet_wrap(vars(Model))+
     theme_bw()

   plots_return <- list(difference_plot_hist, difference_plot_point, rates_plot)
  }

  return(plots_return)

}
