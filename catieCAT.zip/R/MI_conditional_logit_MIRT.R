#' Obtaining category probabilities for each point in the posterior distribution
#'
#' @param x Matrix with rows corresponding to items/item categories (stacked) and columns corresponding to item parameters.The third column contains difficulty parameters, the fourth and fifth columns contain discrimination parameters.
#' @param current_posterior posterior distribution obtained using the posteriorReconstructionHist function
#' @param set_limits Whether to use the mins and max of the current posterior (FALSE) or set min to -6 and max to 6 (TRUE)
#' @return Matrix of probability values, where rows correspond to points in the posterior distribution and each column represents an item category


MI_conditional_logit_MIRT <- function(x, current_posterior, set_limits = TRUE){

  d <- x[,3]
  a1 <- x[,4]
  a2 <- x[,5]

  unique_cats <- unique(x[,2])

  condl_logit <- e_condl_logit <-  condl_prob <- matrix(NA, nrow = nrow(current_posterior), ncol = length(unique_cats))
  condl_logit_sum <- vector(length= nrow(current_posterior))

  if(set_limits == FALSE){

    for(dimcomb in 1:nrow(current_posterior)){
      for(u in 1:length(unique_cats)){
        condl_logit[dimcomb, u] <- d[u]+current_posterior[dimcomb,1]*a1[u]+current_posterior[dimcomb,2]*a2[u]
        e_condl_logit[dimcomb, u] <- exp(condl_logit[dimcomb, u])
      }
      condl_logit_sum[dimcomb] <- sum(e_condl_logit[dimcomb,])
    }

    for(dimcomb in 1:nrow(current_posterior)){
      for(u in 1:length(unique_cats)){
        condl_prob[dimcomb,u] <- e_condl_logit[dimcomb,u]/condl_logit_sum[dimcomb]
      }
    }
  }


  if(set_limits == TRUE){

    dim.min <- dim.min <- -6
    dim.max <- dim.max <- 6

    dim.bins <- seq(from = dim.min, to = dim.max, length.out = sqrt(nrow(current_posterior)))
    dimension_combinations <- expand.grid(x = dim.bins, y = dim.bins)


    for(dimcomb in 1:nrow(dimension_combinations)){
      for(u in 1:length(unique_cats)){
        condl_logit[dimcomb, u] <- d[u]+dimension_combinations[dimcomb,1]*a1[u]+dimension_combinations[dimcomb,2]*a2[u]
        e_condl_logit <- exp(condl_logit)
      }
    }

    condl_logit_sum <- rowSums(e_condl_logit)

    for(dimcomb in 1:nrow(dimension_combinations)){
      for(u in 1:length(unique_cats)){
        condl_prob[dimcomb,u] <- e_condl_logit[dimcomb,u]/condl_logit_sum[dimcomb]
      }
    }

  }

  return(condl_prob)

}
