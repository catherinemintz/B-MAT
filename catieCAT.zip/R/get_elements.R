get_elements <- function(x, element) {
  if(is.list(x))
  {
    if(element %in% names(x)) x[[element]]
    else lapply(x, get_elements, element = element)
  }
}

#from https://stackoverflow.com/questions/64578972/pull-all-elements-with-specific-name-from-a-nested-list