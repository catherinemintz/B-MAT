draws_to_summary <- function(draws){
  
  colmean <- apply(draws, MARGIN = 2, FUN = mean)
  col.names <- colnames(draws)
  colmean.mat <- as.data.frame(matrix(t(rbind(colmean))))
  colnames(colmean.mat) <- "mean"
  colmean.mat$variable <- col.names
  
  return(colmean.mat)
  
}