graph_nominal_parameters <- function(item, people){

  person_prob <- lapply(seq_along(people), FUN = function(y){

    x = people[[y]]

    mnrm_probs <-  MNRM(item, x, return_probs = TRUE)

    mnrm_probs$theta1 <- x[,1]
    mnrm_probs$theta2 <- x[,2]

    return(mnrm_probs)

  })

  person_df <- do.call(rbind.data.frame, person_prob)

  item_list <- list()

  if(length(unique(item$a1)) != 1){

    item_list[["theta1"]] <- ggplot(data = person_df)+
      geom_point(aes(x = theta1, y = V1), color = "dark green")+
      geom_point(aes(x = theta1, y = V2), color = "red")+
      geom_point(aes(x = theta1, y = V3), color = "purple")+
      geom_point(aes(x = theta1, y = V4), color = "blue")

  }

  if(length(unique(item$a2)) != 1){

    item_list[["theta2"]] <- ggplot(data = person_df)+
      geom_point(aes(x = theta2, y = V1), color = "dark green")+
      geom_point(aes(x = theta2, y = V2), color = "red")+
      geom_point(aes(x = theta2, y = V3), color = "purple")+
      geom_point(aes(x = theta2, y = V4), color = "blue")

  }

  return(item_list)

}
