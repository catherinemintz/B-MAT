for(i in 1:length(list.files(path = "/Users/mathers/catieCAT/R"))){
  
  file <- paste("/Users/mathers/catieCAT/R/",list.files(path = "/Users/mathers/catieCAT/R")[i], sep="")
  
  source(file, encoding="utf-8")
  
}

options(scipen=999)

condition.names <- as.data.frame(expand.grid(c("D-Optimality", "Mutual Information"), 40, c(1,10,1000,1000000), c("M3PL", "MNRM")))
condition.names$Var1 <- as.character(condition.names$Var1)
condition.names$Var4 <- as.character(condition.names$Var4)

cond.1 <- paste(condition.names$Var1,condition.names$Var2, condition.names$Var3, sep = "_")
cond.2 <- paste(cond.1, condition.names$Var4, sep = "/")

bank.person <- expand.grid(c(1:97,99:101), c(1:100))
  
MNRM.names <- paste("MNRM_Bank_",bank.person[,1], "_Person_",bank.person[,2], ".RData", sep = "")
M3PL.names <- paste("M3PL_Bank_",bank.person[,1], "_Person_",bank.person[,2], ".RData", sep = "")

reptitions_list <- lapply(seq_along(cond.2), FUN = function(i){
  
  x = cond.2[i]
  
  cond.list <- list()
  
  path_final <- paste("~/LSS/lss_jtemplin/Mintz/Dissertation/MAT_Results/", x, "/", sep = "") #CATIE: Update this for job sumission /Shared/lss_jtemplin/Mintz/Dissertation/
  
  path.files <- list.files(path = path_final)
  
  if(condition.names$Var4[i] == "MNRM"){
    
    all.files<- MNRM.names
    
  }
  
  if(condition.names$Var4[i] == "M3PL"){
    
    all.files <- M3PL.names
    
  }

  files.to.get <- setdiff(all.files, path.files)
  
  all_num <- lapply(files.to.get, function(x){as.numeric(strsplit(x, "\\D+")[[1]][-1])})
  
  if(condition.names$Var4[i] == "M3PL"){
    
    nums.to.get <- do.call(rbind.data.frame, lapply(all_num, function(w){
      
      bank_person <- (c(w[2], w[3]))
      
      return(bank_person)
      
      
    }))
    
  }
  
  if(condition.names$Var4[i] == "MNRM"){
    
    nums.to.get <- do.call(rbind.data.frame, lapply(all_num, function(w){
      
      bank_person <- (c(w[1], w[2]))
      
      return(bank_person)
      
      
    }))
    
  }
  
  # cond.return <- do.call(data.table::rbindlist, cond.list)
  
  return(nums.to.get)
  
  
})

names(reptitions_list) <- cond.2
cond_left <- reptitions_list

save(cond_left, file = "~/LSS/lss_jtemplin/Mintz/Dissertation/MAT_Results/Conditions_Left.RData")
