#' STAN_output_to_item_bank
#'
#' @param x Dataframe of STAN output summarized using the posterior::summarise_draws() function. The first and second columns should be "variable" and "mean", respectively.
#' @param item_type "Dichotomous" for dichotomously-scored items, "nominal" or "polytomous" for items with category parameters.
#' @param parameter_names Vector of parameter names from STAN. E.g., nominal items STAN parameters "initMu" for intercepts and "initLambdaDim" for slopes, parameter_names should be "c("initMu", "initLambdaDim")".
#' @param output_names List of desired parameter estimate names in final output. E.g., an item bank with one intercept and two slopes per item, output_names could be "list("mu", c("slope1", "slope2"))".
#' @param dimensions Vector of parameter dimensions specified in STAN. E.g., a nominal item with one intercept and two slopes per category, dimensions could be "c(2,3)" (i.e., item x category, item x category x factor).
#' @param item.cat.factor.positions For nominal or polytomous item_type only. List, with each list element corresponding to the parameter in parameter_names. Specifies which STAN matrix/array element corresponds to the item, category, and - if applicable - factor, respectively.
#' E.g., for a multidimensional, compensatory nominal response model: if rows are items, columns are categories, and shelves are factors, item.cat.factor.positions should be "list(c(1,2), c(1,2,3))".
#' @param key.positions For nominal or polytomous item_type only with key parameters set to zero for model identification. Numeric vector of item keys.
#' @return Dataframe with rows corresponding to items/categories and columns corresponding to parameter estimates


STAN_output_to_item_bank <- function(x, item_type = "dichotomous", parameter_names, output_names, dimensions, item.cat.factor.positions = NULL, key.positions = NULL){

  #View(STAN_output_to_item_bank(modsum_mnrm, item_type = "nominal", parameter_names = c("mu", "lambdaDim"), output_names = list("mu", c("theta1", "theta2")), key.positions = keys_num, item.cat.factor.positions = list(c(1,2), c(1,3,2), c(1,2))))
  # parameter_names <- c("initMu", "initLambdaDim")
  # dimensions = c(2,3)
  # output_names <- list("mu", c("theta1", "theta2"))
  # key.positions = rep(4, 60)
  # item.cat.factor.positions = list(c(1,2), c(1,3,2), c(1,2))

  extract_params <- lapply(parameter_names, function(y){

    w <- x[which(grepl(y, x$variable)),]
    z <- w[,c(1:2)]

    s <- apply(z[,1], MARGIN = 1, FUN = function(v){

    out.brackets <- regmatches(v, gregexpr("\\[\\K[^\\]]+(?=\\])", v, perl=TRUE))

    out.num <- as.data.frame(t(unlist(as.vector(strsplit(gsub("\\D", "\\1\\2 ", out.brackets), " ")))))

    return(out.num)

   })
    s.df <- do.call(rbind.data.frame,s)

    z <- cbind(z,s.df)

    return(z)

  })


  if(item_type == "dichotomous"){

    clean_params <- lapply(extract_params, function(y){

        df.names = vector(length = ncol(y)-3)

        for(i in 1:length(df.names)){

          df.names[i] = paste(colnames(y)[i+3], "+", sep = " ")

          if(i == length(df.names)){

            df.names[i] = colnames(y)[i+3]
          }

        }

        formula = paste(colnames(y)[3]," ~", (paste(df.names,collapse=' ')))

        z <- reshape2::dcast(y, formula = formula, value.var = colnames(y)[2])

        return(z)

    })

    named_params <- lapply(seq_along(clean_params), function(i){

      y = clean_params[[i]]

      out.names = vector(length =length(output_names[[i]]))

      for(j in 1:length(out.names)){

        out.names[j] = paste(output_names[[i]][j], ",", sep = "")

        if(j == length(out.names)){

          out.names[j] = output_names[[i]][j]
        }

      }


      colnames(y) <- unlist(strsplit(paste("Item,", paste(out.names, collapse=''), sep = ""), ","))


      return(y)

    })

    merged_params <- Reduce(merge, named_params)

    merged_params$Item <- as.numeric(merged_params$Item)

  }

  if(item_type == "nominal" | item_type == "polytomous"){

    clean_params <- lapply(seq_along(extract_params), FUN = function(j){

      y = extract_params[[j]]

       if(is.null(item.cat.factor.positions) == TRUE){item.cat.factor.positions = c(1,2)}

       col.positions <- c(1,2,item.cat.factor.positions[[j]]+2)
       item.pos <- item.cat.factor.positions[[j]][1]+2
       cat.pos <-  item.cat.factor.positions[[j]][2]+2

      y.split <- split(y, y[,item.pos])

      y.apply <- lapply(seq_along(y.split), function(w){

        y.split.w <- y.split[[w]]

        if(length(item.cat.factor.positions[[j]]) > 2){

          factor.pos <-  item.cat.factor.positions[[j]][3]+2

          w.split <- split(y.split.w, y.split.w[, factor.pos])

          w.apply <- lapply(seq_along(w.split), function(m){

            w.split.m <- w.split[[m]]

            if(key.positions[w] %!in% w.split.m[,cat.pos]){

              var.name <- sub("^([[:alpha:]]*).*", "\\1", w.split.m[1,1])
              paste.vec <- vector(length= 3)
              paste.vec[item.pos] <- unique(w.split.m[,item.pos])[1]
              paste.vec[factor.pos] <- unique(w.split.m[,factor.pos])[1]
              paste.vec[cat.pos] <- key.positions[w]
              paste.vec <- as.numeric(paste.vec[which(paste.vec != "FALSE")])


              new.row <- nrow(w.split.m)+1
              w.split.m[new.row,1] <- paste(var.name, "[", paste(paste.vec, collapse = ","), "]", sep = "")
              w.split.m[new.row,2] <- 0
              w.split.m[new.row,item.pos] <- unique(w.split.m[,item.pos])[1]
              w.split.m[new.row,factor.pos] <- unique(w.split.m[,factor.pos])[1]
              w.split.m[new.row,cat.pos] <- key.positions[w]

              }

            return(w.split.m)

          })

          w.combine <- do.call(rbind.data.frame, w.apply)

          return(w.combine)

        } else {

          if(key.positions[w] %!in% y.split.w[,cat.pos]){

            var.name <- sub("^([[:alpha:]]*).*", "\\1", y.split.w[1,1])
            paste.vec <- vector(length= 3)
            paste.vec[item.pos] <- unique(y.split.w[,item.pos])[1]
            paste.vec[cat.pos] <- key.positions[w]
            paste.vec <- as.numeric(paste.vec[which(paste.vec != "FALSE")])


            new.row <- nrow(y.split.w)+1
            y.split.w[new.row,1] <- paste(var.name, "[", paste(paste.vec, collapse = ","), "]", sep = "")
            y.split.w[new.row,2] <- 0
            y.split.w[new.row,item.pos] <- unique(y.split.w[,item.pos])[1]
            y.split.w[new.row,cat.pos] <- key.positions[w]

            }

          return(y.split.w)


        }

      })

      y <- do.call(rbind.data.frame, y.apply)

      df.names <- colnames(y)[which(colnames(y) %!in% colnames(y[,c(1,2,item.pos, cat.pos)]))]

      if(length(df.names > 0)){

       # formula = paste(colnames(y)[item.pos], "+", paste(df.names,collapse=' + '), "~",  colnames(y)[cat.pos])
        formula = paste(colnames(y)[item.pos], "+", colnames(y)[cat.pos], "~", paste(df.names,collapse=' + '))

        y <- reshape2::dcast(y, formula = formula, value.var = colnames(y)[2])

      } else {

        y <- y[, c(item.pos, cat.pos,2)]

      }

      colnames(y) <- strsplit(paste("Item", ",", "Category", ",", paste(output_names[[j]], collapse = "," ), sep = ""), split = ",")[[1]]

       y$Item <- as.numeric(y$Item)
      y$Category <- as.numeric(y$Category)

      return(y)

    })

    merged_params <- Reduce(merge, clean_params)




  }


  return(merged_params)

}

####===================== DNU ####

# y.apply <- lapply(seq_along(y.split), function(w){
#
#   if(length(item.cat.factor.positions[[j]]) == 2){
#     substr.digits = 2
#   }
#
#   if(length(item.cat.factor.positions[[j]]) == 3){
#     substr.digits = 4
#   }
#
#
#   y.split.w <- y.split[[w]]
#
#   if(key.positions[w] %!in% y.split.w[,4]){
#
#     if(length(output_names[[j]]) == 1){
#
#       new.row <- nrow(y.split.w)+1
#       y.split.w[new.row,1] <- paste(substr(y.split.w[1,1], 1, nchar(y.split.w[1,1])-substr.digits), key.positions[w], "]", sep ="")
#       y.split.w[new.row,2] <- 0
#       y.split.w[new.row,3] <- unique(y.split.w[,item.pos])[1]
#       y.split.w[new.row,4] <- key.positions[w]
#
#     } else {
#
#       new.row <- nrow(y.split.w)+length(output_names[[j]])
#       factor.length <- length(output_names[[j]])
#
#       row.fac <- list(c((nrow(y.split.w)+1):new.rows), c(1:factor.length))
#
#       for(n in length(row.fac)){
#
#           y.split.w[row.fac[[1]][n],1] <- paste(substr(y.split.w[1,1], 1, nchar(y.split.w[1,1])-substr.digits), row.fac[[2]][n], ",",key.positions[w], "]", sep ="")
#           y.split.w[row.fac[[1]][n],2] <- 0
#           y.split.w[row.fac[[1]][n],3] <- unique(y.split.w[,item.pos])[1]
#           y.split.w[row.fac[[1]][n],4] <- row.fac[[2]][n]
#           y.split.w[row.fac[[1]][n],5] <- key.positions[w]
#       }
#
#     }
#
#
#   }
#
#   return(y.split.w)
#
# })
