
posteriorEstimate = function(response, item_parameters, class_prior, num_att, data_type){ #1 col per class? priors will follow a multinomial distribution?

  # response_array = response_array

  item_id = item_parameters[,1]

  b0_array = item_parameters[,2]
  b1_array = item_parameters[,3]
  b2_array = item_parameters[,4]

  num_att = num_att
  class_prior = class_prior

  classPosteriorint = matrix(NA, ncol = length(class_prior), nrow = 1)
  classPosterior = matrix(NA, ncol = length(class_prior), nrow = 1)


  if(data_type == "dichotomous"){
    itemJointProbs = exp(jointloglike(response = response, b0 = b0_array, b1 = b1_array, b2 = b2_array, num_att = num_att, data_type = data_type, per_class = TRUE))

    # for(c in 1:length(class_prior)){
    classPosteriorint = class_prior*itemJointProbs
    #}

    sumclassPosterior = sum(classPosteriorint)

    for(c in 1:length(class_prior)){
      classPosterior[c] = classPosteriorint[c]/sumclassPosterior
    }
  }

  ##-------------------------------------------------Nominal Condition

  if(data_type == "nominal"){

    # items_split <- split(item_parameters[,2:4], item_parameters[,1])
    # items_split2 <- lapply(items_split, matrix, ncol = 3)
    #  items_split3 <- lapply(items_split2, t) #columns are categories


    # itemJointProbs_exp <- lapply(items_split2, function(x){exp(
    #                                 jointloglike(response = response_array,
    #                                              b0_array = x[,1],
    #                                              b1_array = x[,2],
    #                                              b2_array = x[,3],
    #                                              num_att = num_att,
    #                                              data_type = "nominal"))})

    # b0_array = t(matrix(item_parameters[,3], ncol = num_att)) #ncol was originally 3?
    # b1_array = t(matrix(item_parameters[,4], ncol = num_att))
    # b2_array = t(matrix(item_parameters[,5], ncol = num_att))

    b0_array = item_parameters[,3]
    b1_array = item_parameters[,4]
    b2_array = item_parameters[,5]

    itemJointProbs = exp(jointloglike(response = response, b0= b0_array, b1 = b1_array, b2 = b2_array, num_att = num_att, data_type = "nominal", per_class = TRUE))

    for(c in 1:length(class_prior)){
      classPosteriorint[c] = class_prior[c]*itemJointProbs[c]
    }

    sumclassPosterior = sum(classPosteriorint)

    for(c in 1:length(class_prior)){
      classPosterior[c] = classPosteriorint[c]/sumclassPosterior
    }
  }


  return(classPosterior)
}

#### Practice
#
# b0_cats <- matrix(rnorm(16,-2,0.25), ncol = 4)
# b1_cats <- matrix(rnorm(16, 2,0.25), ncol = 4)
# b2_cats <- matrix(rnorm(16, 2,0.25), ncol = 4)
#
# response_cat <- c(1,3,4,2)
# classprac <- matrix(c(rep(0.25,4)), nrow = 1)
#
# posteriorEstimate(response = c(2,1,3,4), b0 = b0_cats, b1 = b1_cats, b2 =  b2_cats, num_att =2, class_prior = classprac, data_type = "nominal")
#
