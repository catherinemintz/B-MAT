
myArgs = commandArgs(trailingOnly = TRUE) #this will have all the specified arguments

iteration = as.numeric(myArgs[1])
total_items = as.numeric(myArgs[2])

#save(myArgs, file = paste("/Users/mathers/Dissertation/myArgs_", iteration, ".RData", sep = ""))

# set random number seed
seed = 0813 + iteration
set.seed(seed = seed)

####========================================================================== Reading in necessary functions and packages ####

library("MASS")
library("reshape2")
library("gtools")
#library("data.table")
#library("rstan")

for(i in 1:length(list.files(path = "/Users/mathers/catieCAT/R"))){
  
  file <- paste("/Users/mathers/catieCAT/R/",list.files(path = "/Users/mathers/catieCAT/R")[i], sep="")
  
  source(file, encoding="utf-8")
  
}

## Local sourcing
# for(i in 1:length(list.files(path = "~/hpchome/catieCAT/R"))){
#
#   file <- paste("~/hpchome/catieCAT/R/",list.files(path = "~/hpchome/catieCAT/R")[i], sep="")
#
#   source(file, encoding="utf-8")
#
# }


####========================================================================== Generating Item and Person Parameters ####

#Items
unidim_items <- total_items/4
multidim_items <- total_items/2

dim2_names <- sort(c(rep(c(unidim_items+1):c(unidim_items*2), 4)))
dim12_names <- sort(c(rep(c(max(dim2_names)+1):c(max(dim2_names)+multidim_items), 4)))

#for(iteration in 1:2){

sim_items_nom_1 <- as.data.frame(as.matrix(nominal_response_parameters(unidim_items, categories = 4, 1, seed = FALSE, set.zero = TRUE, latent_variable_type = "continuous")))
sim_items_nom_1$a2 <- 0

sim_items_nom_2 <- as.data.frame(as.matrix(nominal_response_parameters(unidim_items, categories = 4, 1, seed = FALSE, set.zero = TRUE, latent_variable_type = "continuous")))
sim_items_nom_2$a2 <- sim_items_nom_2$a1
sim_items_nom_2$a1 <- 0
sim_items_nom_2$Item <- dim2_names

sim_items_nom_12 <- as.data.frame(as.matrix(nominal_response_parameters(multidim_items, categories = 4, 2, seed= FALSE, set.zero = TRUE, latent_variable_type = "continuous")))
sim_items_nom_12$Item <- dim12_names

sim_items_nom <- rbind(sim_items_nom_1, sim_items_nom_2, sim_items_nom_12)
sim_items_split <- split(sim_items_nom, sim_items_nom$Item)

# Persons
sim_people <- mvrnorm(n = 2000, mu = c(0,0), Sigma = matrix(c(1, 0.5, 0.5,1), nrow = 2))
sim_people_split <- split(sim_people, seq(nrow(sim_people)))
sim_people_split <- lapply(sim_people_split, matrix, ncol = 2, nrow = 1)


#sim_examinees <- mvrnorm(n = 100, mu = c(0,0), Sigma = matrix(c(1, 0.5, 0.5,1), nrow = 2))
sim_examinees <- expand.grid(c(runif(10, -4, 4)), c(runif(10, -4, 4)))
sim_examinees_split <- split(sim_examinees, seq(nrow(sim_examinees)))
sim_examinees_split <- lapply(sim_examinees_split, matrix, ncol = 2, nrow = 1)

####========================================================================== Generating item banks (MNRM and M3PL) Without introducing noise ####

sim_response_nom <- lapply(sim_items_split, function(x){
  
  
  rv <- lapply(sim_people_split, function(y){
    
    z <-MNRM(single_item_parameters = x, thetas = y, return_probs = FALSE)
    
    return(z)
    
  })
  
  
  rv_df <- do.call(rbind.data.frame, rv)
  
  return(rv_df)
  
})

sim_response_nom_df <- as.data.frame((do.call(cbind.data.frame, sim_response_nom)))
colnames(sim_response_nom_df) <- paste("Item", 1:ncol(sim_response_nom_df), sep="")

sim_response_dich_df <- sim_response_nom_df

sim_response_dich_df[sim_response_dich_df < 4] <- 0
sim_response_dich_df[sim_response_dich_df == 4] <- 1


save(sim_people, sim_examinees_split, sim_response_dich_df, sim_response_nom_df, unidim_items, multidim_items, file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Generating_Parameters/Iteration_", iteration, ".RData", sep=""))
save(sim_items_nom, file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/MNRM/Iteration_", iteration, ".RData", sep=""))
