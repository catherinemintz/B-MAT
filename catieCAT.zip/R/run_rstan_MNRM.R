run_rstan_MNRM <- function(STAN_file,
                           x,
                           num_theta,
                           item_params,
                           working_directory,
                           priors = list(
                             mu_theta = c(0,0),
                             sigma_theta = c(1,1),
                             sigma_theta_corr = rep(1,2),
                             lkj_theta=1, #for correlation matrix
                             sigma_theta_corr = rep(1,num_theta),
                             theta_corr_input = .5)){


  # diff <- item_params[,c(1:3)]
  # a1 <- item_params[,c(1:2,4)]
  # a2 <- item_params[,c(1:2,5)]

  diff <- as.data.frame(reshape(item_params[,c(1:3)], timevar = "Category", idvar = "Item", direction = "wide")[-1])
  a1 <- as.data.frame(reshape(item_params[,c(1:2,4)], timevar = "Category", idvar = "Item", direction = "wide")[-1])
  a2 <- as.data.frame(reshape(item_params[,c(1:2,5)], timevar = "Category", idvar = "Item", direction = "wide")[-1])

  y1 <- t(rbind(unique(item_params[,1]), x))
  num.items <- unique(item_params[,1])

  stanData <- list(D=num_theta,
                   I=num.items,
                   a1=a1,
                   a2 = a2,
                   diff = diff,
                   maxCat = 4,
                   Y=x, #begin specifying priors
                   lkj_theta= priors[["lkj_theta"]], #for correlation matrix
                   theta_corr_input = priors[["theta_corr_input"]],
                   mu_theta = priors[["mu_theta"]],
                   sigma_theta = priors[["sigma_theta"]],
                   sigma_theta_corr = priors[["sigma_theta_corr"]])

  mnrm_mcmc <- mnrm_file$sample(
    data = stanData,
    chains = 4,
    parallel_chains = 4,
    iter_warmup = 5000,
    iter_sampling = 10000,
    show_messages = TRUE)

  return(mnrm_mcmc)

}

