# multidimensional_information <- function(item, model){
#
#   if(model == "M3PL"){
#
#       loglike <- x*log(item$c+(1-item$c)*(exp(item$d + item$a1*theta1+item$a2*theta2)/1+exp(item$d + item$a1*theta1+item$a2*theta2)))+(1-x)*(1-(item$c+(1-item$c)*(exp(item$d + item$a1*theta1+item$a2*theta2)/1+exp(item$d + item$a1*theta1+item$a2*theta2))))
#
#       deriv(loglike, c("theta1", "theta2"))
#
#   }
#
#
#   if(model = "MNRM"){
#
#     neg.D <- -
#
#
#   }
#
#
#
# }


