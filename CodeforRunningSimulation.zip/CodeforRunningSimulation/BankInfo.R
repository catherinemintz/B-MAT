library("MASS")
library("reshape2")
library("gtools")
#library("data.table")
#library("rstan")

for(i in 1:length(list.files(path = "/Users/mathers/catieCAT/R"))){
  
  file <- paste("/Users/mathers/catieCAT/R/",list.files(path = "/Users/mathers/catieCAT/R")[i], sep="")
  
  source(file, encoding="utf-8")
  
}

#==================================================================== Bank Descriptives ####
models <- c("MNRM", "M3PL") 

itembanks <- c(1:97,99:101)

banks <-  lapply(models, FUN = function(x){
  
  cond.list <- list()
  
  if(x == "MNRM"){
  
  #path_final <- paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/", x, "/", sep = "") #CATIE: Update this for job sumission /Shared/lss_jtemplin/Mintz/Dissertation/
  #  path_final <- paste("~/LSS/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/", x, "/", sep = "") #CATIE: Update this for job sumission /Shared/lss_jtemplin/Mintz/Dissertation/

  
  for(i in 1:100){   
    
    load(paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/", x, "/Iteration_",itembanks[i] ,".RData",sep = ""))

    cond.list[[i]] <- sim_items_nom
    
    }
  
  }
  
  if(x == "M3PL"){
    
    #path_final <- paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/", x, "/mirt/", sep = "") #CATIE: Update this for job sumission /Shared/lss_jtemplin/Mintz/Dissertation/
    
    for(i in 1:100){   
      
      load(paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/", x, "/mirt/M3PL_Item_Bank_",itembanks[i] ,".RData",sep = ""))
      
      cond.list[[i]] <- item_bank
      
    }
    
  }
  
#  path.files <- sort(paste(path_final, list.files(path = path_final), sep=""))
  
  return(cond.list)
  
})

names(banks) <- models

quad.vals <- mgauss.hermite(n = 10, mu = c(0,0), sigma = matrix(c(1,0.5,0.5,1), nrow = 2))[,c(1:2)]
quad.vals <- quad.vals[order(quad.vals[,1]),]


bank_info <- lapply(seq_along(banks), function(i){
  
  x = banks[[i]]
  bank.name <- names(banks)[i]
  
  if(bank.name == "MNRM"){
    
    mod.type <- "MNRM"
    
  } 
  
  if(bank.name == "M3PL"){
    
    mod.type <- "M3PL"
    
  }
  
  
  y <- lapply(x, function(w){
    
    bank_info <- apply(quad.vals, 1, function(z){
      
      bank.outcome <- list()
      bank.outcome <- test_information(item_parameters = w, model = mod.type, theta.val = list(matrix(c(1,.5,.5,1), nrow = 2), z), item.info = FALSE)
      
      return(bank.outcome)
      
    })
    
    
  })
  
  
})


save(bank_info, file = "/Shared/lss_jtemplin/Mintz/Dissertation/MAT_Results/bank_info.RData")