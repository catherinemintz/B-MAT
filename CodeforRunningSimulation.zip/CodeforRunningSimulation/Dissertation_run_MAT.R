
myArgs = commandArgs(trailingOnly = TRUE) #this will have all the specified arguments

#save(myArgs, file = paste("/Users/mathers/Dissertation/myArgs_", iteration, ".RData", sep = ""))

#save(myArgs, file = paste("/Users/mathers/Dissertation/myArgs_", ".RData", sep = ""))

iteration = as.numeric(myArgs[1])
model = myArgs[2]
itemselect = myArgs[3]
testterm = as.numeric(myArgs[4])
priorstrength = as.numeric(myArgs[5])

if(itemselect == "MI"){
  
  itemselect <- "Mutual Information"
  
}

if(itemselect == "Dopt"){
  
  itemselect <- "D-optimality"
  
}

#save(myArgs, file = paste("/Users/mathers/Dissertation/myArgs_", iteration, ".RData", sep = ""))

# set random number seed
seed = 0813 + iteration
set.seed(seed = seed)

####========================================================================== Reading in necessary functions and packages ####

library("MASS")
library("reshape2")
library("gtools")
#library("data.table")
#library("rstan")

for(i in 1:length(list.files(path = "/Users/mathers/catieCAT/R"))){
  
  file <- paste("/Users/mathers/catieCAT/R/",list.files(path = "/Users/mathers/catieCAT/R")[i], sep="")
  
  source(file, encoding="utf-8")
  
}

####========================================================================== Reading in data ####

load(file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Generating_Parameters/Iteration_", iteration, ".RData", sep=""))

if(model == "MNRM"){
  
  load(file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/", model, "/", "Iteration_", iteration, ".RData", sep=""))
  
}

if(model == "M3PL"){
  
  load(file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/Simulated_Item_Banks/", model, "/mirt/", model, "_Item_Bank_", iteration, ".RData", sep=""))
  
}


####========================================================================== Running the MATs across the conditions (2 termination, 2 selection, 3 Bayesian) ####

wd <- "/Users/mathers/stan_models/" #where the model text exists
# wd <- "~/hpchome/stan_models/" #for local

#conditions_list_dich <- list(c(20,40), c("Mutual Information", "D-Optimality"), c(10,1000,1000000), c("dichotomous"), list(dichotomous_item_bank), paste(wd, "m3pl_fi_fc_syntax.txt", sep =""), paste(wd, "m3pl_fi_fc_syntax_first.txt", sep =""))
#conditions_list_nom <- list(c(20,40), c("Mutual Information", "D-Optimality"), c(10,1000,1000000), c("nominal"), list(nominal_item_bank), paste(wd, "mnrm_fi_fc_syntax.txt", sep =""), paste(wd, "mnrm_fi_fc_syntax_first.txt", sep =""))


if(model == "M3PL"){
  
  colnames(item_bank) <- c("Item", "d", "a1","a2", "c") 
  
  person_results <- lapply(sim_examinees_split, function(x){
    
    person.cond <- MAT(item_pool = item_bank,
                       item_selection_criterion = itemselect,
                       test_termination_criterion = testterm,
                       data_type = "dichotomous",
                       true_theta = x,
                       priors = list(
                         mu_theta = c(0,0),
                         Sigma=matrix(c(1,0.5, 0.5,1), nrow = 2),
                         Sigma_Strength = priorstrength,
                         Theta_Strength= priorstrength), #for correlation matrix
                       working_directory = wd,
                       model_text_file = paste(wd, "m3pl_fi_fc_syntax.txt", sep =""),
                       first_item_text_file = paste(wd, "m3pl_fi_fc_syntax_first.txt", sep =""),
                       Bank = iteration)
    
    return(person.cond)  
    
  })
  
}

if(model == "MNRM"){
  
  item_bank = sim_items_nom
  
  colnames(item_bank) <- c("Item", "Category", "d", "a1","a2") 
  
  person_results <- lapply(sim_examinees_split, function(x){
    
    person.cond <- MAT(item_pool = item_bank,
                       item_selection_criterion = itemselect,
                       test_termination_criterion = testterm,
                       data_type = "nominal",
                       true_theta = x,
                       priors = list(
                         maxCategory = 4,
                         mu_theta = c(0,0),
                         Sigma=matrix(c(1,0.5, 0.5,1), nrow = 2),
                         Sigma_Strength = priorstrength,
                         Theta_Strength= priorstrength), #for correlation matrix
                       working_directory = wd,
                       model_text_file = paste(wd, "mnrm_fi_fc_syntax.txt", sep =""),
                       first_item_text_file = paste(wd, "mnrm_fi_fc_syntax_first.txt", sep =""),
                       Bank = iteration)
    
    return(person.cond)  
    
  })
  
  
  
}

#assign(paste0("Condition",iteration, model, itemselect, testterm, priorstrength, sep = "_"), person_results)

#save(x = paste("Condition",iteration, model, itemselect, testterm, priorstrength, sep = "_"), file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/MAT_Results/", itemselect,"_",testterm, "_", priorstrength, "/", model, "_MAT_", iteration, ".RData", sep=""))

save(x = person_results, file = paste("/Shared/lss_jtemplin/Mintz/Dissertation/MAT_Results/", itemselect,"_",testterm, "_", priorstrength, "/", model, "_MAT_", iteration, ".RData", sep=""))
