#' parameter_conversion
#'
#' @param x A dataframe with item parameters in each column
#' @param scalingfactor An integer value. For e.g., use 1.72 if converting to/from a logistic ogive.
#' @param conversion_type Desired output scale. 
#' @param diff_int_names Character vector of column names for difficulty/intercept parameters 
#' @param disc_slope_names Character vector of column names for discrimination/slope parameters 
#' @return A list of item responses, administered items, and the estimated posterior distribution after each item for each simulee.


parameter_conversion <- function(x, scalingfactor = NULL, conversion_type = list("discrimination/difficulty", "slope/intercept", diff_int_names, disc_slope_names)){
  
  y <- x
  
  if(is.na(scalingfactor) == TRUE){
    
    scalingfactor <- 1
    
  }
  
  if(conversion_type == "discrimination/difficulty"){
    
    y[,which(colnames(y) %in% diff_int_names)] <- x[,(colnames(y) %in% diff_int_names)]/(-1*scalingfactor*x[,(colnames(y) %in% disc_slope_names)])
    y[,(colnames(y) %in% disc_slope_names)] <- x[,(colnames(y) %in% disc_slope_names)]/scalingfactor
    
  }
  
  if(conversion_type == "slope/intercept"){
    
    y[,which(colnames(y) %in% diff_int_names)] <- -1*scalingfactor*x[,(colnames(y) %in% disc_slope_names)]*x[,(colnames(y) %in% diff_int_names)]
    y[,(colnames(y) %in% disc_slope_names)] <- x[,(colnames(y) %in% disc_slope_names)]*scalingfactor
    
  }
  
  return(y)
  
}