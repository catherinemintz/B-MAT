generating_parameter_evaluation <- function(generating_location, simulated_location, save_location){

  #for local
  # generating_location <- "~/hpchome/Dissertation/Generating Parameters/"
  # simulated_location <-  "~/hpchome/Dissertation/Simulated Item Banks/"
  # save_location = "~/hpchome/Dissertation/Tables and Graphs/"

  ## Reading in Generating Parameters

  generating_filenames <- list.files(generating_location, pattern="item", full.names=TRUE)
  generating_names <- do.call(rbind.data.frame,lapply(generating_filenames, function(x){

    iteration_name <- unlist(strsplit(as.character(x), "[^0-9]+"))[2]

    return(iteration_name)


  }))

  generating_list <- lapply(generating_filenames, readRDS)

  for(i in 1:length(generating_list)){

    names(generating_list)[i] <- paste("Iteration_", generating_names[i,], sep = "")

  }



  ## Reading in Item Bank Parameter Estimates

  bank_filenames <- list.files(simulated_location, pattern=paste("modsum_mnrm", sep =""), full.names=TRUE)
  bank_names <- do.call(rbind.data.frame,lapply(bank_filenames, function(x){

    iteration_name <- unlist(strsplit(as.character(x), "[^0-9]+"))[2]

    return(iteration_name)


  }))

  bank_list <- lapply(bank_filenames, read.csv)

  for(i in 1:length(bank_list)){

    names(bank_list)[i] <- paste("Iteration_",bank_names[i,], sep="")

  }



  ## Extracting and Cleaning Simulated Parameters

  extracted_thresholds <- lapply(bank_list, function(x){

    thresholds <- x[grep("^mu", x$variable), ]

    nums <- as.data.frame(strsplit(thresholds$variable, ","))

    #threshold_splice_item <- sub("\\D*(\\d+).*", "\\1", nums[1,])
    threshold_splice_item <- gsub("[^0-9]+", "", nums[1,])
    threshold_splice_cat <- gsub("[^0-9]+", "", nums[2,])

    thresholds_item_cat <- as.data.frame(matrix(c(NA), nrow = length(threshold_splice_item)))
    thresholds_item_cat$Item <- as.numeric(threshold_splice_item)
    thresholds_item_cat$Category <- as.numeric(threshold_splice_cat)
    thresholds_item_cat$Mu <- thresholds$mean

    thresholds_item_cat <-thresholds_item_cat[, which(colnames(thresholds_item_cat) %in% c("Item", "Category", "Mu"))]

    return(thresholds_item_cat)

  })

  extracted_slopes <- lapply(bank_list, function(x){

    slopes <- x[grep("^lambdaDim", x$variable), ]

    nums <- as.data.frame(strsplit(slopes$variable, ","))

    slopes_splice_item <- gsub("[^0-9]+", "", nums[1,])
    slopes_splice_dimension <- gsub("[^0-9]+", "", nums[2,])
    slopes_splice_cat <- gsub("[^0-9]+", "", nums[3,])

    slopes_item_cat <- as.data.frame(matrix(c(NA), nrow = length(slopes_splice_item)))
    slopes_item_cat$Item <- as.numeric(slopes_splice_item)
    slopes_item_cat$Category <- as.numeric(slopes_splice_cat)
    slopes_item_cat$Dimension <- slopes_splice_dimension
    slopes_item_cat$Lambda <- slopes$mean
    slopes_item_cat <- slopes_item_cat[,-1]

    slopes_wide <- reshape(slopes_item_cat, timevar = "Dimension", idvar = c("Item", "Category"),v.names = "Lambda", direction = "wide")

    return(slopes_wide)



  })



  ## Computing the Difference Between Generating and Simulated Parameters

  #Thresholds

  combined_thresh <- mapply(LIST, extracted_thresholds, generating_list, SIMPLIFY=FALSE)
  threshold_difference <- lapply(combined_thresh, function(w){


    x <- w[[1]]
    y <- w[[2]]

    x <- x[with(x, order(x$Item, x$Category)), ]
    z <- x
    y <- y[with(y, order(y$Item, y$Category)), ]

    z$GeneratingMu[x$Item == y$Item & x$Category== y$Category]  <- y$d[x$Item == y$Item & x$Category== y$Category]
    z$thresh_diff <- z$Mu - z$GeneratingMu

    return(z)

  })
  threshold_difference_df <- do.call(rbind.data.frame, threshold_difference)

  threshold_difference_df["Iteration"] = unlist(lapply(
    strsplit(row.names(threshold_difference_df), ".", fixed = TRUE), function(x) x[[1]])
  )

  #Slopes

  combined_slopes <- mapply(LIST, extracted_slopes, generating_list, SIMPLIFY=FALSE)
  slopes_difference <- lapply(combined_slopes, function(w){


    x <- w[[1]]
    y <- w[[2]]

    x <- x[with(x, order(x$Item, x$Category)), ]
    z <- x
    y <- y[with(y, order(y$Item, y$Category)), ]

    z$GeneratingSlope1[x$Item == y$Item & x$Category== y$Category]  <- y$a1[x$Item == y$Item & x$Category== y$Category]
    z$GeneratingSlope2[x$Item == y$Item & x$Category== y$Category]  <- y$a2[x$Item == y$Item & x$Category== y$Category]
    z$slope_diff_1 <- z$Lambda.1 - z$GeneratingSlope1
    z$slope_diff_2 <- z$Lambda.2 - z$GeneratingSlope2


    return(z)

  })
  slopes_difference_df <- do.call(rbind.data.frame, slopes_difference)

  slopes_difference_df["Iteration"] = unlist(lapply(
    strsplit(row.names(slopes_difference_df), ".", fixed = TRUE), function(x) x[[1]])
  )

  # Binning graphs

  bininterval <- 2

  thresh_split <- split(threshold_difference_df, threshold_difference_df$Category)
  thresh_apply <- lapply(thresh_split, function(x){

    x <- x[with(x, order(x$GeneratingMu)), ]
    #y <- cut(c(min(x$GeneratingMu):max(x$GeneratingMu)), breaks = 5)

    x$bin <- as.numeric(ggplot2::cut_number(x$GeneratingMu,bininterval))
    x$BinInterval <- ggplot2::cut_number(x$GeneratingMu,bininterval)
    x <- as.data.table(x)

    #y <- x[, BinMean:=mean(Mu), BinSD:=sd(Mu), by=list(bin)]
    y <- x[,`:=`(BinMean = mean(Mu),
                 BinSD = sd(Mu)),
           by=list(bin)]


    CatMax <- max(y$Mu)
    CatMin <- min(y$Mu)
    offset <- c(abs(CatMax), abs(CatMin))
    y$Offset <- offset[which.max(offset)]

    return(y)

  })
  thresh_combine <- do.call(rbind.data.frame, thresh_apply)

  slope_split <- split(slopes_difference_df, slopes_difference_df$Category)

  slope_1_apply <- lapply(slope_split, function(x){

    x <- x[with(x, order(x$GeneratingSlope1)), ]

    x$bin <- as.numeric(ggplot2::cut_number(x$GeneratingSlope1,bininterval))
    x$BinInterval <- ggplot2::cut_number(x$GeneratingSlope1,bininterval)
    x <- as.data.table(x)

    #y <- x[, BinMean:=mean(Mu), BinSD:=sd(Mu), by=list(bin)]
    y <- x[,`:=`(BinMean = mean(GeneratingSlope1),
                 BinSD = sd(GeneratingSlope1)),
           by=list(bin)]

    CatMax <- max(y$BinMean)
    CatMin <- min(y$BinMean)
    offset <- c(abs(CatMin), abs(CatMax))
    y$Offset <- offset[which.max(offset)]+y$BinSD[y$BinMean == offset[which.max(offset)]][1]

    return(y)

  })
  slope_1_combine <- do.call(rbind.data.frame, slope_1_apply)

  slope_2_apply <- lapply(slope_split, function(x){

    x <- x[with(x, order(x$GeneratingSlope2)), ]

    x$bin <- as.numeric(ggplot2::cut_number(x$GeneratingSlope2,bininterval))
    x$BinInterval <- ggplot2::cut_number(x$GeneratingSlope2,bininterval)
    x <- as.data.table(x)

    #y <- x[, BinMean:=mean(Mu), BinSD:=sd(Mu), by=list(bin)]
    y <- x[,`:=`(BinMean = mean(GeneratingSlope2),
                 BinSD = sd(GeneratingSlope2)),
           by=list(bin)]


    CatMax <- max(y$Lambda.1, y$Lambda.2)
    CatMin <- min(y$Lambda.1, y$Lambda.2)
    offset <- c(abs(CatMax), abs(CatMin))
    y$Offset <- offset[which.max(offset)]

    return(y)

  })
  slope_2_combine <- do.call(rbind.data.frame, slope_2_apply)



  ## Graphing the differences across simulations

  mu_plots_point <- slope_1_plots_point <- slope_2_plots_point <- list()

  for(i in 1:length(unique(thresh_combine$Category))){

    mu_plots_point[[i]] <- mu_plot <- ggplot(data = thresh_combine[which(thresh_combine$Category == i),])+
      geom_point(aes(x= BinInterval, y = BinMean))+
      geom_errorbar(position = "dodge", aes(x = BinInterval, ymin=BinMean-BinSD, ymax=BinMean+BinSD), width=.2)+
      scale_x_discrete(name = "Generating Threshold (In Intervals)")+
      scale_y_continuous(name = "Estimated Threshold Means")+
      ggtitle(label = paste("Category ", i, " Thresholds", sep =""))+
      theme_bw()+
      theme(plot.title =element_text(hjust=0.5))

   print(mu_plots_point[[i]])
   ggplot2::ggsave(plot = mu_plot, path = save_location, filename = paste("Threshold Bias Category ",i, sep = ""), device = "jpeg")

  }

  for(i in 1:length(unique(slope_1_combine$Category))){

    abs.lim <- (ceiling(slope_1_combine$Offset[slope_1_combine$Category == i][1]*2)/2) #CREATE THIS BASED ON THE BIN MEANS

    limits <- c(-abs.lim, abs.lim)

    breaks_vec <- seq(limits[1], limits[2], by = 0.5)

    slope_1_plots_point[[i]] <- slope_plot <- ggplot(data = slope_1_combine[which(slope_1_combine$Category == i),])+
      geom_point(aes(x= BinInterval, y = BinMean))+
      geom_errorbar(position = "dodge", aes(x = BinInterval, ymin=BinMean-BinSD, ymax=BinMean+BinSD), width=.2)+
      scale_x_discrete(name = "Generating Slope (In Intervals)")+
      scale_y_continuous(name = "Estimated Slope Means", limits = limits, breaks = breaks_vec)+
      ggtitle(label = paste("Dimension 1: Category ", i, " Slopes", sep =""))+
      theme_bw()+
      theme(plot.title =element_text(hjust=0.5))

    print(slope_1_plots_point[[i]])
    ggplot2::ggsave(plot = slope_plot, path = save_location, filename = paste("Slope 1 Bias Category ",i, sep = ""), device = "jpeg")


  }

  for(i in 1:length(unique(slope_2_combine$Category))){

    slope_2_plots_point[[i]] <- slope_plot <- ggplot(data = slope_2_combine[which(slope_2_combine$Category == i),])+
      geom_point(aes(x= BinInterval, y = BinMean))+
      geom_errorbar(position = "dodge", aes(x = BinInterval, ymin=BinMean-BinSD, ymax=BinMean+BinSD), width=.2)+
      scale_x_discrete(name = "Generating Slope (In Intervals)")+
      scale_y_continuous(name = "Estimated Slope Means")+
      ggtitle(label = paste("Dimension 2: Category ", i, " Slopes", sep =""))+
      theme_bw()+
      theme(plot.title =element_text(hjust=0.5))

   # print(slope_2_plots_point[[i]])
    ggplot2::ggsave(plot = slope_plot, path = save_location, filename = paste("Slope 2 Bias Category ",i, sep = ""), device = "jpeg")


  }


  ## Creating a table for the bias

  all_parameters <- merge(threshold_difference_df, slopes_difference_df, by = intersect(names(threshold_difference_df), names(slopes_difference_df)))

  all_parameters <- NA

}
