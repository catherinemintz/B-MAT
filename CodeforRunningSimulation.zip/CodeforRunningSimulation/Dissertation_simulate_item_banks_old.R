
myArgs = commandArgs(trailingOnly = TRUE) #this will have all the specified arguments

iteration = as.numeric(myArgs[1])
model = myArgs[2]

#save(myArgs, file = paste("/Users/mathers/Dissertation/myArgs_", iteration, ".RData", sep = ""))

# set random number seed
seed = 0813 + iteration
set.seed(seed = seed)

####========================================================================== Reading in necessary functions and packages ####

library("MASS")
library("reshape2")
library("gtools")
#library("data.table")
#library("rstan")

for(i in 1:length(list.files(path = "/Users/mathers/catieCAT/R"))){
  
  file <- paste("/Users/mathers/catieCAT/R/",list.files(path = "/Users/mathers/catieCAT/R")[i], sep="")
  
  source(file, encoding="utf-8")
  
}

## Local sourcing
# for(i in 1:length(list.files(path = "~/hpchome/catieCAT/R"))){
#
#   file <- paste("~/hpchome/catieCAT/R/",list.files(path = "~/hpchome/catieCAT/R")[i], sep="")
#
#   source(file, encoding="utf-8")
#
# }

####========================================================================== Reading in data ####

load(file = paste("/Users/mathers/Dissertation/Generating Parameters/Iteration_", iteration, ".RData", sep=""))

####========================================================================== Creating rstan inputs ####

# data dimensions
nObs = nrow(sim_people)
nItems = ncol(sim_response_dich_df)
nFactors = 2
maxCategory = 4


# item threshold hyperparameters
muMeanHyperParameter = 0
muMeanVecHP = rep(muMeanHyperParameter, maxCategory-1)
muMeanMatrix = NULL
for (item in 1:nItems){
  muMeanMatrix = rbind(muMeanMatrix, muMeanVecHP)
}

muVarianceHyperParameter = 1
muCovarianceMatrixHP = diag(x = muVarianceHyperParameter, nrow = maxCategory-1)
muCovArray = array(data = 0, dim = c(nItems, maxCategory-1, maxCategory-1))
for (item in 1:nItems){
  muCovArray[item, , ] = diag(x = muVarianceHyperParameter, nrow = maxCategory-1)
}

# item discrimination/factor loading hyperparameters
lambdaMeanHyperParameter = 0
lambdaMeanVecHP = rep(lambdaMeanHyperParameter, maxCategory-1)
lambdaMeanMatrix = NULL
for (item in 1:nItems){
  lambdaMeanMatrix = rbind(lambdaMeanMatrix, lambdaMeanVecHP)
}


lambdaVarianceHyperParameter = 10
lambdaCovarianceMatrixHP = diag(x = lambdaVarianceHyperParameter, nrow = nItems)

Keys <- rep(4, nItems)

responseCombos <- as.data.frame(t(matrix(c(rep(c(1:maxCategory), maxCategory-1)), nrow = maxCategory-1, ncol = maxCategory)))
responseCombos <- t(apply(responseCombos,1,sort))
responseCombos <- as.data.frame(responseCombos)
responseOptions <- c(1:maxCategory)

responseCombos$Missing <- 0
for(i in 1:nrow(responseCombos)){
  responseCombos$Missing[i] <- which(responseOptions %!in% responseCombos[i,c(1:(maxCategory-1))])
}
responseCombosord <- responseCombos[order(responseCombos$Missing),]

drop = "Missing"
responseCombos <- responseCombosord[,!(names(responseCombosord) %in% drop)]
responseCombos <- matrix(unlist(responseCombos), nrow = maxCategory, ncol = (maxCategory-1))


thetaMean = rep(0, 2)

dim1 <- c(rep(0, unidim_items), rep(1, unidim_items), rep(1, multidim_items))
dim2 <- c(rep(1, unidim_items), rep(0, unidim_items), rep(1, multidim_items))
Qmatrix <- t(rbind(dim1, dim2))

####========================================================================== Simulating Item Banks ####

if(model == "M3PL"){
  
  modcode_m3pl = readr::read_file("/Users/mathers/stan_models/m3pl_syntax.txt") # read in stan model syntax from a .txt file stored on your HPC home drive (replace <hawkid> (without brackets) with your HawkID and <stanfile> with the name of your stan model syntax file)
  
  # modcode_m3pl = readr::read_file("~/hpchome/stan_models/m3pl_syntax.txt") # for use on local system
  
  moddata_m3pl = list(
    nObs = nObs,
    nItems = nItems,
    Qmatrix = Qmatrix,
    Y = t(sim_response_dich_df),
    meanMu = 0,
    covMu = 1,
    meanLambda = rep(0, nFactors),
    covLambda = diag(1, nFactors),
    nFactors = nFactors,
    meanTheta = thetaMean) # define model data as specified in the rstan model syntax's data block (just like cmdstanr)
  
  modstan_m3pl = rstan::stan_model(model_code = modcode_m3pl) # compile stan model
  
  modrun_m3pl = rstan::sampling(modstan_m3pl,
                                data = moddata_m3pl,
                                chains = 4,
                                warmup = 150,
                                iter = 200,
                                thin = 50,
                                #open_progress = TRUE,
                                refresh = 50) # run sampler with default settings (see rstan documentation at https://mc-stan.org/rstan/reference/stanmodel-method-sampling.html for more options, if needed)
  
  modsum_m3pl = posterior::summarise_draws(modrun_m3pl) # summarizes the posterior draws after sampling
  
  moddraws_m3pl = as.data.frame(modrun_m3pl) # saves the posterior's draws to a data.frame object (this will be used to create a .csv file later)
  
  save(modrun_m3pl, modsum_m3pl, moddraws_m3pl, file = paste("/Users/mathers/Dissertation/Simulated Item Banks/M3PL/M3PL_Raw_Iteration_", iteration, ".RData", sep=""))
  
  item_bank <- STAN_output_to_item_bank(x = modsum_m3pl,   
                                                    item_type = "dichotomous",
                                                    parameter_names <- c("initMu", "initLambdaDim", "guess"),
                                                    dimensions = c(2,3,2),
                                                    output_names <- list("d", c("a1", "a2"), "c"))
  
  save(item_bank, file = paste("/Users/mathers/Dissertation/Simulated Item Banks/M3PL/M3PL_Item_Bank_", iteration, ".RData", sep=""))
  
}

if(model == "MNRM"){
  
  modcode_mnrm = readr::read_file("/Users/mathers/stan_models/mnrm_syntax.txt") # read in stan model syntax from a .txt file stored on your HPC home drive (replace <hawkid> (without brackets) with your HawkID and <stanfile> with the name of your stan model syntax file)
  
  #modcode_mnrm = readr::read_file("~/hpchome/stan_models/mnrm_syntax.txt") # for use on local system
  
  # to help algorithm converge:
  # create starting values for theta that are standardized sum scores
  
  accuracy = matrix(data = NA, nrow = ncol(sim_response_nom_df), ncol = nrow(sim_response_nom_df))
  
  for (item in 1:ncol(accuracy)){
    accuracy[which(sim_response_nom_df[item,] == Keys[item]), item] = 1
    accuracy[which(!sim_response_nom_df[item,] == Keys[item]), item] = 0
  }
  
  sumscores =  t(accuracy) %*% Qmatrix
  meanSumScores = apply(sumscores, 2, mean)
  sdSumScores = apply(sumscores, 2, sd)
  
  startingThetas = cbind(
    (sumscores[,1] - meanSumScores[1])/sdSumScores[1],
    (sumscores[,2] - meanSumScores[2])/sdSumScores[2]
  )
  
  moddata_mnrm = list(nObs = nObs,
                      nItems = nItems,
                      maxCategory = maxCategory,
                      Keys = Keys,
                      ResponseCombos = responseCombos,
                      Qmatrix = Qmatrix,
                      Y = t(sim_response_nom_df),
                      meanMu = muMeanMatrix,
                      covMu = muCovArray,
                      nFactors = 2,
                      meanTheta = thetaMean) # define model data as specified in the rstan model syntax's data block (just like cmdstanr)
  
  modstan_mnrm = rstan::stan_model(model_code = modcode_mnrm) # compile stan model
  
  modrun_mnrm = rstan::sampling(modstan_mnrm,
                                data = moddata_mnrm,
                                chains = 4,
                                warmup = 150,
                                iter = 200,
                                thin = 50,
                                # open_progress = TRUE,
                                refresh = 50) # run sampler with default settings (see rstan documentation at https://mc-stan.org/rstan/reference/stanmodel-method-sampling.html for more options, if needed)
  
  modsum_mnrm = posterior::summarise_draws(modrun_mnrm) # summarizes the posterior draws after sampling
  
  moddraws_mnrm = as.data.frame(modrun_mnrm) # saves the posterior's draws to a data.frame object (this will be used to create a .csv file later)
  
  save(modrun_mnrm, modsum_mnrm, moddraws_mnrm, file = paste("/Users/mathers/Dissertation/Simulated Item Banks/MNRM/MNRM_Raw_Iteration_", iteration, ".RData", sep=""))
  
  item_bank <- STAN_output_to_item_bank(x = modsum_mnrm,   
                                                item_type = "nominal",
                                                parameter_names <- c("initMu", "initLambdaDim"),
                                                dimensions = c(2,3),
                                                output_names <- list("d", c("a1", "a2")),
                                                key.positions = rep(4, nrow(sim_response_nom_df)),
                                                item.cat.factor.positions = list(c(1,2), c(1,3,2), c(1,2)))
  
  save(item_bank, file = paste("/Users/mathers/Dissertation/Simulated Item Banks/MNRM/MNRM_Item_Bank_", iteration, ".RData", sep=""))
}