odiag <- function(x) x[col(x) != row(x)]
