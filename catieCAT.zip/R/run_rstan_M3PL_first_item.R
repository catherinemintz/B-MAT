run_rstan_M3PL_first_item <- function(STAN_file,
                           x,
                           num_theta,
                           item_params,
                           working_directory,
                           single_item = FALSE,
                           priors = list(
                             mu_theta = c(0,0),
                             sigma_theta = c(1,1),
                             lkj_theta=1, #for correlation matrix
                             sigma_theta_corr = rep(1,2),
                             theta_corr_input = .5)){

  working_directory <<- working_directory
  STAN_file <<- STAN_file

  # m3PL_file <- STAN_file

  a1 <- as.integer(item_params[3])
  a2 <- as.integer(item_params[4])
  guess <- as.integer(item_params[5])
  diff <- as.integer(item_params[2])

  y1 <- t(rbind(item_params[1], x))

  if(single_item == TRUE){

    y1[,1] <- I <- 1

  } else {

    I <- nrow(a1)
  }

  # stanData <- list(D=num_theta,
  #                  I=max(y1[,1]),
  #                  a1=a1,
  #                  a2 = a2,
  #                  diff = diff,
  #                  guess = guess,
  #                  Y=y1[,2], #begin specifying priors
  #                  mu_theta = priors[["mu_theta"]],
  #                  sigma_theta = priors[["sigma_theta"]],
  #                  sigma_theta_corr = priors[["sigma_theta_corr"]],
  #                  theta_corr_input = priors[["theta_corr_input"]],
  #                  lkj_theta= priors[["lkj_theta"]]) #for correlation matrix)

  stanData <- list(D=num_theta,
                   I=I,
                   a1=a1,
                   a2 = a2,
                   diff = diff,
                   guess = guess,
                   Y=y1[,2], #begin specifying priors
                   mu_theta = priors[["mu_theta"]],
                   sigma_theta = priors[["sigma_theta"]],
                   sigma_theta_corr = priors[["sigma_theta_corr"]],
                   theta_corr_input = priors[["theta_corr_input"]],
                   lkj_theta= priors[["lkj_theta"]]) #for correlation matrix)


  path_name <- paste(working_directory,"first_item_model.stan", sep="/")

  fileConn <-file(path_name)
  writeLines(STAN_file, fileConn)
  close(fileConn)

  file_mod <- file.path(path_name)

  model_file <- cmdstan_model(file_mod)

  model_mcmc <- model_file$sample(
    data = stanData,
    chains = 4,
    parallel_chains = 4,
    iter_warmup = 5000,
    iter_sampling = 10000,
    show_messages = TRUE)

  #model_params <- m3PL_mcmc$summary()

  return(model_mcmc)

}
