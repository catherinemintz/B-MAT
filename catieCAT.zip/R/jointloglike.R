
#source("C:\\Users\\CatieM\\Dropbox\\Dissertation\\Dissertation R Package\\functions\\DCMloglike.R")

## Joint likelihood function ===========================================================

jointloglike = function(response, b0_array, b1_array, b2_array, num_att, data_type, per_class){

  # item_id = item_parameters[,1]

    jointloglikelihood = 0

    if(data_type == "dichotomous"){

      for (i in 1: length(b0_array)){ ##may need to be either length or nrow
        jointloglikelihood = jointloglikelihood + DCMloglike(response = response,
                                                             b0 = b0_array[i],
                                                             b1 = b1_array[i],
                                                             b2 = b2_array[i],
                                                             num_att = num_att,
                                                             data_type = "dichotomous",
                                                             per_class = per_class)

      }
    }

    if(data_type == "nominal"){

      categories <- length(b0_array)/length(response)

      if(length(response) > 1){
        for (i in 1:nrow(b0_array)){ ##may need to be either length or nrow
          jointloglikelihood = jointloglikelihood + DCMloglike(response = response,
                                                               b0 = b0_array[i],
                                                               b1 = b1_array[i],
                                                               b2 = b2_array[i],
                                                               num_att = num_att,
                                                               data_type = "nominal",
                                                               per_class = per_class)
        }
      } else{

          jointloglikelihood =  DCMloglike(response = response,
                                              b0 = b0_array,
                                              b1 = b1_array,
                                              b2 = b2_array,
                                              num_att = num_att,
                                              data_type = "nominal",
                                              per_class = per_class)

      }
    }


  return(jointloglikelihood)
}

