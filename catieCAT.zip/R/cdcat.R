#' CD-CAT
#'
#' @param item_pool A dataframe with column vectors in the following order: Question ID, Item intercept, and A minus 2 Attribute weight columns
#' @param num_att The number of attributes
#' @param item_selection_criterion Choice of item selection criterion. Takes either "Mutual Information" or "Shannon Entropy" as input
#' @param test_termination_criterion The number of items to administer
#' @param data_type The type of data. Takes either "dichotomous" (for 0/1 scored data) or "nominal" (for unordered data; built for series of 1,2,3,4)
#' @param true_class Either a vector of length two or matrix with nrow = number of personal and ncol = number of attributes with simulees' latent classes.
#' @param class_prior Vector of length equal to number of latent classes. Each element is the prior probability for each class.
#' @return A list of item responses, administered items, and the estimated posterior distribution after each item for each simulee.
#'
CDCAT <- function(item_pool, num_att, item_selection_criterion, test_termination_criterion, data_type, true_class, class_prior = NULL){

  set.seed(123)

  true_class <- true_class
  examinee_estimate <- c(0,1)   #examinee_estimate <- matrix(rep(c(0,1)), nrow = length(examinees), ncol = num_att)

  # Objects for use in the functions

  classObject <- matrix(c(0,0,1,1,0,1,0,1), nrow = 4)
  current_posterior <- rep(0.25,4) #Actually the prior

  if(is.null(class_prior) == FALSE){
    current_posterior <- class_prior
  }

  # Objects for necessary follow-ups

  items_administered <- matrix(NA)
  #estimated_posterior <- as.data.frame(matrix(NA, nrow = test_termination_criterion, ncol = 4))
  estimated_posterior <- list()
  responses <- vector(length = test_termination_criterion)

  objectlengths <- 0
   ##================================================================CD-CAT for Dichotomous Data

  if(data_type == "dichotomous"){

    ##---------------------------------------------------------------------------------------------------- Mutual Information

    if(item_selection_criterion == "mutual information"| item_selection_criterion == "Mutual Information"){

      ##------------------- First item

      for(j in 1:nrow(item_pool)){
        item_pool$MI_results[j] <- item_mututal_information(current_posterior = current_posterior,
                                                            item_parameters = item_pool[j,],
                                                            num_theta = num_att,
                                                           latent_variable_type = "categorical",
                                                            data_type = "dichotomous")
      }


      item_pool_sorted <- item_pool[order(-item_pool$MI_results),]
      top_five <- item_pool_sorted[1:5,]
      item_to_be_administered <- top_five[sample(1:nrow(top_five), 1), ]

      #item_to_be_administered <- item_pool[(which.max(item_pool$MI_results)),] #Choosing the item with the highest MI

      new_response <- LCDM(item_to_be_administered, latent_class = true_class)
      responses[objectlengths] <- new_response

      current_posterior <- posteriorEstimate(response = new_response,
                                             item_parameters = item_to_be_administered,
                                             class_prior = current_posterior,
                                             num_att = 2,
                                             data_type = "dichotomous")

      items_administered <- item_to_be_administered

      estimated_posterior[objectlengths,] <- current_posterior #make sure this object updates accordingly

      objectlengths <- objectlengths + 1 #updating the element index in each list

      ##--------------------------------- After the first item

      while(objectlengths <= test_termination_criterion){ #keep looping through until the specified number of items is administered

        #  item_parameters <- item_pool[which(item_pool[,1] != items_administered[,1] ),] #pulling out the items that haven't yet been administered
        item_parameters <- item_pool[which(!(item_pool[,1] %in% items_administered[,1])),]


        for(j in 1:nrow(item_parameters)){
          item_parameters$MI_results[j] <- item_mututal_information(current_posterior =  current_posterior,
                                                              num_theta = num_att,
                                                              item_parameters = item_parameters[j,],
                                                              latent_variable_type = "categorical",
                                                              data_type = "dichotomous")
        }


        item_to_be_administered <- item_parameters[(which.max(item_parameters$MI_results)),] #select item who has the highest MI from MI_results

        items_administered <- rbind(items_administered,item_to_be_administered)

        new_response <- LCDM(item_to_be_administered, latent_class = true_class)
        responses[objectlengths] <- new_response

        current_posterior <- posteriorEstimate(response = new_response,
                                               item_parameters = items_administered,
                                               class_prior = current_posterior,
                                               num_att = 2,
                                               data_type = "dichotomous")

        estimated_posterior[objectlengths,] <- current_posterior

        objectlengths <- objectlengths + 1 #updating the element index in each list

      }
    }

    ##----------------------------------------------------------------------- Shannon Entropy

    if(item_selection_criterion == "shannon entropy"| item_selection_criterion == "Shannon Entropy"){

      ##------------------- First item

      for(j in 1:nrow(item_pool)){
        item_pool$SH_results[j] <-  item_shannon_entropy(current_posterior = current_posterior,
                                                         item_parameters = item_pool[j,],
                                                         classObject = classObject,
                                                         data_type = "dichotomous")
      }


      item_pool_sorted <- item_pool[order(item_pool$SH_results),]
      top_five <- item_pool_sorted[1:5,]
      item_to_be_administered <- top_five[sample(1:nrow(top_five), 1), ]


      # item_to_be_administered <- item_pool[(which.min(item_pool$SH_results)),] #Choosing which item should be administered

      new_response <- LCDM(item_to_be_administered, latent_class = true_class)
      responses[objectlengths] <- new_response

      current_posterior <- posteriorEstimate(response = new_response,
                                             item_parameters = item_to_be_administered,
                                             class_prior = current_posterior,
                                             num_att = 2,
                                             data_type = "dichotomous")


      items_administered <- item_to_be_administered

      estimated_posterior[objectlengths,] <- current_posterior #make sure this object updates accordingly

      objectlengths <- objectlengths + 1

      ##--------------------------------- After the first item

      while(objectlengths <= test_termination_criterion){

        item_parameters <- item_pool[which(!(item_pool[,1] %in% items_administered[,1])),]


        for(j in 1:nrow(item_parameters)){
          item_parameters$SH_results[j] <- item_shannon_entropy(current_posterior =  current_posterior,
                                                          item_parameters = item_parameters[j,],
                                                          classObject = classObject,
                                                          data_type = "dichotomous")

        }


        item_to_be_administered <- item_parameters[(which.min(item_parameters$SH_results)),]

        items_administered <- rbind(items_administered,item_to_be_administered)

        new_response <- LCDM(item_to_be_administered, latent_class = true_class)
        responses[objectlengths] <- new_response

        current_posterior <- posteriorEstimate(response = new_response,
                                               item_parameters = items_administered,
                                               class_prior = current_posterior,
                                               num_att = 2,
                                               data_type = "dichotomous")

        estimated_posterior[objectlengths,] <- current_posterior

        objectlengths <- objectlengths + 1 #updating the element index in each list

      }
    }

    print(responses)
    print(items_administered)
    print(estimated_posterior)

  }

  ####------------------------------------------------------CD-CAT for Nominal Data-----------------------------------------------
  if(data_type == "nominal"){

    ##---------------------------------------------------------------------------------------------------- Mutual Information

    if(item_selection_criterion == "mutual information"| item_selection_criterion == "Mutual Information"){

      ##------------------- First item

      objectlengths <- objectlengths + 1 #updating the element index in each list

      MI_results <- matrix(NA, ncol = 2, nrow = length(unique(item_pool[,1])))

      items_split_first <- split(item_pool, item_pool[,1])

      for(j in 1:length(items_split_first)){

        temp <- item_mututal_information(current_posterior = current_posterior,
                                         item_parameters = items_split_first[[j]],
                                         num_theta = num_att,
                                         latent_variable_type = "categorical",
                                         data_type = "nominal")
        temp2 <- items_split_first[[j]]

        MI_results[j,1] <- temp2[1,1]
        MI_results[j,2] <- temp
      }


      ia <- MI_results[which.max(MI_results[,2]),]
      item_to_be_administered <- item_pool[which(item_pool[,1] == ia[1]),] #Choosing which item should be administered

      new_response <- NLCDM(item_to_be_administered, latent_class = true_class)
      responses[objectlengths] <- new_response

      current_posterior <- posteriorEstimate(response = new_response,
                                             item_parameters = item_to_be_administered,
                                             class_prior = current_posterior,
                                             num_att = 2,
                                             data_type = "nominal")

      items_administered <- item_to_be_administered

      estimated_posterior[[objectlengths]] <- current_posterior #make sure this object updates accordingly


      ##--------------------------------- After the first item

      while(objectlengths < test_termination_criterion){ #keep looping through until the specified number of items is administered

         item_parameters <- item_pool[which(!(item_pool[,1] %in% items_administered[,1])),] #pulling out the items that haven't yet been administered

        MI_results <- matrix(NA, ncol = 2, nrow = length(unique(item_parameters[,1])))

        items_split <- split(item_parameters, item_parameters[,1])

        for(j in 1:length(items_split)){

            temp <- item_mututal_information(current_posterior = current_posterior,
                                             item_parameters = items_split[[j]],
                                             num_theta = num_att,
                                             latent_variable_type = "categorical",
                                             data_type = "nominal")
            temp2 <- items_split[[j]]

            MI_results[j,1] <- temp2[1,1]
            MI_results[j,2] <- temp
          }

        ia <- MI_results[which.max(MI_results[,2]),]
        item_to_be_administered <- item_parameters[which(item_parameters[,1] == ia[1]),] #Choosing which item should be administered

        #item_to_be_administered <- item_parameters[(which.max(item_parameters$MI_results)),] #select item who has the highest MI from MI_results

        items_administered <- rbind(items_administered,item_to_be_administered)

        new_response <- NLCDM(item_to_be_administered, latent_class = true_class)

        current_posterior <- posteriorEstimate(response = new_response,
                                               item_parameters = items_administered,
                                               class_prior = current_posterior,
                                               num_att = 2,
                                               data_type = "nominal")

        objectlengths <- objectlengths + 1 #updating the element index in each list

        responses[objectlengths] <- new_response
        estimated_posterior[[objectlengths]] <- current_posterior

        }
    }

    ##----------------------------------------------------------------------- Shannon Entropy

    if(item_selection_criterion == "shannon entropy"| item_selection_criterion == "Shannon Entropy"){


      ## First item

      objectlengths <- objectlengths + 1 #updating the element index in each list

      MI_results <- matrix(NA, ncol = 2, nrow = length(unique(item_pool[,1])))

      items_split_first <- split(item_pool, item_pool[,1])

      for(j in 1:length(items_split_first)){

        temp <- item_shannon_entropy(current_posterior = current_posterior,
                                         item_parameters = items_split_first[[j]],
                                         classObject = classObject,
                                         data_type = "nominal")
        temp2 <- items_split_first[[j]]

        MI_results[j,1] <- temp2[1,1]
        MI_results[j,2] <- temp
      }


      ia <- MI_results[which.max(MI_results[,2]),]
      item_to_be_administered <- item_pool[which(item_pool[,1] == ia[1]),] #Choosing which item should be administered

      new_response <- NLCDM(item_to_be_administered, latent_class = true_class)
      responses[objectlengths] <- new_response

      current_posterior <- posteriorEstimate(response = new_response,
                                             item_parameters = item_to_be_administered,
                                             class_prior = current_posterior,
                                             num_att = 2,
                                             data_type = "nominal")

      items_administered <- item_to_be_administered

      estimated_posterior[[objectlengths]] <- current_posterior #make sure this object updates accordingly


      ##--------------------------------- After the first item

      while(objectlengths < test_termination_criterion){ #keep looping through until the specified number of items is administered

        item_parameters <- item_pool[which(!(item_pool[,1] %in% items_administered[,1])),] #pulling out the items that haven't yet been administered

        MI_results <- matrix(NA, ncol = 2, nrow = length(unique(item_parameters[,1])))

        items_split <- split(item_parameters, item_parameters[,1])

        for(j in 1:length(items_split)){

          temp <- item_shannon_entropy(current_posterior = current_posterior,
                                       item_parameters = items_split_first[[j]],
                                       classObject = classObject,
                                       data_type = "nominal")
          temp2 <- items_split[[j]]

          MI_results[j,1] <- temp2[1,1]
          MI_results[j,2] <- temp
        }

        ia <- MI_results[which.max(MI_results[,2]),]
        item_to_be_administered <- item_parameters[which(item_parameters[,1] == ia[1]),] #Choosing which item should be administered

        #item_to_be_administered <- item_parameters[(which.max(item_parameters$MI_results)),] #select item who has the highest MI from MI_results

        items_administered <- rbind(items_administered,item_to_be_administered)

        new_response <- NLCDM(item_to_be_administered, latent_class = true_class)

        current_posterior <- posteriorEstimate(response = new_response,
                                               item_parameters = items_administered,
                                               class_prior = current_posterior,
                                               num_att = 2,
                                               data_type = "nominal")

        objectlengths <- objectlengths + 1 #updating the element index in each list

        responses[objectlengths] <- new_response
        estimated_posterior[[objectlengths]] <- current_posterior

      }

    }

    print(responses)
    print(items_administered)
    print(estimated_posterior)

  }

  CDCAT_results <- list(responses, items_administered, estimated_posterior)
  names(CDCAT_results) <- c("Responses", "Administered.Items","Estimated.Posterior")

  return(CDCAT_results)

}


##============================================================== Follow-ups

# items_for_dimension_one <- list()
# items_for_dimension_two <- list()
# items_for_both_dimensions <- list()

# if(item_to_be_administered$Dimension == "One"|item_to_be_administered$Dimension == "1"){ #For checking whether one dimension is more heavily pulled from than another
#   items_for_dimension_one[[objectlengths]] <- item_to_be_administered           }
#
# if(item_to_be_administered$Dimension == "Two"|item_to_be_administered$Dimension == "two"){
#   items_for_dimension_two[[objectlengths]] <- item_to_be_administered
# }
#
# if(item_to_be_administered$Dimension == "Both"|item_to_be_administered$Dimension == "both"){
#   items_for_both_dimensions[[objectlengths]] <- item_to_be_administered
# }

#item_exposure <- matrix()

